import { n as __exportAll } from "../_runtime.mjs";
import { i as size, n as bindTo, r as equalSizes, t as tryCreateCanvasRenderingTarget2D } from "./fancy-canvas.mjs";
//#region node_modules/lightweight-charts/dist/lightweight-charts.production.mjs
/*!
* @license
* TradingView Lightweight Charts™ v5.2.1
* Copyright (c) 2026 TradingView, Inc.
* Licensed under Apache License 2.0 https://www.apache.org/licenses/LICENSE-2.0
*/
var lightweight_charts_production_exports = /* @__PURE__ */ __exportAll({
	CandlestickSeries: () => Qe,
	ColorType: () => $i,
	CrosshairMode: () => K,
	LastPriceAnimationMode: () => Hi,
	LineSeries: () => ye,
	LineStyle: () => h,
	LineType: () => r,
	MismatchDirection: () => It,
	PriceLineSource: () => Ui,
	PriceScaleMode: () => bi,
	TickMarkType: () => ji,
	TrackingModeExitMode: () => Wi,
	createChart: () => le,
	createChartEx: () => ae,
	isBusinessDay: () => Ki,
	isUTCTimestamp: () => Gi
});
var e = {
	title: "",
	visible: !0,
	hitTestTolerance: 3,
	lastValueVisible: !0,
	priceLineVisible: !0,
	priceLineSource: 0,
	priceLineWidth: 1,
	priceLineColor: "",
	priceLineStyle: 2,
	baseLineVisible: !0,
	baseLineWidth: 1,
	baseLineColor: "#B2B5BE",
	baseLineStyle: 0,
	priceFormat: {
		type: "price",
		precision: 2,
		minMove: .01
	}
};
var r;
var h;
function a(t, i) {
	const n = function(t, i) {
		switch (t) {
			case 0:
			default: return [];
			case 1: return [i, i];
			case 2: return [2 * i, 2 * i];
			case 3: return [6 * i, 6 * i];
			case 4: return [i, 4 * i];
		}
	}(i, t.lineWidth);
	return t.setLineDash(n), n;
}
function l(t, i, n, s) {
	t.beginPath();
	const e = t.lineWidth % 2 ? .5 : 0;
	t.moveTo(n, i + e), t.lineTo(s, i + e), t.stroke();
}
function o(t, i) {
	if (!t) throw new Error("Assertion failed" + (i ? ": " + i : ""));
}
function _(t) {
	if (void 0 === t) throw new Error("Value is undefined");
	return t;
}
function u(t) {
	if (null === t) throw new Error("Value is null");
	return t;
}
function c(t) {
	return u(_(t));
}
(function(t) {
	t[t.Simple = 0] = "Simple", t[t.WithSteps = 1] = "WithSteps", t[t.Curved = 2] = "Curved";
})(r || (r = {})), function(t) {
	t[t.Solid = 0] = "Solid", t[t.Dotted = 1] = "Dotted", t[t.Dashed = 2] = "Dashed", t[t.LargeDashed = 3] = "LargeDashed", t[t.SparseDotted = 4] = "SparseDotted";
}(h || (h = {}));
var d = class {
	constructor() {
		this.t = [];
	}
	i(t, i, n) {
		const s = {
			h: t,
			l: i,
			o: !0 === n
		};
		this.t.push(s);
	}
	_(t) {
		const i = this.t.findIndex(((i) => t === i.h));
		i > -1 && this.t.splice(i, 1);
	}
	u(t) {
		this.t = this.t.filter(((i) => i.l !== t));
	}
	p(t, i, n) {
		const s = [...this.t];
		this.t = this.t.filter(((t) => !t.o)), s.forEach(((s) => s.h(t, i, n)));
	}
	v() {
		return this.t.length > 0;
	}
	m() {
		this.t = [];
	}
};
function f(t, ...i) {
	for (const n of i) for (const i in n) void 0 !== n[i] && Object.prototype.hasOwnProperty.call(n, i) && ![
		"__proto__",
		"constructor",
		"prototype"
	].includes(i) && ("object" != typeof n[i] || void 0 === t[i] || Array.isArray(n[i]) ? t[i] = n[i] : f(t[i], n[i]));
	return t;
}
function p(t) {
	return "number" == typeof t && isFinite(t);
}
function v(t) {
	return "number" == typeof t && t % 1 == 0;
}
function m(t) {
	return "string" == typeof t;
}
function w(t) {
	return "boolean" == typeof t;
}
function M(t) {
	const i = t;
	if (!i || "object" != typeof i) return i;
	let n, s, e;
	for (s in n = Array.isArray(i) ? [] : {}, i) i.hasOwnProperty(s) && (e = i[s], n[s] = e && "object" == typeof e ? M(e) : e);
	return n;
}
function g(t) {
	return null !== t;
}
function b(t) {
	return null === t ? void 0 : t;
}
var S = "-apple-system, BlinkMacSystemFont, 'Trebuchet MS', Roboto, Ubuntu, sans-serif";
function x(t, i, n) {
	return void 0 === i && (i = S), `${n = void 0 !== n ? `${n} ` : ""}${t}px ${i}`;
}
var C = class {
	constructor(t) {
		this.M = {
			S: 1,
			C: 5,
			P: NaN,
			k: "",
			T: "",
			R: "",
			D: "",
			I: 0,
			V: 0,
			B: 0,
			A: 0,
			L: 0
		}, this.O = t;
	}
	N() {
		const t = this.M, i = this.F(), n = this.W();
		return t.P === i && t.T === n || (t.P = i, t.T = n, t.k = x(i, n), t.A = 2.5 / 12 * i, t.I = t.A, t.V = i / 12 * t.C, t.B = i / 12 * t.C, t.L = 0), t.R = this.H(), t.D = this.U(), this.M;
	}
	H() {
		return this.O.N().layout.textColor;
	}
	U() {
		return this.O.$();
	}
	F() {
		return this.O.N().layout.fontSize;
	}
	W() {
		return this.O.N().layout.fontFamily;
	}
};
function y(t) {
	return t < 0 ? 0 : t > 255 ? 255 : Math.round(t) || 0;
}
function P(t) {
	return .199 * t[0] + .687 * t[1] + .114 * t[2];
}
var k = class {
	constructor(t, i) {
		this.j = /* @__PURE__ */ new Map(), this.q = t, i && (this.j = i);
	}
	Y(t, i) {
		if ("transparent" === t) return t;
		const n = this.K(t), s = n[3];
		return `rgba(${n[0]}, ${n[1]}, ${n[2]}, ${i * s})`;
	}
	G(t) {
		const i = this.K(t);
		return {
			Z: `rgb(${i[0]}, ${i[1]}, ${i[2]})`,
			X: P(i) > 160 ? "black" : "white"
		};
	}
	J(t) {
		return P(this.K(t));
	}
	tt(t, i, n) {
		const [s, e, r, h] = this.K(t), [a, l, o, _] = this.K(i), u = [
			y(s + n * (a - s)),
			y(e + n * (l - e)),
			y(r + n * (o - r)),
			(c = h + n * (_ - h), c <= 0 || c > 1 ? Math.min(Math.max(c, 0), 1) : Math.round(1e4 * c) / 1e4)
		];
		var c;
		return `rgba(${u[0]}, ${u[1]}, ${u[2]}, ${u[3]})`;
	}
	K(t) {
		const i = this.j.get(t);
		if (i) return i;
		const s = function(t) {
			const i = document.createElement("div");
			i.style.display = "none", document.body.appendChild(i), i.style.color = t;
			const n = window.getComputedStyle(i).color;
			return document.body.removeChild(i), n;
		}(t).match(/^rgba?\s*\((\d+),\s*(\d+),\s*(\d+)(?:,\s*(\d*\.?\d+))?\)$/);
		if (!s) {
			if (this.q.length) for (const i of this.q) {
				const n = i(t);
				if (n) return this.j.set(t, n), n;
			}
			throw new Error(`Failed to parse color: ${t}`);
		}
		const e = [
			parseInt(s[1], 10),
			parseInt(s[2], 10),
			parseInt(s[3], 10),
			s[4] ? parseFloat(s[4]) : 1
		];
		return this.j.set(t, e), e;
	}
};
var T = class {
	constructor() {
		this.it = [];
	}
	nt(t) {
		this.it = t;
	}
	st(t, i, n) {
		this.it.forEach(((s) => {
			s.st(t, i, n);
		}));
	}
};
var R = class {
	st(t, i, n) {
		t.useBitmapCoordinateSpace(((t) => this.et(t, i, n)));
	}
};
var D = class extends R {
	constructor() {
		super(...arguments), this.rt = null;
	}
	ht(t) {
		this.rt = t;
	}
	et({ context: t, horizontalPixelRatio: i, verticalPixelRatio: n }) {
		if (null === this.rt || null === this.rt.lt) return;
		const s = this.rt.lt, e = this.rt, r = Math.max(1, Math.floor(i)) % 2 / 2, h = (h) => {
			t.beginPath();
			for (let a = s.to - 1; a >= s.from; --a) {
				const s = e.ot[a], l = Math.round(s._t * i) + r, o = s.ut * n, _ = h * n + r;
				t.moveTo(l, o), t.arc(l, o, _, 0, 2 * Math.PI);
			}
			t.fill();
		};
		e.ct > 0 && (t.fillStyle = e.dt, h(e.ft + e.ct)), t.fillStyle = e.vt, h(e.ft);
	}
};
function I() {
	return {
		ot: [{
			_t: 0,
			ut: 0,
			wt: 0,
			Mt: 0
		}],
		vt: "",
		dt: "",
		ft: 0,
		ct: 0,
		lt: null
	};
}
var V = {
	from: 0,
	to: 1
};
var B = class {
	constructor(t, i, n) {
		this.gt = new T(), this.bt = [], this.St = [], this.xt = !0, this.O = t, this.Ct = i, this.yt = n, this.gt.nt(this.bt);
	}
	Pt(t) {
		this.kt(), this.xt = !0;
	}
	Tt() {
		return this.xt && (this.Rt(), this.xt = !1), this.gt;
	}
	kt() {
		const t = this.yt.Dt();
		t.length !== this.bt.length && (this.St = t.map(I), this.bt = this.St.map(((t) => {
			const i = new D();
			return i.ht(t), i;
		})), this.gt.nt(this.bt));
	}
	Rt() {
		const t = 2 === this.Ct.N().mode || !this.Ct.It(), i = this.yt.Vt(), n = this.Ct.Bt(), s = this.O.Et();
		this.kt(), i.forEach(((i, e) => {
			const r = this.St[e], h = i.At(n), a = i.Lt();
			!t && null !== h && i.It() && null !== a ? (r.vt = h.zt, r.ft = h.ft, r.ct = h.Ot, r.ot[0].Mt = h.Mt, r.ot[0].ut = i.Ft().Nt(h.Mt, a.Wt), r.dt = h.Ht ?? this.O.Ut(r.ot[0].ut / i.Ft().$t()), r.ot[0].wt = n, r.ot[0]._t = s.jt(n), r.lt = V) : r.lt = null;
		}));
	}
};
var E = class extends R {
	constructor(t) {
		super(), this.qt = t;
	}
	et({ context: t, bitmapSize: i, horizontalPixelRatio: n, verticalPixelRatio: s }) {
		if (null === this.qt) return;
		const e = this.qt.Yt.It, r = this.qt.Kt.It;
		if (!e && !r) return;
		const h = Math.round(this.qt._t * n), o = Math.round(this.qt.ut * s);
		t.lineCap = "butt", e && h >= 0 && (t.lineWidth = Math.floor(this.qt.Yt.ct * n), t.strokeStyle = this.qt.Yt.R, t.fillStyle = this.qt.Yt.R, a(t, this.qt.Yt.Gt), function(t, i, n, s) {
			t.beginPath();
			const e = t.lineWidth % 2 ? .5 : 0;
			t.moveTo(i + e, n), t.lineTo(i + e, s), t.stroke();
		}(t, h, 0, i.height)), r && o >= 0 && (t.lineWidth = Math.floor(this.qt.Kt.ct * s), t.strokeStyle = this.qt.Kt.R, t.fillStyle = this.qt.Kt.R, a(t, this.qt.Kt.Gt), l(t, o, 0, i.width));
	}
};
var A = class {
	constructor(t, i) {
		this.xt = !0, this.Zt = {
			Yt: {
				ct: 1,
				Gt: 0,
				R: "",
				It: !1
			},
			Kt: {
				ct: 1,
				Gt: 0,
				R: "",
				It: !1
			},
			_t: 0,
			ut: 0
		}, this.Xt = new E(this.Zt), this.Jt = t, this.yt = i;
	}
	Pt() {
		this.xt = !0;
	}
	Tt(t) {
		return this.xt && (this.Rt(), this.xt = !1), this.Xt;
	}
	Rt() {
		const t = this.Jt.It(), i = this.yt.Qt().N().crosshair, n = this.Zt;
		if (2 === i.mode) return n.Kt.It = !1, void (n.Yt.It = !1);
		n.Kt.It = t && this.Jt.ti(this.yt), n.Yt.It = t && this.Jt.ii(), n.Kt.ct = i.horzLine.width, n.Kt.Gt = i.horzLine.style, n.Kt.R = i.horzLine.color, n.Yt.ct = i.vertLine.width, n.Yt.Gt = i.vertLine.style, n.Yt.R = i.vertLine.color, n._t = this.Jt.ni(), n.ut = this.Jt.si();
	}
};
function L(t, i, n, s, e, r) {
	t.fillRect(i + r, n, s - 2 * r, r), t.fillRect(i + r, n + e - r, s - 2 * r, r), t.fillRect(i, n, r, e), t.fillRect(i + s - r, n, r, e);
}
function z(t, i, n, s, e, r) {
	t.save(), t.globalCompositeOperation = "copy", t.fillStyle = r, t.fillRect(i, n, s, e), t.restore();
}
function O(t, i, n, s, e, r) {
	t.beginPath(), t.roundRect ? t.roundRect(i, n, s, e, r) : (t.lineTo(i + s - r[1], n), 0 !== r[1] && t.arcTo(i + s, n, i + s, n + r[1], r[1]), t.lineTo(i + s, n + e - r[2]), 0 !== r[2] && t.arcTo(i + s, n + e, i + s - r[2], n + e, r[2]), t.lineTo(i + r[3], n + e), 0 !== r[3] && t.arcTo(i, n + e, i, n + e - r[3], r[3]), t.lineTo(i, n + r[0]), 0 !== r[0] && t.arcTo(i, n, i + r[0], n, r[0]));
}
function N(t, i, n, s, e, r, h = 0, a = [
	0,
	0,
	0,
	0
], l = "") {
	if (t.save(), !h || !l || l === r) return O(t, i, n, s, e, a), t.fillStyle = r, t.fill(), void t.restore();
	const o = h / 2;
	var _;
	O(t, i + o, n + o, s - h, e - h, (_ = -o, a.map(((t) => 0 === t ? t : t + _)))), "transparent" !== r && (t.fillStyle = r, t.fill()), "transparent" !== l && (t.lineWidth = h, t.strokeStyle = l, t.closePath(), t.stroke()), t.restore();
}
function F(t, i, n, s, e, r, h) {
	t.save(), t.globalCompositeOperation = "copy";
	const a = t.createLinearGradient(0, 0, 0, e);
	a.addColorStop(0, r), a.addColorStop(1, h), t.fillStyle = a, t.fillRect(i, n, s, e), t.restore();
}
var W = class {
	constructor(t, i) {
		this.ht(t, i);
	}
	ht(t, i) {
		this.qt = t, this.ei = i;
	}
	$t(t, i) {
		return this.qt.It ? t.P + t.A + t.I : 0;
	}
	st(t, i, n, s) {
		if (!this.qt.It || 0 === this.qt.ri.length) return;
		const e = this.qt.R, r = this.ei.Z, h = t.useBitmapCoordinateSpace(((t) => {
			const h = t.context;
			h.font = i.k;
			const a = this.hi(t, i, n, s), l = a.ai;
			return a.li ? N(h, l.oi, l._i, l.ui, l.ci, r, l.di, [
				l.ft,
				0,
				0,
				l.ft
			], r) : N(h, l.fi, l._i, l.ui, l.ci, r, l.di, [
				0,
				l.ft,
				l.ft,
				0
			], r), this.qt.pi && (h.fillStyle = e, h.fillRect(l.fi, l.mi, l.wi - l.fi, l.Mi)), this.qt.gi && (h.fillStyle = i.D, h.fillRect(a.li ? l.bi - l.di : 0, l._i, l.di, l.Si - l._i)), a;
		}));
		t.useMediaCoordinateSpace((({ context: t }) => {
			const n = h.xi;
			t.font = i.k, t.textAlign = h.li ? "right" : "left", t.textBaseline = "middle", t.fillStyle = e, t.fillText(this.qt.ri, n.Ci, (n._i + n.Si) / 2 + n.yi);
		}));
	}
	hi(t, i, n, s) {
		const { context: e, bitmapSize: r, mediaSize: h, horizontalPixelRatio: a, verticalPixelRatio: l } = t, o = this.qt.pi || !this.qt.Pi ? i.C : 0, _ = this.qt.ki ? i.S : 0, u = i.A + this.ei.Ti, c = i.I + this.ei.Ri, d = i.V, f = i.B, p = this.qt.ri, v = i.P, m = n.Di(e, p), w = Math.ceil(n.Ii(e, p)), M = v + u + c, g = i.S + d + f + w + o, b = Math.max(1, Math.floor(l));
		let S = Math.round(M * l);
		S % 2 != b % 2 && (S += 1);
		const x = _ > 0 ? Math.max(1, Math.floor(_ * a)) : 0, C = Math.round(g * a), y = Math.round(o * a), P = this.ei.Vi ?? this.ei.Bi ?? this.ei.Ei, k = Math.round(P * l) - Math.floor(.5 * l), T = Math.floor(k + b / 2 - S / 2), R = T + S, D = "right" === s, I = D ? h.width - _ : _, V = D ? r.width - x : x;
		let B, E, A;
		return D ? (B = V - C, E = V - y, A = I - o - d - _) : (B = V + C, E = V + y, A = I + o + d), {
			li: D,
			ai: {
				_i: T,
				mi: k,
				Si: R,
				ui: C,
				ci: S,
				ft: 2 * a,
				di: x,
				oi: B,
				fi: V,
				wi: E,
				Mi: b,
				bi: r.width
			},
			xi: {
				_i: T / l,
				Si: R / l,
				Ci: A,
				yi: m
			}
		};
	}
};
var H = class {
	constructor(t) {
		this.Ai = {
			Ei: 0,
			Z: "#000",
			Ri: 0,
			Ti: 0
		}, this.Li = {
			ri: "",
			It: !1,
			pi: !0,
			Pi: !1,
			Ht: "",
			R: "#FFF",
			gi: !1,
			ki: !1
		}, this.zi = {
			ri: "",
			It: !1,
			pi: !1,
			Pi: !0,
			Ht: "",
			R: "#FFF",
			gi: !0,
			ki: !0
		}, this.xt = !0, this.Oi = new (t || W)(this.Li, this.Ai), this.Ni = new (t || W)(this.zi, this.Ai);
	}
	ri() {
		return this.Fi(), this.Li.ri;
	}
	Ei() {
		return this.Fi(), this.Ai.Ei;
	}
	Pt() {
		this.xt = !0;
	}
	$t(t, i = !1) {
		return Math.max(this.Oi.$t(t, i), this.Ni.$t(t, i));
	}
	Wi() {
		return this.Ai.Vi ?? null;
	}
	Hi() {
		return this.Ai.Vi ?? this.Ai.Bi ?? this.Ei();
	}
	Ui(t) {
		this.Ai.Bi = t ?? void 0;
	}
	$i() {
		return this.Fi(), this.Li.It || this.zi.It;
	}
	ji() {
		return this.Fi(), this.Li.It;
	}
	Tt(t) {
		return this.Fi(), this.Li.pi = this.Li.pi && t.N().ticksVisible, this.zi.pi = this.zi.pi && t.N().ticksVisible, this.Oi.ht(this.Li, this.Ai), this.Ni.ht(this.zi, this.Ai), this.Oi;
	}
	qi() {
		return this.Fi(), this.Oi.ht(this.Li, this.Ai), this.Ni.ht(this.zi, this.Ai), this.Ni;
	}
	Fi() {
		this.xt && (this.Li.pi = !0, this.zi.pi = !1, this.Yi(this.Li, this.zi, this.Ai));
	}
};
var U = class extends H {
	constructor(t, i, n) {
		super(), this.Jt = t, this.Ki = i, this.Gi = n;
	}
	Yi(t, i, n) {
		if (t.It = !1, 2 === this.Jt.N().mode) return;
		const s = this.Jt.N().horzLine;
		if (!s.labelVisible) return;
		const e = this.Ki.Lt();
		if (!this.Jt.It() || this.Ki.Zi() || null === e) return;
		const r = this.Ki.Xi().G(s.labelBackgroundColor);
		n.Z = r.Z, t.R = r.X;
		const h = 2 / 12 * this.Ki.P();
		n.Ti = h, n.Ri = h;
		const a = this.Gi(this.Ki);
		n.Ei = a.Ei, t.ri = this.Ki.Ji(a.Mt, e), t.It = !0;
	}
};
var $ = /[1-9]/g;
var j = class {
	constructor() {
		this.qt = null;
	}
	ht(t) {
		this.qt = t;
	}
	st(t, i) {
		if (null === this.qt || !1 === this.qt.It || 0 === this.qt.ri.length) return;
		const n = t.useMediaCoordinateSpace((({ context: t }) => (t.font = i.k, Math.round(i.Qi.Ii(t, u(this.qt).ri, $)))));
		if (n <= 0) return;
		const s = i.tn, e = n + 2 * s, r = e / 2, h = this.qt.nn;
		let a = this.qt.Ei, l = Math.floor(a - r) + .5;
		l < 0 ? (a += Math.abs(0 - l), l = Math.floor(a - r) + .5) : l + e > h && (a -= Math.abs(h - (l + e)), l = Math.floor(a - r) + .5);
		const o = l + e, _ = Math.ceil(0 + i.S + i.C + i.A + i.P + i.I);
		t.useBitmapCoordinateSpace((({ context: t, horizontalPixelRatio: n, verticalPixelRatio: s }) => {
			const e = u(this.qt);
			t.fillStyle = e.Z;
			const r = Math.round(l * n), h = Math.round(0 * s), a = Math.round(o * n), c = Math.round(_ * s), d = Math.round(2 * n);
			if (t.beginPath(), t.moveTo(r, h), t.lineTo(r, c - d), t.arcTo(r, c, r + d, c, d), t.lineTo(a - d, c), t.arcTo(a, c, a, c - d, d), t.lineTo(a, h), t.fill(), e.pi) {
				const r = Math.round(e.Ei * n), a = h, l = Math.round((a + i.C) * s);
				t.fillStyle = e.R;
				const o = Math.max(1, Math.floor(n)), _ = Math.floor(.5 * n);
				t.fillRect(r - _, a, o, l - a);
			}
		})), t.useMediaCoordinateSpace((({ context: t }) => {
			const n = u(this.qt), e = 0 + i.S + i.C + i.A + i.P / 2;
			t.font = i.k, t.textAlign = "left", t.textBaseline = "middle", t.fillStyle = n.R;
			const r = i.Qi.Di(t, "Apr0");
			t.translate(l + s, e + r), t.fillText(n.ri, 0, 0);
		}));
	}
};
var q = class {
	constructor(t, i, n) {
		this.xt = !0, this.Xt = new j(), this.Zt = {
			It: !1,
			Z: "#4c525e",
			R: "white",
			ri: "",
			nn: 0,
			Ei: NaN,
			pi: !0
		}, this.Ct = t, this.sn = i, this.Gi = n;
	}
	Pt() {
		this.xt = !0;
	}
	Tt() {
		return this.xt && (this.Rt(), this.xt = !1), this.Xt.ht(this.Zt), this.Xt;
	}
	Rt() {
		const t = this.Zt;
		if (t.It = !1, 2 === this.Ct.N().mode) return;
		const i = this.Ct.N().vertLine;
		if (!i.labelVisible) return;
		const n = this.sn.Et();
		if (n.Zi()) return;
		t.nn = n.nn();
		const s = this.Gi();
		if (null === s) return;
		t.Ei = s.Ei;
		const e = n.en(this.Ct.Bt());
		t.ri = n.rn(u(e)), t.It = !0;
		const r = this.sn.Xi().G(i.labelBackgroundColor);
		t.Z = r.Z, t.R = r.X, t.pi = n.N().ticksVisible;
	}
};
var Y = class {
	constructor() {
		this.hn = null, this.an = 0;
	}
	ln() {
		return this.an;
	}
	_n(t) {
		this.an = t;
	}
	Ft() {
		return this.hn;
	}
	un(t) {
		this.hn = t;
	}
	cn(t) {
		return [];
	}
	dn() {
		return [];
	}
	It() {
		return !0;
	}
};
var K;
(function(t) {
	t[t.Normal = 0] = "Normal", t[t.Magnet = 1] = "Magnet", t[t.Hidden = 2] = "Hidden", t[t.MagnetOHLC = 3] = "MagnetOHLC";
})(K || (K = {}));
var G = class extends Y {
	constructor(t, i) {
		super(), this.yt = null, this.fn = NaN, this.pn = 0, this.vn = !1, this.mn = /* @__PURE__ */ new Map(), this.wn = !1, this.Mn = /* @__PURE__ */ new WeakMap(), this.gn = /* @__PURE__ */ new WeakMap(), this.bn = NaN, this.Sn = NaN, this.xn = NaN, this.Cn = NaN, this.sn = t, this.yn = i;
		this.Pn = ((t, i) => (n) => {
			const s = i(), e = t();
			if (n === u(this.yt).kn()) return {
				Mt: e,
				Ei: s
			};
			{
				const t = u(n.Lt());
				return {
					Mt: n.Tn(s, t),
					Ei: s
				};
			}
		})((() => this.fn), (() => this.Sn));
		const n = ((t, i) => () => {
			const n = this.sn.Et().Rn(t()), s = i();
			return n && Number.isFinite(s) ? {
				wt: n,
				Ei: s
			} : null;
		})((() => this.pn), (() => this.ni()));
		this.Dn = new q(this, t, n);
	}
	N() {
		return this.yn;
	}
	In(t, i) {
		this.xn = t, this.Cn = i;
	}
	Vn() {
		this.xn = NaN, this.Cn = NaN;
	}
	Bn() {
		return this.xn;
	}
	En() {
		return this.Cn;
	}
	An(t, i, n) {
		this.wn || (this.wn = !0), this.vn = !0, this.Ln(t, i, n);
	}
	Bt() {
		return this.pn;
	}
	ni() {
		return this.bn;
	}
	si() {
		return this.Sn;
	}
	It() {
		return this.vn;
	}
	zn() {
		this.vn = !1, this.On(), this.fn = NaN, this.bn = NaN, this.Sn = NaN, this.yt = null, this.Vn(), this.Nn();
	}
	Fn(t) {
		if (!this.yn.doNotSnapToHiddenSeriesIndices) return t;
		const i = this.sn, n = i.Et();
		let s = null, e = null;
		for (const n of i.Wn()) {
			const i = n.Un().Hn(t, -1);
			if (i) {
				if (i.$n === t) return t;
				(null === s || i.$n > s) && (s = i.$n);
			}
			const r = n.Un().Hn(t, 1);
			if (r) {
				if (r.$n === t) return t;
				(null === e || r.$n < e) && (e = r.$n);
			}
		}
		const r = [s, e].filter(g);
		if (0 === r.length) return t;
		const h = n.jt(t), a = r.map(((t) => Math.abs(h - n.jt(t))));
		return r[a.indexOf(Math.min(...a))];
	}
	jn(t) {
		let i = this.Mn.get(t);
		i || (i = new A(this, t), this.Mn.set(t, i));
		let n = this.gn.get(t);
		return n || (n = new B(this.sn, this, t), this.gn.set(t, n)), [i, n];
	}
	ti(t) {
		return t === this.yt && this.yn.horzLine.visible;
	}
	ii() {
		return this.yn.vertLine.visible;
	}
	qn(t, i) {
		this.vn && this.yt === t || this.mn.clear();
		const n = [];
		return this.yt === t && n.push(this.Yn(this.mn, i, this.Pn)), n;
	}
	dn() {
		return this.vn ? [this.Dn] : [];
	}
	Kn() {
		return this.yt;
	}
	Nn() {
		this.sn.Gn().forEach(((t) => {
			this.Mn.get(t)?.Pt(), this.gn.get(t)?.Pt();
		})), this.mn.forEach(((t) => t.Pt())), this.Dn.Pt();
	}
	Zn(t) {
		return t && !t.kn().Zi() ? t.kn() : null;
	}
	Ln(t, i, n) {
		this.Xn(t, i, n) && this.Nn();
	}
	Xn(t, i, n) {
		const s = this.bn, e = this.Sn, r = this.fn, h = this.pn, a = this.yt, l = this.Zn(n);
		this.pn = t, this.bn = isNaN(t) ? NaN : this.sn.Et().jt(t), this.yt = n;
		const o = null !== l ? l.Lt() : null;
		return null !== l && null !== o ? (this.fn = i, this.Sn = l.Nt(i, o)) : (this.fn = NaN, this.Sn = NaN), s !== this.bn || e !== this.Sn || h !== this.pn || r !== this.fn || a !== this.yt;
	}
	On() {
		const t = this.sn.Jn().map(((t) => t.Un().Qn())).filter(g), i = 0 === t.length ? null : Math.max(...t);
		this.pn = null !== i ? i : NaN;
	}
	Yn(t, i, n) {
		let s = t.get(i);
		return void 0 === s && (s = new U(this, i, n), t.set(i, s)), s;
	}
};
function Z(t) {
	return "left" === t || "right" === t;
}
var X = class X {
	constructor(t) {
		this.ts = /* @__PURE__ */ new Map(), this.ns = [], this.ss = t;
	}
	es(t, i) {
		const n = function(t, i) {
			return void 0 === t ? i : {
				rs: Math.max(t.rs, i.rs),
				hs: t.hs || i.hs
			};
		}(this.ts.get(t), i);
		this.ts.set(t, n);
	}
	ls() {
		return this.ss;
	}
	_s(t) {
		const i = this.ts.get(t);
		return void 0 === i ? { rs: this.ss } : {
			rs: Math.max(this.ss, i.rs),
			hs: i.hs
		};
	}
	us() {
		this.cs(), this.ns = [{ ds: 0 }];
	}
	fs(t) {
		this.cs(), this.ns = [{
			ds: 1,
			Wt: t
		}];
	}
	ps(t) {
		this.vs(), this.ns.push({
			ds: 5,
			Wt: t
		});
	}
	cs() {
		this.vs(), this.ns.push({ ds: 6 });
	}
	ws() {
		this.cs(), this.ns = [{ ds: 4 }];
	}
	Ms(t) {
		this.cs(), this.ns.push({
			ds: 2,
			Wt: t
		});
	}
	gs(t) {
		this.cs(), this.ns.push({
			ds: 3,
			Wt: t
		});
	}
	bs() {
		return this.ns;
	}
	Ss(t) {
		for (const i of t.ns) this.xs(i);
		this.ss = Math.max(this.ss, t.ss), t.ts.forEach(((t, i) => {
			this.es(i, t);
		}));
	}
	static Cs() {
		return new X(2);
	}
	static ys() {
		return new X(3);
	}
	xs(t) {
		switch (t.ds) {
			case 0:
				this.us();
				break;
			case 1:
				this.fs(t.Wt);
				break;
			case 2:
				this.Ms(t.Wt);
				break;
			case 3:
				this.gs(t.Wt);
				break;
			case 4:
				this.ws();
				break;
			case 5:
				this.ps(t.Wt);
				break;
			case 6: this.vs();
		}
	}
	vs() {
		const t = this.ns.findIndex(((t) => 5 === t.ds));
		-1 !== t && this.ns.splice(t, 1);
	}
};
var J = class {
	formatTickmarks(t) {
		return t.map(((t) => this.format(t)));
	}
};
var Q = ".";
function tt(t, i) {
	if (!p(t)) return "n/a";
	if (!v(i)) throw new TypeError("invalid length");
	if (i < 0 || i > 16) throw new TypeError("invalid length");
	if (0 === i) return t.toString();
	return ("0000000000000000" + t.toString()).slice(-i);
}
var it = class extends J {
	constructor(t, i) {
		if (super(), i || (i = 1), p(t) && v(t) || (t = 100), t < 0) throw new TypeError("invalid base");
		this.Ki = t, this.Ps = i, this.ks();
	}
	format(t) {
		const i = t < 0 ? "−" : "";
		return t = Math.abs(t), i + this.Ts(t);
	}
	ks() {
		if (this.Rs = 0, this.Ki > 0 && this.Ps > 0) {
			let t = this.Ki;
			for (; t > 1;) t /= 10, this.Rs++;
		}
	}
	Ts(t) {
		const i = this.Ki / this.Ps;
		let n = Math.floor(t), s = "";
		const e = void 0 !== this.Rs ? this.Rs : NaN;
		if (i > 1) {
			let r = +(Math.round(t * i) - n * i).toFixed(this.Rs);
			r >= i && (r -= i, n += 1), s = Q + tt(+r.toFixed(this.Rs) * this.Ps, e);
		} else n = Math.round(n * i) / i, e > 0 && (s = Q + tt(0, e));
		return n.toFixed(0) + s;
	}
};
var nt = class extends it {
	constructor(t = 100) {
		super(t);
	}
	format(t) {
		return `${super.format(t)}%`;
	}
};
var st = class extends J {
	constructor(t) {
		super(), this.Ds = t;
	}
	format(t) {
		let i = "";
		return t < 0 && (i = "-", t = -t), t < 995 ? i + this.Is(t) : t < 999995 ? i + this.Is(t / 1e3) + "K" : t < 999999995 ? (t = 1e3 * Math.round(t / 1e3), i + this.Is(t / 1e6) + "M") : (t = 1e6 * Math.round(t / 1e6), i + this.Is(t / 1e9) + "B");
	}
	Is(t) {
		let i;
		const n = Math.pow(10, this.Ds);
		return i = (t = Math.round(t * n) / n) >= 1e-15 && t < 1 ? t.toFixed(this.Ds).replace(/\.?0+$/, "") : String(t), i.replace(/(\.[1-9]*)0+$/, ((t, i) => i));
	}
};
var et = /[2-9]/g;
var rt = class {
	constructor(t = 50) {
		this.Vs = 0, this.Bs = 1, this.Es = 1, this.As = {}, this.Ls = /* @__PURE__ */ new Map(), this.zs = t;
	}
	Os() {
		this.Vs = 0, this.Ls.clear(), this.Bs = 1, this.Es = 1, this.As = {};
	}
	Ii(t, i, n) {
		return this.Ns(t, i, n).width;
	}
	Di(t, i, n) {
		const s = this.Ns(t, i, n);
		return ((s.actualBoundingBoxAscent || 0) - (s.actualBoundingBoxDescent || 0)) / 2;
	}
	Ns(t, i, n) {
		const s = n || et, e = String(i).replace(s, "0");
		if (this.Ls.has(e)) return _(this.Ls.get(e)).Fs;
		if (this.Vs === this.zs) {
			const t = this.As[this.Es];
			delete this.As[this.Es], this.Ls.delete(t), this.Es++, this.Vs--;
		}
		t.save(), t.textBaseline = "middle";
		const r = t.measureText(e);
		return t.restore(), 0 === r.width && i.length || (this.Ls.set(e, {
			Fs: r,
			Ws: this.Bs
		}), this.As[this.Bs] = e, this.Vs++, this.Bs++), r;
	}
};
var ht = class {
	constructor(t) {
		this.Hs = null, this.M = null, this.Us = "right", this.$s = t;
	}
	js(t, i, n) {
		this.Hs = t, this.M = i, this.Us = n;
	}
	st(t) {
		null !== this.M && null !== this.Hs && this.Hs.st(t, this.M, this.$s, this.Us);
	}
};
var at = class {
	constructor(t, i, n) {
		this.qs = t, this.$s = new rt(50), this.Ys = i, this.O = n, this.F = -1, this.Xt = new ht(this.$s);
	}
	Tt() {
		const t = this.O.Ks(this.Ys);
		if (null === t) return null;
		const i = t.Gs(this.Ys) ? t.Zs() : this.Ys.Ft();
		if (null === i) return null;
		const n = t.Xs(i);
		if ("overlay" === n) return null;
		const s = this.O.Js();
		return s.P !== this.F && (this.F = s.P, this.$s.Os()), this.Xt.js(this.qs.qi(), s, n), this.Xt;
	}
};
var lt = class extends R {
	constructor() {
		super(...arguments), this.qt = null;
	}
	ht(t) {
		this.qt = t;
	}
	Qs(t, i) {
		if (!this.qt?.It) return null;
		const { ut: n, ct: s, te: e } = this.qt;
		return i >= n - s - 7 && i <= n + s + 7 ? {
			ie: this.qt,
			ne: Math.abs(i - n),
			se: 2,
			ee: "price-line",
			te: e
		} : null;
	}
	et({ context: t, bitmapSize: i, horizontalPixelRatio: n, verticalPixelRatio: s }) {
		if (null === this.qt) return;
		if (!1 === this.qt.It) return;
		const e = Math.round(this.qt.ut * s);
		e < 0 || e > i.height || (t.lineCap = "butt", t.strokeStyle = this.qt.R, t.lineWidth = Math.floor(this.qt.ct * n), a(t, this.qt.Gt), l(t, e, 0, i.width));
	}
};
var ot = class {
	constructor(t) {
		this.re = {
			ut: 0,
			R: "rgba(0, 0, 0, 0)",
			ct: 1,
			Gt: 0,
			It: !1
		}, this.he = new lt(), this.xt = !0, this.ae = t, this.le = t.Qt(), this.he.ht(this.re);
	}
	Pt() {
		this.xt = !0;
	}
	Tt() {
		return this.ae.It() ? (this.xt && (this.oe(), this.xt = !1), this.he) : null;
	}
};
var _t = class extends ot {
	constructor(t) {
		super(t);
	}
	oe() {
		this.re.It = !1;
		const t = this.ae.Ft(), i = t._e()._e;
		if (2 !== i && 3 !== i) return;
		const n = this.ae.N();
		if (!n.baseLineVisible || !this.ae.It()) return;
		const s = this.ae.Lt();
		null !== s && (this.re.It = !0, this.re.ut = t.Nt(s.Wt, s.Wt), this.re.R = n.baseLineColor, this.re.ct = n.baseLineWidth, this.re.Gt = n.baseLineStyle);
	}
};
var ut = class extends R {
	constructor() {
		super(...arguments), this.qt = null;
	}
	ht(t) {
		this.qt = t;
	}
	ue() {
		return this.qt;
	}
	et({ context: t, horizontalPixelRatio: i, verticalPixelRatio: n }) {
		const s = this.qt;
		if (null === s) return;
		const e = Math.max(1, Math.floor(i)), r = e % 2 / 2, h = Math.round(s.ce.x * i) + r, a = s.ce.y * n;
		t.fillStyle = s.de, t.beginPath();
		const l = Math.max(2, 1.5 * s.fe) * i;
		t.arc(h, a, l, 0, 2 * Math.PI, !1), t.fill(), t.fillStyle = s.pe, t.beginPath(), t.arc(h, a, s.ft * i, 0, 2 * Math.PI, !1), t.fill(), t.lineWidth = e, t.strokeStyle = s.ve, t.beginPath(), t.arc(h, a, s.ft * i + e / 2, 0, 2 * Math.PI, !1), t.stroke();
	}
};
var ct = [
	{
		me: 0,
		we: .25,
		Me: 4,
		ge: 10,
		be: .25,
		Se: 0,
		xe: .4,
		Ce: .8
	},
	{
		me: .25,
		we: .525,
		Me: 10,
		ge: 14,
		be: 0,
		Se: 0,
		xe: .8,
		Ce: 0
	},
	{
		me: .525,
		we: 1,
		Me: 14,
		ge: 14,
		be: 0,
		Se: 0,
		xe: 0,
		Ce: 0
	}
];
var dt = class {
	constructor(t) {
		this.Xt = new ut(), this.xt = !0, this.ye = !0, this.Pe = performance.now(), this.ke = this.Pe - 1, this.Te = t;
	}
	Re() {
		this.ke = this.Pe - 1, this.Pt();
	}
	De() {
		if (this.Pt(), 2 === this.Te.N().lastPriceAnimation) {
			const t = performance.now(), i = this.ke - t;
			if (i > 0) return void (i < 650 && (this.ke += 2600));
			this.Pe = t, this.ke = t + 2600;
		}
	}
	Pt() {
		this.xt = !0;
	}
	Ie() {
		this.ye = !0;
	}
	It() {
		return 0 !== this.Te.N().lastPriceAnimation;
	}
	Ve() {
		switch (this.Te.N().lastPriceAnimation) {
			case 0: return !1;
			case 1: return !0;
			case 2: return performance.now() <= this.ke;
		}
	}
	Tt() {
		return this.xt ? (this.Rt(), this.xt = !1, this.ye = !1) : this.ye && (this.Be(), this.ye = !1), this.Xt;
	}
	Rt() {
		this.Xt.ht(null);
		const t = this.Te.Qt().Et(), i = t.Ee(), n = this.Te.Lt();
		if (null === i || null === n) return;
		const s = this.Te.Ae(!0);
		if (s.Le || !i.ze(s.$n)) return;
		const e = {
			x: t.jt(s.$n),
			y: this.Te.Ft().Nt(s.Mt, n.Wt)
		}, r = s.R, h = this.Te.N().lineWidth, a = this.Oe(this.Ne(), r);
		this.Xt.ht({
			de: r,
			fe: h,
			pe: a.pe,
			ve: a.ve,
			ft: a.ft,
			ce: e
		});
	}
	Be() {
		const t = this.Xt.ue();
		if (null !== t) {
			const i = this.Oe(this.Ne(), t.de);
			t.pe = i.pe, t.ve = i.ve, t.ft = i.ft;
		}
	}
	Ne() {
		return this.Ve() ? performance.now() - this.Pe : 2599;
	}
	Fe(t, i, n, s) {
		const e = n + (s - n) * i;
		return this.Te.Qt().Xi().Y(t, e);
	}
	Oe(t, i) {
		const n = t % 2600 / 2600;
		let s;
		for (const t of ct) if (n >= t.me && n <= t.we) {
			s = t;
			break;
		}
		o(void 0 !== s, "Last price animation internal logic error");
		const e = (n - s.me) / (s.we - s.me);
		return {
			pe: this.Fe(i, e, s.be, s.Se),
			ve: this.Fe(i, e, s.xe, s.Ce),
			ft: (r = e, h = s.Me, a = s.ge, h + (a - h) * r)
		};
		var r, h, a;
	}
};
var ft = class extends ot {
	constructor(t) {
		super(t);
	}
	oe() {
		const t = this.re;
		t.It = !1;
		const i = this.ae.N();
		if (!i.priceLineVisible || !this.ae.It()) return;
		const n = this.ae.Ae(0 === i.priceLineSource);
		n.Le || (t.It = !0, t.ut = n.Ei, t.R = this.ae.We(n.R), t.ct = i.priceLineWidth, t.Gt = i.priceLineStyle);
	}
};
var pt = class extends H {
	constructor(t) {
		super(), this.Jt = t;
	}
	Yi(t, i, n) {
		t.It = !1, i.It = !1;
		const s = this.Jt;
		if (!s.It()) return;
		const e = s.N(), r = e.lastValueVisible, h = "" !== s.He(), a = 0 === e.seriesLastValueMode, l = s.Ae(!1);
		if (l.Le) return;
		r && (t.ri = this.Ue(l, r, a), t.It = 0 !== t.ri.length), (h || a) && (i.ri = this.$e(l, r, h, a), i.It = i.ri.length > 0);
		const o = s.We(l.R), _ = this.Jt.Qt().Xi().G(o);
		n.Z = _.Z, n.Ei = l.Ei, i.Ht = s.Qt().Ut(l.Ei / s.Ft().$t()), t.Ht = o, t.R = _.X, i.R = _.X;
	}
	$e(t, i, n, s) {
		let e = "";
		const r = this.Jt.He();
		return n && 0 !== r.length && (e += `${r} `), i && s && (e += this.Jt.Ft().je() ? t.qe : t.Ye), e.trim();
	}
	Ue(t, i, n) {
		return i ? n ? this.Jt.Ft().je() ? t.Ye : t.qe : t.ri : "";
	}
};
function vt(t, i, n, s) {
	const e = Number.isFinite(i), r = Number.isFinite(n);
	return e && r ? t(i, n) : e || r ? e ? i : n : s;
}
var mt = class mt {
	constructor(t, i) {
		this.Ke = t, this.Ge = i;
	}
	Ze(t) {
		return null !== t && this.Ke === t.Ke && this.Ge === t.Ge;
	}
	Xe() {
		return new mt(this.Ke, this.Ge);
	}
	Je() {
		return this.Ke;
	}
	Qe() {
		return this.Ge;
	}
	tr() {
		return this.Ge - this.Ke;
	}
	Zi() {
		return this.Ge === this.Ke || Number.isNaN(this.Ge) || Number.isNaN(this.Ke);
	}
	Ss(t) {
		return null === t ? this : new mt(vt(Math.min, this.Je(), t.Je(), -1 / 0), vt(Math.max, this.Qe(), t.Qe(), 1 / 0));
	}
	ir(t) {
		if (!p(t)) return;
		if (0 === this.Ge - this.Ke) return;
		const i = .5 * (this.Ge + this.Ke);
		let n = this.Ge - i, s = this.Ke - i;
		n *= t, s *= t, this.Ge = i + n, this.Ke = i + s;
	}
	nr(t) {
		p(t) && (this.Ge += t, this.Ke += t);
	}
	sr() {
		return {
			minValue: this.Ke,
			maxValue: this.Ge
		};
	}
	static er(t) {
		return null === t ? null : new mt(t.minValue, t.maxValue);
	}
};
var wt = class wt {
	constructor(t, i) {
		this.rr = t, this.hr = i || null;
	}
	ar() {
		return this.rr;
	}
	lr() {
		return this.hr;
	}
	sr() {
		return {
			priceRange: null === this.rr ? null : this.rr.sr(),
			margins: this.hr || void 0
		};
	}
	static er(t) {
		return null === t ? null : new wt(mt.er(t.priceRange), t.margins);
	}
};
var Mt = [
	2,
	4,
	8,
	16,
	32,
	64,
	128,
	256,
	512
];
var gt = "Custom series with conflation reducer must have a priceValueBuilder method";
var bt = class extends ot {
	constructor(t, i) {
		super(t), this._r = i;
	}
	oe() {
		const t = this.re;
		t.It = !1;
		const i = this._r.N();
		if (!this.ae.It() || !i.lineVisible) return;
		const n = this._r.ur();
		null !== n && (t.It = !0, t.ut = n, t.R = i.color, t.ct = i.lineWidth, t.Gt = i.lineStyle, t.te = this._r.N().id);
	}
};
var St = class extends H {
	constructor(t, i) {
		super(), this.Te = t, this._r = i;
	}
	Yi(t, i, n) {
		t.It = !1, i.It = !1;
		const s = this._r.N(), e = s.axisLabelVisible, r = "" !== s.title, h = this.Te;
		if (!e || !h.It()) return;
		const a = this._r.ur();
		if (null === a) return;
		r && (i.ri = s.title, i.It = !0), i.Ht = h.Qt().Ut(a / h.Ft().$t()), t.ri = this.cr(s.price), t.It = !0;
		const l = this.Te.Qt().Xi().G(s.axisLabelColor || s.color);
		n.Z = l.Z;
		const o = s.axisLabelTextColor || l.X;
		t.R = o, i.R = o, n.Ei = a;
	}
	cr(t) {
		const i = this.Te.Lt();
		return null === i ? "" : this.Te.Ft().Ji(t, i.Wt);
	}
};
var xt = class {
	constructor(t, i) {
		this.Te = t, this.yn = i, this.dr = new bt(t, this), this.qs = new St(t, this), this.pr = new at(this.qs, t, t.Qt());
	}
	vr(t) {
		f(this.yn, t), this.Pt(), this.Te.Qt().mr();
	}
	N() {
		return this.yn;
	}
	wr() {
		return this.dr;
	}
	Mr() {
		return this.pr;
	}
	gr() {
		return this.qs;
	}
	Pt() {
		this.dr.Pt(), this.qs.Pt();
	}
	ur() {
		const t = this.Te, i = t.Ft();
		if (t.Qt().Et().Zi() || i.Zi()) return null;
		const n = t.Lt();
		return null === n ? null : i.Nt(this.yn.price, n.Wt);
	}
};
var Ct = class {
	constructor() {
		this.br = /* @__PURE__ */ new WeakMap();
	}
	Sr(t, i, n) {
		const s = 1 / i * n;
		if (t >= s) return 1;
		const e = s / t;
		return Math.min(Math.pow(2, Math.floor(Math.log2(e))), 512);
	}
	Cr(t, i, n, s = !1, e) {
		if (0 === t.length || i <= 1) return t;
		const r = this.yr(i);
		if (r <= 1) return t;
		const h = this.Pr(t);
		let a = h.kr.get(r);
		return void 0 !== a || (a = this.Tr(t, r, n, s, e, h.kr), h.kr.set(r, a)), a;
	}
	Rr(t, i, n, s, e = !1, r) {
		if (n < 1 || 0 === t.length) return t;
		const h = this.Pr(t), a = h.kr.get(n);
		if (!a) return this.Cr(t, n, s, e, r);
		const l = this.Dr(t, i, n, a, e, s, r);
		return h.kr.set(n, l), l;
	}
	yr(t) {
		if (t <= 2) return 2;
		for (const i of Mt) if (t <= i) return i;
		return 512;
	}
	Ir(t) {
		if (0 === t.length) return 0;
		const i = t[0], n = t[t.length - 1];
		return 31 * t.length + 17 * i.$n + 13 * n.$n;
	}
	Tr(t, i, n, s = !1, e, r = /* @__PURE__ */ new Map()) {
		if (2 === i) return this.Vr(t, 2, n, s, e);
		const h = i / 2;
		let a = r.get(h);
		return a || (a = this.Tr(t, h, n, s, e, r), r.set(h, a)), this.Br(a, n, s, e);
	}
	Vr(t, i, n, s = !1, e) {
		const r = this.Er(t, i, n, s, e);
		return this.Ar(r, s);
	}
	Br(t, i, n = !1, s) {
		const e = this.Er(t, 2, i, n, s);
		return this.Ar(e, n);
	}
	Er(t, i, n, s = !1, e) {
		const r = [];
		for (let h = 0; h < t.length; h += i) if (t.length - h >= i) {
			const i = this.Lr(t[h], t[h + 1], n, s, e);
			i.zr = !1, r.push(i);
		} else if (0 === r.length) r.push(this.Or(t[h], !0));
		else {
			const i = r[r.length - 1];
			r[r.length - 1] = this.Nr(i, t[h], n, s, e);
		}
		return r;
	}
	Fr(t, i) {
		return (t ?? 1) + (i ?? 1);
	}
	Lr(t, i, n, s = !1, e) {
		if (!s || !n || !e) {
			const n = t.Wt[1] > i.Wt[1] ? t.Wt[1] : i.Wt[1], s = t.Wt[2] < i.Wt[2] ? t.Wt[2] : i.Wt[2];
			return {
				Wr: t.$n,
				Hr: i.$n,
				Ur: t.wt,
				$r: i.wt,
				jr: t.Wt[0],
				qr: n,
				Yr: s,
				Kr: i.Wt[3],
				Gr: this.Fr(t.Gr, i.Gr),
				Zr: void 0,
				zr: !1
			};
		}
		const r = n(this.Xr(t, e), this.Xr(i, e)), h = e(r), a = h.length ? h[h.length - 1] : 0;
		return {
			Wr: t.$n,
			Hr: i.$n,
			Ur: t.wt,
			$r: i.wt,
			jr: t.Wt[0],
			qr: Math.max(t.Wt[1], a),
			Yr: Math.min(t.Wt[2], a),
			Kr: a,
			Gr: this.Fr(t.Gr, i.Gr),
			Zr: r,
			zr: !1
		};
	}
	Nr(t, i, n, s = !1, e) {
		if (!s || !n || !e) return {
			Wr: t.Wr,
			Hr: i.$n,
			Ur: t.Ur,
			$r: i.wt,
			jr: t.jr,
			qr: t.qr > i.Wt[1] ? t.qr : i.Wt[1],
			Yr: t.Yr < i.Wt[2] ? t.Yr : i.Wt[2],
			Kr: i.Wt[3],
			Gr: t.Gr + (i.Gr ?? 1),
			Zr: t.Zr,
			zr: !1
		};
		const r = t.Zr, h = this.Xr(i, e), a = r ? {
			data: r,
			index: t.Wr,
			originalTime: t.Ur,
			time: t.Ur,
			priceValues: e(r)
		} : null, l = a ? n(a, h) : h.data, o = a ? e(l) : h.priceValues, _ = o.length ? o[o.length - 1] : 0;
		return {
			Wr: t.Wr,
			Hr: i.$n,
			Ur: t.Ur,
			$r: i.wt,
			jr: t.jr,
			qr: Math.max(t.qr, _),
			Yr: Math.min(t.Yr, _),
			Kr: _,
			Gr: t.Gr + (i.Gr ?? 1),
			Zr: l,
			zr: !1
		};
	}
	Jr(t, i, n, s, e, r, h = !1, a) {
		const l = i === s ? e : t[i];
		if (n - i == 1) return this.Or(l, !0);
		const o = i + 1 === s ? e : t[i + 1];
		let _ = this.Lr(l, o, r, h, a);
		for (let l = i + 2; l < n; l++) {
			const i = l === s ? e : t[l];
			_ = this.Nr(_, i, r, h, a);
		}
		return _;
	}
	Xr(t, i) {
		const n = t.ue ?? {};
		return {
			data: t.ue,
			index: t.$n,
			originalTime: t.Qr,
			time: t.wt,
			priceValues: i(n)
		};
	}
	th(t, i = !1) {
		const n = !0 === i, s = !!t.Zr;
		return {
			$n: t.Wr,
			wt: t.Ur,
			Qr: t.Ur,
			Wt: [
				n ? t.Kr : t.jr,
				t.qr,
				t.Yr,
				t.Kr
			],
			Gr: t.Gr,
			ue: n ? s ? t.Zr : { wt: t.Ur } : void 0
		};
	}
	Ar(t, i = !1) {
		return t.map(((t) => this.th(t, i)));
	}
	Dr(t, i, n, s, e = !1, r, h) {
		if (0 === s.length) return s;
		const a = t.length - 1, l = Math.floor(a / n) * n;
		if (Math.min(l + n, t.length) - l < n && t.length > n) {
			const s = t.slice();
			return s[s.length - 1] = i, this.Cr(s, n, r, e, h);
		}
		if (Math.floor((a - 1) / n) === Math.floor(a / n) || 1 === s.length) {
			const o = Math.min(l + n, t.length), _ = o - l;
			if (_ <= 0) return s;
			const u = 1 === _ ? this.Or(l === a ? i : t[l], !0) : this.Jr(t, l, o, a, i, r, e, h);
			return s[s.length - 1] = this.th(u, e), s;
		}
		{
			const s = t.slice();
			return s[s.length - 1] = i, this.Cr(s, n, r, e, h);
		}
	}
	Or(t, i = !1) {
		return {
			Wr: t.$n,
			Hr: t.$n,
			Ur: t.wt,
			$r: t.wt,
			jr: t.Wt[0],
			qr: t.Wt[1],
			Yr: t.Wt[2],
			Kr: t.Wt[3],
			Gr: t.Gr ?? 1,
			Zr: t.ue,
			zr: i
		};
	}
	Pr(t) {
		const i = this.ih(t), n = this.Ir(t);
		return i.nh !== n && (i.kr.clear(), i.nh = n), i;
	}
	ih(t) {
		let i = this.br.get(t);
		return void 0 === i && (i = {
			nh: this.Ir(t),
			kr: /* @__PURE__ */ new Map()
		}, this.br.set(t, i)), i;
	}
};
var yt = class extends Y {
	constructor(t) {
		super(), this.sn = t;
	}
	Qt() {
		return this.sn;
	}
};
var Pt = {
	Bar: (t, i, n, s) => {
		const e = i.upColor, r = i.downColor, h = u(t(n, s)), a = c(h.Wt[0]) <= c(h.Wt[3]);
		return { sh: h.R ?? (a ? e : r) };
	},
	Candlestick: (t, i, n, s) => {
		const e = i.upColor, r = i.downColor, h = i.borderUpColor, a = i.borderDownColor, l = i.wickUpColor, o = i.wickDownColor, _ = u(t(n, s)), d = c(_.Wt[0]) <= c(_.Wt[3]);
		return {
			sh: _.R ?? (d ? e : r),
			eh: _.Ht ?? (d ? h : a),
			rh: _.hh ?? (d ? l : o)
		};
	},
	Custom: (t, i, n, s) => ({ sh: u(t(n, s)).R ?? i.color }),
	Area: (t, i, n, s) => {
		const e = u(t(n, s));
		return {
			sh: e.vt ?? i.lineColor,
			vt: e.vt ?? i.lineColor,
			ah: e.ah ?? i.topColor,
			oh: e.oh ?? i.bottomColor
		};
	},
	Baseline: (t, i, n, s) => {
		const e = u(t(n, s));
		return {
			sh: e.Wt[3] >= i.baseValue.price ? i.topLineColor : i.bottomLineColor,
			_h: e._h ?? i.topLineColor,
			uh: e.uh ?? i.bottomLineColor,
			dh: e.dh ?? i.topFillColor1,
			fh: e.fh ?? i.topFillColor2,
			ph: e.ph ?? i.bottomFillColor1,
			mh: e.mh ?? i.bottomFillColor2
		};
	},
	Line: (t, i, n, s) => {
		const e = u(t(n, s));
		return {
			sh: e.R ?? i.color,
			vt: e.R ?? i.color
		};
	},
	Histogram: (t, i, n, s) => ({ sh: u(t(n, s)).R ?? i.color })
};
var kt = class {
	constructor(t) {
		this.wh = (t, i) => void 0 !== i ? i.Wt : this.Te.Un().Mh(t), this.Te = t, this.gh = Pt[t.bh()];
	}
	Sh(t, i) {
		return this.gh(this.wh, this.Te.N(), t, i);
	}
};
function Tt(t, i, n, s, e = 0, r = i.length) {
	let h = r - e;
	for (; 0 < h;) {
		const r = h >> 1, a = e + r;
		s(i[a], n) === t ? (e = a + 1, h -= r + 1) : h = r;
	}
	return e;
}
var Rt = Tt.bind(null, !0);
var Dt = Tt.bind(null, !1);
var It;
(function(t) {
	t[t.NearestLeft = -1] = "NearestLeft", t[t.None = 0] = "None", t[t.NearestRight = 1] = "NearestRight";
})(It || (It = {}));
var Vt = 30;
var Bt = class {
	constructor() {
		this.xh = [], this.Ch = /* @__PURE__ */ new Map(), this.yh = /* @__PURE__ */ new Map(), this.Ph = [];
	}
	kh() {
		return this.Th() > 0 ? this.xh[this.xh.length - 1] : null;
	}
	Rh() {
		return this.Th() > 0 ? this.Dh(0) : null;
	}
	Qn() {
		return this.Th() > 0 ? this.Dh(this.xh.length - 1) : null;
	}
	Th() {
		return this.xh.length;
	}
	Zi() {
		return 0 === this.Th();
	}
	ze(t) {
		return null !== this.Ih(t, 0);
	}
	Mh(t) {
		return this.Hn(t);
	}
	Hn(t, i = 0) {
		const n = this.Ih(t, i);
		return null === n ? null : {
			...this.Vh(n),
			$n: this.Dh(n)
		};
	}
	Bh() {
		return this.xh;
	}
	Eh(t, i, n) {
		if (this.Zi()) return null;
		let s = null;
		for (const e of n) s = Et(s, this.Ah(t, i, e));
		return s;
	}
	ht(t) {
		this.yh.clear(), this.Ch.clear(), this.xh = t, this.Ph = t.map(((t) => t.$n));
	}
	Lh() {
		return this.Ph;
	}
	Dh(t) {
		return this.xh[t].$n;
	}
	Vh(t) {
		return this.xh[t];
	}
	Ih(t, i) {
		const n = this.zh(t);
		if (null === n && 0 !== i) switch (i) {
			case -1: return this.Oh(t);
			case 1: return this.Nh(t);
			default: throw new TypeError("Unknown search mode");
		}
		return n;
	}
	Oh(t) {
		let i = this.Fh(t);
		return i > 0 && (i -= 1), i !== this.xh.length && this.Dh(i) < t ? i : null;
	}
	Nh(t) {
		const i = this.Wh(t);
		return i !== this.xh.length && t < this.Dh(i) ? i : null;
	}
	zh(t) {
		const i = this.Fh(t);
		return i === this.xh.length || t < this.xh[i].$n ? null : i;
	}
	Fh(t) {
		return Rt(this.xh, t, ((t, i) => t.$n < i));
	}
	Wh(t) {
		return Dt(this.xh, t, ((t, i) => t.$n > i));
	}
	Hh(t, i, n) {
		let s = null;
		for (let e = t; e < i; e++) {
			const t = this.xh[e].Wt[n];
			Number.isNaN(t) || (null === s ? s = {
				Uh: t,
				$h: t
			} : (t < s.Uh && (s.Uh = t), t > s.$h && (s.$h = t)));
		}
		return s;
	}
	Ah(t, i, n) {
		if (this.Zi()) return null;
		let s = null;
		const e = u(this.Rh()), r = u(this.Qn()), h = Math.max(t, e), a = Math.min(i, r), l = Math.ceil(h / Vt) * Vt, o = Math.max(l, Math.floor(a / Vt) * Vt);
		{
			const t = this.Fh(h), e = this.Wh(Math.min(a, l, i));
			s = Et(s, this.Hh(t, e, n));
		}
		let _ = this.Ch.get(n);
		void 0 === _ && (_ = /* @__PURE__ */ new Map(), this.Ch.set(n, _));
		for (let t = Math.max(l + 1, h); t < o; t += Vt) {
			const i = Math.floor(t / Vt);
			let e = _.get(i);
			if (void 0 === e) {
				const t = this.Fh(i * Vt), s = this.Wh((i + 1) * Vt - 1);
				e = this.Hh(t, s, n), _.set(i, e);
			}
			s = Et(s, e);
		}
		{
			const t = this.Fh(o), i = this.Wh(a);
			s = Et(s, this.Hh(t, i, n));
		}
		return s;
	}
};
function Et(t, i) {
	if (null === t) return i;
	if (null === i) return t;
	return {
		Uh: Math.min(t.Uh, i.Uh),
		$h: Math.max(t.$h, i.$h)
	};
}
function At() {
	return new Bt();
}
var Lt = { setLineStyle: a };
var zt = class {
	constructor(t) {
		this.jh = t;
	}
	st(t, i, n) {
		this.jh.draw(t, Lt);
	}
	qh(t, i, n) {
		this.jh.drawBackground?.(t, Lt);
	}
};
var Ot = class {
	constructor(t) {
		this.Ls = null, this.Yh = t;
	}
	Tt() {
		const t = this.Yh.renderer();
		if (null === t) return null;
		if (this.Ls?.Kh === t) return this.Ls.Gh;
		const i = new zt(t);
		return this.Ls = {
			Kh: t,
			Gh: i
		}, i;
	}
	Zh() {
		return this.Yh.zOrder?.() ?? "normal";
	}
};
var Nt = class {
	constructor(t) {
		this.Xh = null, this.Jh = t;
	}
	Qh() {
		return this.Jh;
	}
	Nn() {
		this.Jh.updateAllViews?.();
	}
	jn() {
		const t = this.Jh.paneViews?.() ?? [];
		if (this.Xh?.Kh === t) return this.Xh.Gh;
		const i = t.map(((t) => new Ot(t)));
		return this.Xh = {
			Kh: t,
			Gh: i
		}, i;
	}
	Qs(t, i) {
		return this.Jh.hitTest?.(t, i) ?? null;
	}
};
var Ft = class extends Nt {
	cn() {
		return [];
	}
};
var Wt = class {
	constructor(t) {
		this.jh = t;
	}
	st(t, i, n) {
		this.jh.draw(t, Lt);
	}
	qh(t, i, n) {
		this.jh.drawBackground?.(t, Lt);
	}
};
var Ht = class {
	constructor(t) {
		this.Ls = null, this.Yh = t;
	}
	Tt() {
		const t = this.Yh.renderer();
		if (null === t) return null;
		if (this.Ls?.Kh === t) return this.Ls.Gh;
		const i = new Wt(t);
		return this.Ls = {
			Kh: t,
			Gh: i
		}, i;
	}
	Zh() {
		return this.Yh.zOrder?.() ?? "normal";
	}
};
function Ut(t) {
	return {
		ri: t.text(),
		Ei: t.coordinate(),
		Vi: t.fixedCoordinate?.(),
		R: t.textColor(),
		Z: t.backColor(),
		It: t.visible?.() ?? !0,
		pi: t.tickVisible?.() ?? !0
	};
}
var $t = class {
	constructor(t, i) {
		this.Xt = new j(), this.ta = t, this.ia = i;
	}
	Tt() {
		return this.Xt.ht({
			nn: this.ia.nn(),
			...Ut(this.ta)
		}), this.Xt;
	}
};
var jt = class extends H {
	constructor(t, i) {
		super(), this.ta = t, this.Ki = i;
	}
	Yi(t, i, n) {
		const s = Ut(this.ta);
		n.Z = s.Z, t.R = s.R;
		const e = 2 / 12 * this.Ki.P();
		n.Ti = e, n.Ri = e, n.Ei = s.Ei, n.Vi = s.Vi, t.ri = s.ri, t.It = s.It, t.pi = s.pi;
	}
};
var qt = class extends Nt {
	constructor(t, i) {
		super(t), this.na = null, this.sa = null, this.ea = null, this.ra = null, this.Te = i;
	}
	dn() {
		const t = this.Jh.timeAxisViews?.() ?? [];
		if (this.na?.Kh === t) return this.na.Gh;
		const i = this.Te.Qt().Et(), n = t.map(((t) => new $t(t, i)));
		return this.na = {
			Kh: t,
			Gh: n
		}, n;
	}
	qn() {
		const t = this.Jh.priceAxisViews?.() ?? [];
		if (this.sa?.Kh === t) return this.sa.Gh;
		const i = this.Te.Ft(), n = t.map(((t) => new jt(t, i)));
		return this.sa = {
			Kh: t,
			Gh: n
		}, n;
	}
	ha() {
		const t = this.Jh.priceAxisPaneViews?.() ?? [];
		if (this.ea?.Kh === t) return this.ea.Gh;
		const i = t.map(((t) => new Ht(t)));
		return this.ea = {
			Kh: t,
			Gh: i
		}, i;
	}
	aa() {
		const t = this.Jh.timeAxisPaneViews?.() ?? [];
		if (this.ra?.Kh === t) return this.ra.Gh;
		const i = t.map(((t) => new Ht(t)));
		return this.ra = {
			Kh: t,
			Gh: i
		}, i;
	}
	la(t, i) {
		return this.Jh.autoscaleInfo?.(t, i) ?? null;
	}
};
function Yt(t, i, n, s) {
	t.forEach(((t) => {
		i(t).forEach(((t) => {
			t.Zh() === n && s.push(t);
		}));
	}));
}
function Kt(t) {
	return t.jn();
}
function Gt(t) {
	return t.ha();
}
function Zt(t) {
	return t.aa();
}
var Xt = [
	"Area",
	"Line",
	"Baseline"
];
var Jt = class extends yt {
	constructor(t, i, n, s, e) {
		super(t), this.qt = At(), this.dr = new ft(this), this.oa = [], this._a = new _t(this), this.ua = null, this.ca = null, this.da = null, this.fa = [], this.pa = new Ct(), this.va = /* @__PURE__ */ new Map(), this.ma = null, this.yn = n, this.wa = i;
		const r = new pt(this);
		if (this.mn = [r], this.pr = new at(r, this, t), Xt.includes(this.wa) && (this.ua = new dt(this)), this.Ma(), this.Yh = s(this, this.Qt(), e), "Custom" === this.wa) {
			const t = this.Yh;
			t.ga && this.ba(t.ga);
		}
	}
	m() {
		null !== this.da && clearTimeout(this.da);
	}
	We(t) {
		return this.yn.priceLineColor || t;
	}
	Ae(t) {
		const i = { Le: !0 }, n = this.Ft();
		if (this.Qt().Et().Zi() || n.Zi() || this.qt.Zi()) return i;
		const s = this.Qt().Et().Ee(), e = this.Lt();
		if (null === s || null === e) return i;
		let r, h;
		if (t) {
			const t = this.qt.kh();
			if (null === t) return i;
			r = t, h = t.$n;
		} else {
			const t = this.qt.Hn(s.bi(), -1);
			if (null === t) return i;
			if (r = this.qt.Mh(t.$n), null === r) return i;
			h = t.$n;
		}
		const a = r.Wt[3], l = this.Sa().Sh(h, { Wt: r }), o = n.Nt(a, e.Wt);
		return {
			Le: !1,
			Mt: a,
			ri: n.Ji(a, e.Wt),
			qe: n.xa(a),
			Ye: n.Ca(a, e.Wt),
			R: l.sh,
			Ei: o,
			$n: h
		};
	}
	Sa() {
		return null !== this.ca || (this.ca = new kt(this)), this.ca;
	}
	N() {
		return this.yn;
	}
	vr(t) {
		const i = this.Qt(), { priceScaleId: n, visible: s, priceFormat: e } = t;
		void 0 !== n && n !== this.yn.priceScaleId && i.ya(this, n), void 0 !== s && s !== this.yn.visible && i.Pa();
		const r = void 0 !== t.conflationThresholdFactor;
		f(this.yn, t), Object.prototype.hasOwnProperty.call(t, "autoscaleInfoProvider") && void 0 === t.autoscaleInfoProvider && (this.yn.autoscaleInfoProvider = void 0), r && (this.va.clear(), this.Qt().mr()), void 0 !== e && (this.Ma(), i.ka()), i.Ta(this), i.Ra(), this.Yh.Pt("options");
	}
	ht(t, i) {
		this.qt.ht(t), this.va.clear();
		const n = this.Qt().Et().N();
		n.enableConflation && n.precomputeConflationOnInit && this.Da(n.precomputeConflationPriority), this.Ia(), null !== this.ua && (i && i.Va ? this.ua.De() : 0 === t.length && this.ua.Re());
		const s = this.Qt().Ks(this);
		this.Qt().Ba(s), this.Qt().Ta(this), this.Qt().Ra(), this.Qt().mr();
	}
	Ia() {
		this.Yh.Pt("data");
	}
	Ea(t) {
		const i = new xt(this, t);
		return this.oa.push(i), this.Qt().Ta(this), i;
	}
	Aa(t) {
		const i = this.oa.indexOf(t);
		-1 !== i && this.oa.splice(i, 1), this.Qt().Ta(this);
	}
	La() {
		return this.oa;
	}
	bh() {
		return this.wa;
	}
	Lt() {
		const t = this.za();
		return null === t ? null : {
			Wt: t.Wt[3],
			Oa: t.wt
		};
	}
	za() {
		const t = this.Qt().Et().Ee();
		if (null === t) return null;
		const i = t.Na();
		return this.qt.Hn(i, 1);
	}
	Un() {
		return this.qt;
	}
	ba(t) {
		this.ma = t, this.va.clear();
	}
	Fa() {
		return !!this.Qt().Et().N().enableConflation && this.Wa() > 1;
	}
	Rr(t) {
		if (!this.Fa()) return;
		const i = this.Wa();
		if (!this.va.has(i)) return;
		const n = "Custom" === this.wa, s = n && this.ma || void 0, e = n && this.Yh.Ha ? (t) => {
			const i = t, n = this.Yh.Ha(i);
			return Array.isArray(n) ? n : ["number" == typeof n ? n : 0];
		} : void 0, r = this.pa.Rr(this.qt.Bh(), t, i, s, n, e), h = At();
		h.ht(r), this.va.set(i, h);
	}
	Ua() {
		const t = this.Qt().Et().N().enableConflation;
		if ("Custom" === this.wa && null === this.ma) return this.qt;
		if (!t) return this.qt;
		const i = this.Wa(), n = this.va.get(i);
		if (n) return n;
		this.$a(i);
		return this.va.get(i) ?? this.qt;
	}
	ja(t) {
		const i = this.qt.Mh(t);
		return null === i ? null : "Bar" === this.wa || "Candlestick" === this.wa || "Custom" === this.wa ? {
			jr: i.Wt[0],
			qr: i.Wt[1],
			Yr: i.Wt[2],
			Kr: i.Wt[3]
		} : i.Wt[3];
	}
	qa(t) {
		const i = [];
		Yt(this.fa, Kt, "top", i);
		const n = this.ua;
		return null !== n && n.It() ? (null === this.da && n.Ve() && (this.da = setTimeout((() => {
			this.da = null, this.Qt().Ya();
		}), 0)), n.Ie(), i.unshift(n), i) : i;
	}
	jn() {
		const t = [];
		this.Ka() || t.push(this._a), t.push(this.Yh, this.dr);
		const i = this.oa.map(((t) => t.wr()));
		return t.push(...i), Yt(this.fa, Kt, "normal", t), t;
	}
	Ga() {
		const t = this.Yh.Ga?.() ?? null;
		if (null === t) return null;
		const i = [];
		this.Ka() || i.push(this._a), i.push(...t.Za), Yt(this.fa, Kt, "normal", i);
		const n = [];
		n.push(...t.qa, this.dr);
		const s = this.oa.map(((t) => t.wr()));
		return n.push(...s), {
			Za: i,
			qa: n
		};
	}
	Xa() {
		return this.Ja(Kt, "bottom");
	}
	Qa(t) {
		return this.Ja(Gt, t);
	}
	tl(t) {
		return this.Ja(Zt, t);
	}
	il(t, i) {
		return this.fa.map(((n) => n.Qs(t, i))).filter(((t) => null !== t));
	}
	cn() {
		return [this.pr, ...this.oa.map(((t) => t.Mr()))];
	}
	qn(t, i) {
		if (i !== this.hn && !this.Ka()) return [];
		const n = [...this.mn];
		for (const t of this.oa) n.push(t.gr());
		return this.fa.forEach(((t) => {
			n.push(...t.qn());
		})), n;
	}
	dn() {
		const t = [];
		return this.fa.forEach(((i) => {
			t.push(...i.dn());
		})), t;
	}
	la(t, i) {
		if (void 0 !== this.yn.autoscaleInfoProvider) {
			const n = this.yn.autoscaleInfoProvider((() => {
				const n = this.nl(t, i);
				return null === n ? null : n.sr();
			}));
			return wt.er(n);
		}
		return this.nl(t, i);
	}
	Kh() {
		const t = this.yn.priceFormat;
		return t.base ?? 1 / t.minMove;
	}
	sl() {
		return this.el;
	}
	Nn() {
		this.Yh.Pt();
		for (const t of this.mn) t.Pt();
		for (const t of this.oa) t.Pt();
		this.dr.Pt(), this._a.Pt(), this.ua?.Pt(), this.fa.forEach(((t) => t.Nn()));
	}
	Ft() {
		return u(super.Ft());
	}
	At(t) {
		if (!(("Line" === this.wa || "Area" === this.wa || "Baseline" === this.wa) && this.yn.crosshairMarkerVisible)) return null;
		const i = this.qt.Mh(t);
		if (null === i) return null;
		return {
			Mt: i.Wt[3],
			ft: this.rl(),
			Ht: this.hl(),
			Ot: this.al(),
			zt: this.ll(t)
		};
	}
	He() {
		return this.yn.title;
	}
	It() {
		return this.yn.visible;
	}
	ol(t) {
		this.fa.push(new qt(t, this));
	}
	_l(t) {
		this.fa = this.fa.filter(((i) => i.Qh() !== t));
	}
	ul() {
		if ("Custom" === this.wa) return (t) => this.Yh.Ha(t);
	}
	cl() {
		if ("Custom" === this.wa) return (t) => this.Yh.dl(t);
	}
	fl() {
		return this.qt.Lh();
	}
	Ka() {
		return !Z(this.Ft().pl());
	}
	nl(t, i) {
		if (!v(t) || !v(i) || this.qt.Zi()) return null;
		const n = "Line" === this.wa || "Area" === this.wa || "Baseline" === this.wa || "Histogram" === this.wa ? [3] : [2, 1], s = this.qt.Eh(t, i, n);
		let e = null !== s ? new mt(s.Uh, s.$h) : null, r = null;
		if ("Histogram" === this.bh()) {
			const t = this.yn.base, i = new mt(t, t);
			e = null !== e ? e.Ss(i) : i;
		}
		return this.fa.forEach(((n) => {
			const s = n.la(t, i);
			if (s?.priceRange) {
				const t = new mt(s.priceRange.minValue, s.priceRange.maxValue);
				e = null !== e ? e.Ss(t) : t;
			}
			s?.margins && (r = s.margins);
		})), new wt(e, r);
	}
	rl() {
		switch (this.wa) {
			case "Line":
			case "Area":
			case "Baseline": return this.yn.crosshairMarkerRadius;
		}
		return 0;
	}
	hl() {
		switch (this.wa) {
			case "Line":
			case "Area":
			case "Baseline": {
				const t = this.yn.crosshairMarkerBorderColor;
				if (0 !== t.length) return t;
			}
		}
		return null;
	}
	al() {
		switch (this.wa) {
			case "Line":
			case "Area":
			case "Baseline": return this.yn.crosshairMarkerBorderWidth;
		}
		return 0;
	}
	ll(t) {
		switch (this.wa) {
			case "Line":
			case "Area":
			case "Baseline": {
				const t = this.yn.crosshairMarkerBackgroundColor;
				if (0 !== t.length) return t;
			}
		}
		return this.Sa().Sh(t).sh;
	}
	Ma() {
		switch (this.yn.priceFormat.type) {
			case "custom": {
				const t = this.yn.priceFormat.formatter;
				this.el = {
					format: t,
					formatTickmarks: this.yn.priceFormat.tickmarksFormatter ?? ((i) => i.map(t))
				};
				break;
			}
			case "volume":
				this.el = new st(this.yn.priceFormat.precision);
				break;
			case "percent":
				this.el = new nt(this.yn.priceFormat.precision);
				break;
			default: {
				const t = Math.pow(10, this.yn.priceFormat.precision);
				this.el = new it(t, this.yn.priceFormat.minMove * t);
			}
		}
		null !== this.hn && this.hn.vl();
	}
	Ja(t, i) {
		const n = [];
		return Yt(this.fa, t, i, n), n;
	}
	Wa() {
		const { ml: t, wl: i, Ml: n } = this.gl();
		return this.pa.Sr(t, i, n);
	}
	gl() {
		const t = this.Qt().Et(), i = t.ml(), n = window.devicePixelRatio || 1, s = t.N().conflationThresholdFactor;
		return {
			ml: i,
			wl: n,
			Ml: this.yn.conflationThresholdFactor ?? s ?? 1
		};
	}
	bl(t) {
		const i = this.qt.Bh();
		let n;
		if ("Custom" === this.wa && null !== this.ma) {
			const s = this.ul();
			if (!s) throw new Error(gt);
			n = this.pa.Cr(i, t, this.ma, !0, ((t) => s(t)));
		} else n = this.pa.Cr(i, t);
		const s = At();
		return s.ht(n), s;
	}
	$a(t) {
		const i = this.bl(t);
		this.va.set(t, i);
	}
	Da(t) {
		if ("Custom" === this.wa && (null === this.ma || !this.ul())) return;
		this.va.clear();
		const i = this.Qt().Et().Sl();
		for (const n of i) {
			const i = () => {
				this.xl(n);
			}, s = "object" == typeof window && window || "object" == typeof self && self;
			s?.yl?.Cl ? s.yl.Cl((() => {
				i();
			}), { se: t }) : Promise.resolve().then((() => i()));
		}
	}
	xl(t) {
		if (this.va.has(t)) return;
		if (0 === this.qt.Bh().length) return;
		const i = this.bl(t);
		this.va.set(t, i);
	}
};
var Qt = [3];
var ti = [
	0,
	1,
	2,
	3
];
var ii = class {
	constructor(t) {
		this.yn = t;
	}
	Pl(t, i, n) {
		let s = t;
		if (0 === this.yn.mode) return s;
		const e = n.kn(), r = e.Lt();
		if (null === r) return s;
		const h = e.Nt(t, r), a = n.kl().filter(((t) => t instanceof Jt)).reduce(((t, s) => {
			if (n.Gs(s) || !s.It()) return t;
			const e = s.Ft(), r = s.Un();
			if (e.Zi() || !r.ze(i)) return t;
			const h = r.Mh(i);
			if (null === h) return t;
			const a = c(s.Lt()), l = 3 === this.yn.mode ? ti : Qt;
			return t.concat(l.map(((t) => e.Nt(h.Wt[t], a.Wt))));
		}), []);
		if (0 === a.length) return s;
		a.sort(((t, i) => Math.abs(t - h) - Math.abs(i - h)));
		const l = a[0];
		return s = e.Tn(l, r), s;
	}
};
function ni(t, i, n) {
	return Math.min(Math.max(t, i), n);
}
function si(t, i, n) {
	return i - t <= n;
}
var ri = class extends R {
	constructor() {
		super(...arguments), this.qt = null;
	}
	ht(t) {
		this.qt = t;
	}
	et({ context: t, bitmapSize: i, horizontalPixelRatio: n, verticalPixelRatio: s }) {
		if (null === this.qt) return;
		const e = Math.max(1, Math.floor(n));
		t.lineWidth = e, function(t, i) {
			t.save(), t.lineWidth % 2 && t.translate(.5, .5), i(), t.restore();
		}(t, (() => {
			const r = u(this.qt);
			if (r.Tl) {
				t.strokeStyle = r.Rl, a(t, r.Dl), t.beginPath();
				for (const s of r.Il) {
					const r = Math.round(s.Vl * n);
					t.moveTo(r, -e), t.lineTo(r, i.height + e);
				}
				t.stroke();
			}
			if (r.Bl) {
				t.strokeStyle = r.El, a(t, r.Al), t.beginPath();
				for (const n of r.Ll) {
					const r = Math.round(n.Vl * s);
					t.moveTo(-e, r), t.lineTo(i.width + e, r);
				}
				t.stroke();
			}
		}));
	}
};
var hi = class {
	constructor(t) {
		this.Xt = new ri(), this.xt = !0, this.yt = t;
	}
	Pt() {
		this.xt = !0;
	}
	Tt() {
		if (this.xt) {
			const t = this.yt.Qt().N().grid, i = {
				Bl: t.horzLines.visible,
				Tl: t.vertLines.visible,
				El: t.horzLines.color,
				Rl: t.vertLines.color,
				Al: t.horzLines.style,
				Dl: t.vertLines.style,
				Ll: this.yt.kn().zl(),
				Il: (this.yt.Qt().Et().zl() || []).map(((t) => ({ Vl: t.coord })))
			};
			this.Xt.ht(i), this.xt = !1;
		}
		return this.Xt;
	}
};
var ai = class {
	constructor(t) {
		this.Yh = new hi(t);
	}
	wr() {
		return this.Yh;
	}
};
var li = {
	Ol: 4,
	Nl: 1e-4
};
function oi(t, i) {
	const n = 100 * (t - i) / i;
	return i < 0 ? -n : n;
}
function _i(t, i) {
	return new mt(oi(t.Je(), i), oi(t.Qe(), i));
}
function ui(t, i) {
	const n = 100 * (t - i) / i + 100;
	return i < 0 ? -n : n;
}
function ci(t, i) {
	return new mt(ui(t.Je(), i), ui(t.Qe(), i));
}
function di(t, i) {
	const n = Math.abs(t);
	if (n < 1e-15) return 0;
	const s = Math.log10(n + i.Nl) + i.Ol;
	return t < 0 ? -s : s;
}
function fi(t, i) {
	const n = Math.abs(t);
	if (n < 1e-15) return 0;
	const s = Math.pow(10, n - i.Ol) - i.Nl;
	return t < 0 ? -s : s;
}
function pi(t, i) {
	if (null === t) return null;
	return new mt(di(t.Je(), i), di(t.Qe(), i));
}
function vi(t, i) {
	if (null === t) return null;
	return new mt(fi(t.Je(), i), fi(t.Qe(), i));
}
function mi(t) {
	if (null === t) return li;
	const i = Math.abs(t.Qe() - t.Je());
	if (i >= 1 || i < 1e-15) return li;
	const n = Math.ceil(Math.abs(Math.log10(i))), s = li.Ol + n;
	return {
		Ol: s,
		Nl: 1 / Math.pow(10, s)
	};
}
var wi = class {
	constructor(t, i) {
		if (this.Fl = t, this.Wl = i, function(t) {
			if (t < 0) return !1;
			if (t > 0xde0b6b3a7640000) return !0;
			for (let i = t; i > 1; i /= 10) if (i % 10 != 0) return !1;
			return !0;
		}(this.Fl)) this.Hl = [
			2,
			2.5,
			2
		];
		else {
			this.Hl = [];
			for (let t = this.Fl; 1 !== t;) {
				if (t % 2 == 0) this.Hl.push(2), t /= 2;
				else {
					if (t % 5 != 0) throw new Error("unexpected base");
					this.Hl.push(2, 2.5), t /= 5;
				}
				if (this.Hl.length > 100) throw new Error("something wrong with base");
			}
		}
	}
	Ul(t, i, n) {
		const s = 0 === this.Fl ? 0 : 1 / this.Fl;
		let e = Math.pow(10, Math.max(0, Math.ceil(Math.log10(t - i)))), r = 0, h = this.Wl[0];
		for (;;) {
			const t = si(e, s, 1e-14) && e > s + 1e-14, i = si(e, n * h, 1e-14), a = si(e, 1, 1e-14);
			if (!(t && i && a)) break;
			e /= h, h = this.Wl[++r % this.Wl.length];
		}
		if (e <= s + 1e-14 && (e = s), e = Math.max(1, e), this.Hl.length > 0 && (a = e, l = 1, o = 1e-14, Math.abs(a - l) < o)) for (r = 0, h = this.Hl[0]; si(e, n * h, 1e-14) && e > s + 1e-14;) e /= h, h = this.Hl[++r % this.Hl.length];
		var a, l, o;
		return e;
	}
};
var Mi = class {
	constructor(t, i, n, s) {
		this.$l = [], this.Ki = t, this.Fl = i, this.jl = n, this.ql = s;
	}
	Ul(t, i) {
		if (t < i) throw new Error("high < low");
		const n = this.Ki.$t(), s = (t - i) * this.Yl() / n, e = new wi(this.Fl, [
			2,
			2.5,
			2
		]), r = new wi(this.Fl, [
			2,
			2,
			2.5
		]), h = new wi(this.Fl, [
			2.5,
			2,
			2
		]), a = [];
		return a.push(e.Ul(t, i, s), r.Ul(t, i, s), h.Ul(t, i, s)), function(t) {
			if (t.length < 1) throw Error("array is empty");
			let i = t[0];
			for (let n = 1; n < t.length; ++n) t[n] < i && (i = t[n]);
			return i;
		}(a);
	}
	Kl() {
		const t = this.Ki, i = t.Lt();
		if (null === i) return void (this.$l = []);
		const n = t.$t(), s = this.jl(n - 1, i), e = this.jl(0, i), r = this.Ki.N().entireTextOnly ? this.Gl() / 2 : 0, h = r, a = n - 1 - r, l = Math.max(s, e), o = Math.min(s, e);
		if (l === o) return void (this.$l = []);
		const _ = this.Ul(l, o);
		if (this.Zl(i, _, l, o, h, a), t.Xl() && this.Jl(_, o, l)) {
			const t = this.Ki.Ql();
			this.io(i, _, h, a, t, 2 * t);
		}
		const u = this.$l.map(((t) => t.no)), c = this.Ki.so(u);
		for (let t = 0; t < this.$l.length; t++) this.$l[t].eo = c[t];
	}
	zl() {
		return this.$l;
	}
	Gl() {
		return this.Ki.P();
	}
	Yl() {
		return Math.ceil(this.Gl() * this.Ki.N().tickMarkDensity);
	}
	Zl(t, i, n, s, e, r) {
		const h = this.$l, a = this.Ki;
		let l = n % i;
		l += l < 0 ? i : 0;
		const o = n >= s ? 1 : -1;
		let _ = null, u = 0;
		for (let c = n - l; c > s; c -= i) {
			const n = this.ql(c, t, !0);
			null !== _ && Math.abs(n - _) < this.Yl() || n < e || n > r || (u < h.length ? (h[u].Vl = n, h[u].eo = a.ro(c), h[u].no = c) : h.push({
				Vl: n,
				eo: a.ro(c),
				no: c
			}), u++, _ = n, a.ho() && (i = this.Ul(c * o, s)));
		}
		h.length = u;
	}
	io(t, i, n, s, e, r) {
		const h = this.$l, a = this.ao(t, n, e, r), l = this.ao(t, s, -r, -e), o = this.ql(0, t, !0) - this.ql(i, t, !0);
		h.length > 0 && h[0].Vl - a.Vl < o / 2 && h.shift(), h.length > 0 && l.Vl - h[h.length - 1].Vl < o / 2 && h.pop(), h.unshift(a), h.push(l);
	}
	ao(t, i, n, s) {
		const e = (n + s) / 2, r = this.jl(i + n, t), h = this.jl(i + s, t), a = Math.min(r, h), l = Math.max(r, h), o = Math.max(.1, this.Ul(l, a)), _ = this.jl(i + e, t), u = _ - _ % o, c = this.ql(u, t, !0);
		return {
			eo: this.Ki.ro(u),
			Vl: c,
			no: u
		};
	}
	Jl(t, i, n) {
		let s = c(this.Ki.ar());
		return this.Ki.ho() && (s = vi(s, this.Ki.lo())), s.Je() - i < t && n - s.Qe() < t;
	}
};
function gi(t) {
	return t.slice().sort(((t, i) => u(t.ln()) - u(i.ln())));
}
var bi;
(function(t) {
	t[t.Normal = 0] = "Normal", t[t.Logarithmic = 1] = "Logarithmic", t[t.Percentage = 2] = "Percentage", t[t.IndexedTo100 = 3] = "IndexedTo100";
})(bi || (bi = {}));
var Si = new nt();
var xi = new it(100, 1);
var Ci = class {
	constructor(t, i, n, s, e) {
		this.oo = 0, this._o = null, this.rr = null, this.uo = null, this.co = {
			do: !1,
			fo: null
		}, this.po = !1, this.vo = 0, this.mo = 0, this.wo = new d(), this.Mo = new d(), this.bo = [], this.So = null, this.xo = null, this.Co = null, this.yo = null, this.Po = null, this.el = xi, this.ko = mi(null), this.To = t, this.yn = i, this.Ro = n, this.Do = s, this.Io = e, this.Vo = new Mi(this, 100, this.Bo.bind(this), this.Eo.bind(this));
	}
	pl() {
		return this.To;
	}
	N() {
		return this.yn;
	}
	vr(t) {
		if (f(this.yn, t), this.vl(), void 0 !== t.mode && this.Ao({ _e: t.mode }), void 0 !== t.scaleMargins) {
			const i = _(t.scaleMargins.top), n = _(t.scaleMargins.bottom);
			if (i < 0 || i > 1) throw new Error(`Invalid top margin - expect value between 0 and 1, given=${i}`);
			if (n < 0 || n > 1) throw new Error(`Invalid bottom margin - expect value between 0 and 1, given=${n}`);
			if (i + n > 1) throw new Error(`Invalid margins - sum of margins must be less than 1, given=${i + n}`);
			this.Lo(), this.Co = null;
		}
	}
	zo() {
		return this.yn.autoScale;
	}
	Oo() {
		return this.po;
	}
	ho() {
		return 1 === this.yn.mode;
	}
	je() {
		return 2 === this.yn.mode;
	}
	No() {
		return 3 === this.yn.mode;
	}
	lo() {
		return this.ko;
	}
	_e() {
		return {
			hs: this.yn.autoScale,
			Fo: this.yn.invertScale,
			_e: this.yn.mode
		};
	}
	Ao(t) {
		const i = this._e();
		let n = null;
		void 0 !== t.hs && (this.yn.autoScale = t.hs), void 0 !== t._e && (this.yn.mode = t._e, 2 !== t._e && 3 !== t._e || (this.yn.autoScale = !0), this.co.do = !1), 1 === i._e && t._e !== i._e && (!function(t, i) {
			if (null === t) return !1;
			const n = fi(t.Je(), i), s = fi(t.Qe(), i);
			return isFinite(n) && isFinite(s);
		}(this.rr, this.ko) ? this.yn.autoScale = !0 : (n = vi(this.rr, this.ko), null !== n && this.Wo(n))), 1 === t._e && t._e !== i._e && (n = pi(this.rr, this.ko), null !== n && this.Wo(n));
		const s = i._e !== this.yn.mode;
		s && (2 === i._e || this.je()) && this.vl(), s && (3 === i._e || this.No()) && this.vl(), void 0 !== t.Fo && i.Fo !== t.Fo && (this.yn.invertScale = t.Fo, this.Ho()), this.Mo.p(i, this._e());
	}
	Uo() {
		return this.Mo;
	}
	P() {
		return this.Ro.fontSize;
	}
	$t() {
		return this.oo;
	}
	$o(t) {
		this.oo !== t && (this.oo = t, this.Lo(), this.Co = null);
	}
	jo() {
		if (this._o) return this._o;
		const t = this.$t() - this.qo() - this.Yo();
		return this._o = t, t;
	}
	ar() {
		return this.Ko(), this.rr;
	}
	Wo(t, i) {
		const n = this.rr;
		(i || null === n && null !== t || null !== n && !n.Ze(t)) && (this.Co = null, this.rr = t);
	}
	Go(t) {
		this.Wo(t), this.Zo(null !== t);
	}
	Zi() {
		return this.Ko(), 0 === this.oo || !this.rr || this.rr.Zi();
	}
	Xo(t) {
		return this.Fo() ? t : this.$t() - 1 - t;
	}
	Nt(t, i) {
		return this.je() ? t = oi(t, i) : this.No() && (t = ui(t, i)), this.Eo(t, i);
	}
	Jo(t, i, n) {
		this.Ko();
		const s = this.Yo(), e = u(this.ar()), r = e.Je(), h = e.Qe(), a = this.jo() - 1, l = this.Fo(), o = a / (h - r), _ = void 0 === n ? 0 : n.from, c = void 0 === n ? t.length : n.to, d = this.Qo();
		for (let n = _; n < c; n++) {
			const e = t[n], h = e.Mt;
			if (isNaN(h)) continue;
			let a = h;
			null !== d && (a = d(e.Mt, i));
			const _ = s + o * (a - r);
			e.ut = l ? _ : this.oo - 1 - _;
		}
	}
	t_(t, i, n) {
		this.Ko();
		const s = this.Yo(), e = u(this.ar()), r = e.Je(), h = e.Qe(), a = this.jo() - 1, l = this.Fo(), o = a / (h - r), _ = void 0 === n ? 0 : n.from, c = void 0 === n ? t.length : n.to, d = this.Qo();
		for (let n = _; n < c; n++) {
			const e = t[n];
			let h = e.jr, a = e.qr, _ = e.Yr, u = e.Kr;
			null !== d && (h = d(e.jr, i), a = d(e.qr, i), _ = d(e.Yr, i), u = d(e.Kr, i));
			let c = s + o * (h - r), f = l ? c : this.oo - 1 - c;
			e.i_ = f, c = s + o * (a - r), f = l ? c : this.oo - 1 - c, e.n_ = f, c = s + o * (_ - r), f = l ? c : this.oo - 1 - c, e.s_ = f, c = s + o * (u - r), f = l ? c : this.oo - 1 - c, e.e_ = f;
		}
	}
	Tn(t, i) {
		const n = this.Bo(t, i);
		return this.r_(n, i);
	}
	r_(t, i) {
		let n = t;
		return this.je() ? n = function(t, i) {
			return i < 0 && (t = -t), t / 100 * i + i;
		}(n, i) : this.No() && (n = function(t, i) {
			return t -= 100, i < 0 && (t = -t), t / 100 * i + i;
		}(n, i)), n;
	}
	kl() {
		return this.bo;
	}
	Dt() {
		return this.xo || (this.xo = gi(this.bo)), this.xo;
	}
	h_(t) {
		-1 === this.bo.indexOf(t) && (this.bo.push(t), this.vl(), this.a_());
	}
	l_(t) {
		const i = this.bo.indexOf(t);
		if (-1 === i) throw new Error("source is not attached to scale");
		this.bo.splice(i, 1), 0 === this.bo.length && (this.Ao({ hs: !0 }), this.Wo(null)), this.vl(), this.a_();
	}
	Lt() {
		let t = null;
		for (const i of this.bo) {
			const n = i.Lt();
			null !== n && (null === t || n.Oa < t.Oa) && (t = n);
		}
		return null === t ? null : t.Wt;
	}
	Fo() {
		return this.yn.invertScale;
	}
	zl() {
		const t = null === this.Lt();
		if (null !== this.Co && (t || this.Co.o_ === t)) return this.Co.zl;
		this.Vo.Kl();
		const i = this.Vo.zl();
		return this.Co = {
			zl: i,
			o_: t
		}, this.wo.p(), i;
	}
	__() {
		return this.wo;
	}
	u_(t) {
		this.je() || this.No() || null === this.yo && null === this.uo && (this.Zi() || (this.yo = this.oo - t, this.uo = u(this.ar()).Xe()));
	}
	c_(t) {
		if (this.je() || this.No()) return;
		if (null === this.yo) return;
		this.Ao({ hs: !1 }), (t = this.oo - t) < 0 && (t = 0);
		let i = (this.yo + .2 * (this.oo - 1)) / (t + .2 * (this.oo - 1));
		const n = u(this.uo).Xe();
		i = Math.max(i, .1), n.ir(i), this.Wo(n);
	}
	d_() {
		this.je() || this.No() || (this.yo = null, this.uo = null);
	}
	f_(t) {
		this.zo() || null === this.Po && null === this.uo && (this.Zi() || (this.Po = t, this.uo = u(this.ar()).Xe()));
	}
	p_(t) {
		if (this.zo()) return;
		if (null === this.Po) return;
		const i = u(this.ar()).tr() / (this.jo() - 1);
		let n = t - this.Po;
		this.Fo() && (n *= -1);
		const s = n * i, e = u(this.uo).Xe();
		e.nr(s), this.Wo(e, !0), this.Co = null;
	}
	v_() {
		this.zo() || null !== this.Po && (this.Po = null, this.uo = null);
	}
	sl() {
		return this.el || this.vl(), this.el;
	}
	Ji(t, i) {
		switch (this.yn.mode) {
			case 2: return this.m_(oi(t, i));
			case 3: return this.sl().format(ui(t, i));
			default: return this.cr(t);
		}
	}
	ro(t) {
		switch (this.yn.mode) {
			case 2: return this.m_(t);
			case 3: return this.sl().format(t);
			default: return this.cr(t);
		}
	}
	so(t) {
		switch (this.yn.mode) {
			case 2: return this.w_(t);
			case 3: return this.sl().formatTickmarks(t);
			default: return this.M_(t);
		}
	}
	xa(t) {
		return this.cr(t, u(this.So).sl());
	}
	Ca(t, i) {
		return t = oi(t, i), this.m_(t, Si);
	}
	g_() {
		return this.bo;
	}
	b_(t) {
		this.co = {
			fo: t,
			do: !1
		};
	}
	Nn() {
		this.bo.forEach(((t) => t.Nn()));
	}
	Xl() {
		return this.yn.ensureEdgeTickMarksVisible && this.zo();
	}
	Ql() {
		return this.P() / 2;
	}
	vl() {
		this.Co = null;
		let t = 1 / 0;
		this.So = null;
		for (const i of this.bo) i.ln() < t && (t = i.ln(), this.So = i);
		let i = 100;
		null !== this.So && (i = Math.round(this.So.Kh())), this.el = xi, this.je() ? (this.el = Si, i = 100) : this.No() ? (this.el = new it(100, 1), i = 100) : null !== this.So && (this.el = this.So.sl()), this.Vo = new Mi(this, i, this.Bo.bind(this), this.Eo.bind(this)), this.Vo.Kl();
	}
	a_() {
		this.xo = null;
	}
	S_() {
		return null === this.So || this.je() || this.No() ? 1 : 1 / this.So.Kh();
	}
	Xi() {
		return this.Io;
	}
	Zo(t) {
		this.po = t;
	}
	qo() {
		return this.Fo() ? this.yn.scaleMargins.bottom * this.$t() + this.mo : this.yn.scaleMargins.top * this.$t() + this.vo;
	}
	Yo() {
		return this.Fo() ? this.yn.scaleMargins.top * this.$t() + this.vo : this.yn.scaleMargins.bottom * this.$t() + this.mo;
	}
	Ko() {
		this.co.do || (this.co.do = !0, this.x_());
	}
	Lo() {
		this._o = null;
	}
	Eo(t, i) {
		if (this.Ko(), this.Zi()) return 0;
		t = this.ho() && t ? di(t, this.ko) : t;
		const n = u(this.ar()), s = this.Yo() + (this.jo() - 1) * (t - n.Je()) / n.tr();
		return this.Xo(s);
	}
	Bo(t, i) {
		if (this.Ko(), this.Zi()) return 0;
		const n = this.Xo(t), s = u(this.ar()), e = s.Je() + s.tr() * ((n - this.Yo()) / (this.jo() - 1));
		return this.ho() ? fi(e, this.ko) : e;
	}
	Ho() {
		this.Co = null, this.Vo.Kl();
	}
	x_() {
		if (this.Oo() && !this.zo()) return;
		const t = this.co.fo;
		if (null === t) return;
		let i = null;
		const n = this.g_();
		let s = 0, e = 0;
		for (const r of n) {
			if (!r.It()) continue;
			const n = r.Lt();
			if (null === n) continue;
			const h = r.la(t.Na(), t.bi());
			let a = h && h.ar();
			if (null !== a) {
				switch (this.yn.mode) {
					case 1:
						a = pi(a, this.ko);
						break;
					case 2:
						a = _i(a, n.Wt);
						break;
					case 3: a = ci(a, n.Wt);
				}
				if (i = null === i ? a : i.Ss(u(a)), null !== h) {
					const t = h.lr();
					null !== t && (s = Math.max(s, t.above), e = Math.max(e, t.below));
				}
			}
		}
		if (this.Xl() && (s = Math.max(s, this.Ql()), e = Math.max(e, this.Ql())), s === this.vo && e === this.mo || (this.vo = s, this.mo = e, this.Co = null, this.Lo()), null !== i) {
			if (i.Je() === i.Qe()) {
				const t = 5 * this.S_();
				this.ho() && (i = vi(i, this.ko)), i = new mt(i.Je() - t, i.Qe() + t), this.ho() && (i = pi(i, this.ko));
			}
			if (this.ho()) {
				const t = vi(i, this.ko), n = mi(t);
				if (r = n, h = this.ko, r.Ol !== h.Ol || r.Nl !== h.Nl) {
					const s = null !== this.uo ? vi(this.uo, this.ko) : null;
					this.ko = n, i = pi(t, n), null !== s && (this.uo = pi(s, n));
				}
			}
			this.Wo(i);
		} else null === this.rr && (this.Wo(new mt(-.5, .5)), this.ko = mi(null));
		var r, h;
	}
	Qo() {
		return this.je() ? oi : this.No() ? ui : this.ho() ? (t) => di(t, this.ko) : null;
	}
	C_(t, i, n) {
		return void 0 === i ? (void 0 === n && (n = this.sl()), n.format(t)) : i(t);
	}
	y_(t, i, n) {
		return void 0 === i ? (void 0 === n && (n = this.sl()), n.formatTickmarks(t)) : i(t);
	}
	cr(t, i) {
		return this.C_(t, this.Do.priceFormatter, i);
	}
	M_(t, i) {
		const n = this.Do.priceFormatter;
		return this.y_(t, this.Do.tickmarksPriceFormatter ?? (n ? (t) => t.map(n) : void 0), i);
	}
	m_(t, i) {
		return this.C_(t, this.Do.percentageFormatter, i);
	}
	w_(t, i) {
		const n = this.Do.percentageFormatter;
		return this.y_(t, this.Do.tickmarksPercentageFormatter ?? (n ? (t) => t.map(n) : void 0), i);
	}
};
function yi(t) {
	return t instanceof Jt;
}
var Pi = class {
	constructor(t, i) {
		this.bo = [], this.P_ = /* @__PURE__ */ new Map(), this.oo = 0, this.k_ = 0, this.T_ = 1, this.xo = null, this.R_ = null, this.D_ = !1, this.I_ = new d(), this.fa = [], this.ia = t, this.sn = i, this.V_ = new ai(this);
		const n = i.N();
		this.B_ = this.E_("left", n.leftPriceScale), this.A_ = this.E_("right", n.rightPriceScale), this.B_.Uo().i(this.L_.bind(this, this.B_), this), this.A_.Uo().i(this.L_.bind(this, this.A_), this), this.z_(n);
	}
	z_(t) {
		if (t.leftPriceScale && this.B_.vr(t.leftPriceScale), t.rightPriceScale && this.A_.vr(t.rightPriceScale), t.localization && (this.B_.vl(), this.A_.vl()), t.overlayPriceScales) {
			const i = Array.from(this.P_.values());
			for (const n of i) {
				const i = u(n[0].Ft());
				i.vr(t.overlayPriceScales), t.localization && i.vl();
			}
		}
	}
	O_(t) {
		switch (t) {
			case "left": return this.B_;
			case "right": return this.A_;
		}
		return this.P_.has(t) ? _(this.P_.get(t))[0].Ft() : null;
	}
	m() {
		this.Qt().N_().u(this), this.B_.Uo().u(this), this.A_.Uo().u(this), this.bo.forEach(((t) => {
			t.m && t.m();
		})), this.fa = this.fa.filter(((t) => {
			const i = t.Qh();
			return i.detached && i.detached(), !1;
		})), this.I_.p();
	}
	F_() {
		return this.T_;
	}
	W_(t) {
		this.T_ = t;
	}
	Qt() {
		return this.sn;
	}
	nn() {
		return this.k_;
	}
	$t() {
		return this.oo;
	}
	H_(t) {
		this.k_ = t, this.U_();
	}
	$o(t) {
		this.oo = t, this.B_.$o(t), this.A_.$o(t), this.bo.forEach(((i) => {
			if (this.Gs(i)) {
				const n = i.Ft();
				null !== n && n.$o(t);
			}
		})), this.U_();
	}
	j_(t) {
		this.D_ = t;
	}
	q_() {
		return this.D_;
	}
	Y_() {
		return this.bo.filter(yi);
	}
	kl() {
		return this.bo;
	}
	Gs(t) {
		const i = t.Ft();
		return null === i || this.B_ !== i && this.A_ !== i;
	}
	h_(t, i, n) {
		this.K_(t, i, n ? t.ln() : this.bo.length);
	}
	l_(t, i) {
		const n = this.bo.indexOf(t);
		o(-1 !== n, "removeDataSource: invalid data source"), this.bo.splice(n, 1), i || this.bo.forEach(((t, i) => t._n(i)));
		const s = u(t.Ft()).pl();
		if (this.P_.has(s)) {
			const i = _(this.P_.get(s)), n = i.indexOf(t);
			-1 !== n && (i.splice(n, 1), 0 === i.length && this.P_.delete(s));
		}
		const e = t.Ft();
		e && e.kl().indexOf(t) >= 0 && (e.l_(t), this.G_(e)), this.Z_();
	}
	Xs(t) {
		return t === this.B_ ? "left" : t === this.A_ ? "right" : "overlay";
	}
	X_() {
		return this.B_;
	}
	J_() {
		return this.A_;
	}
	Q_(t, i) {
		t.u_(i);
	}
	tu(t, i) {
		t.c_(i), this.U_();
	}
	iu(t) {
		t.d_();
	}
	nu(t, i) {
		t.f_(i);
	}
	su(t, i) {
		t.p_(i), this.U_();
	}
	eu(t) {
		t.v_();
	}
	U_() {
		this.bo.forEach(((t) => {
			t.Nn();
		}));
	}
	kn() {
		const [t, i] = this.ru();
		let n = null;
		return t.N().visible && 0 !== t.kl().length ? n = t : i.N().visible && 0 !== i.kl().length ? n = i : 0 !== this.bo.length && (n = this.bo[0].Ft()), null === n && (n = this.Zs() ?? t), n;
	}
	Zs() {
		const [t, i] = this.ru();
		return t.N().visible ? t : i.N().visible ? i : null;
	}
	G_(t) {
		null !== t && t.zo() && this.hu(t);
	}
	au(t) {
		const i = this.ia.Ee();
		t.Ao({ hs: !0 }), null !== i && t.b_(i), this.U_();
	}
	lu() {
		this.hu(this.B_), this.hu(this.A_);
	}
	ou() {
		this.G_(this.B_), this.G_(this.A_), this.bo.forEach(((t) => {
			this.Gs(t) && this.G_(t.Ft());
		})), this.U_(), this.sn.mr();
	}
	Dt() {
		return null === this.xo && (this.xo = gi(this.bo)), this.xo;
	}
	_u() {
		const t = this.Dt(), i = this.sn.cu()?.uu, n = this.sn.N().hoveredSeriesOnTop, s = this.R_;
		if (null !== s && s.Kh === t && s.du === i && s.fu === n) return s.pu;
		const e = function(t, i, n) {
			if (!n) return t;
			const s = t.indexOf(i);
			if (-1 === s || s === t.length - 1) return t;
			const e = [];
			for (let i = 0; i < t.length; i++) i !== s && e.push(t[i]);
			return e.push(t[s]), e;
		}(t, i, n);
		return this.R_ = {
			Kh: t,
			du: i,
			fu: n,
			pu: e
		}, e;
	}
	vu(t, i) {
		i = ni(i, 0, this.bo.length - 1);
		const n = this.bo.indexOf(t);
		o(-1 !== n, "setSeriesOrder: invalid data source"), this.bo.splice(n, 1), this.bo.splice(i, 0, t), this.bo.forEach(((t, i) => t._n(i))), this.Z_();
		for (const t of [this.B_, this.A_]) t.a_(), t.vl();
		this.sn.mr();
	}
	Vt() {
		return this.Dt().filter(yi);
	}
	mu() {
		return this.I_;
	}
	wu() {
		return this.V_;
	}
	ol(t) {
		this.fa.push(new Ft(t));
	}
	_l(t) {
		this.fa = this.fa.filter(((i) => i.Qh() !== t)), t.detached && t.detached(), this.sn.mr();
	}
	Mu() {
		return this.fa;
	}
	il(t, i) {
		return this.fa.map(((n) => n.Qs(t, i))).filter(((t) => null !== t));
	}
	hu(t) {
		const i = t.g_();
		if (i && i.length > 0 && !this.ia.Zi()) {
			const i = this.ia.Ee();
			null !== i && t.b_(i);
		}
		t.Nn();
	}
	K_(t, i, n) {
		let s = this.O_(i);
		if (null === s && (s = this.E_(i, this.sn.N().overlayPriceScales)), this.bo.splice(n, 0, t), !Z(i)) {
			const n = this.P_.get(i) || [];
			n.push(t), this.P_.set(i, n);
		}
		t._n(n), s.h_(t), t.un(s), this.G_(s), this.Z_();
	}
	Z_() {
		this.xo = null, this.R_ = null;
	}
	ru() {
		return "left" === this.sn.N().defaultVisiblePriceScaleId ? [this.B_, this.A_] : [this.A_, this.B_];
	}
	L_(t, i, n) {
		i._e !== n._e && this.hu(t);
	}
	E_(t, i) {
		const s = new Ci(t, {
			visible: !0,
			autoScale: !0,
			...M(i)
		}, this.sn.N().layout, this.sn.N().localization, this.sn.Xi());
		return s.$o(this.$t()), s;
	}
};
function ki(t, i) {
	return null === i || 2 === t.se && 2 !== i.se || (2 !== i.se || 2 === t.se) && t.ne !== i.ne && t.ne < i.ne;
}
function Ti(t) {
	return {
		te: t.te,
		ie: t.ie
	};
}
function Ri(t) {
	return {
		ne: t.distance ?? 0,
		se: t.hitTestPriority ?? ("marker" === t.itemType ? 2 : 0),
		ee: t.itemType ?? "primitive",
		gu: t.cursorStyle,
		te: t.externalId
	};
}
function Di(t) {
	return {
		uu: t.uu,
		bu: Ti(t.Su),
		gu: t.Su.gu,
		ee: t.Su.ee ?? "primitive"
	};
}
function Ii(t, i, n, s) {
	let e = null;
	for (const r of t) {
		let t = r.Qs?.(i, n, s) ?? null;
		if (null === t) {
			const e = r.Tt(s);
			t = null !== e && e.Qs ? e.Qs(i, n) : null;
		}
		if (null !== t) {
			const i = {
				xu: r,
				Su: t
			};
			(null === e || ki(i.Su, e.Su)) && (e = i);
		}
	}
	return e;
}
function Vi(t) {
	return void 0 !== t.jn;
}
function Bi(t, i, n) {
	const s = [t, ...t.Dt()].reverse(), e = function(t, i, n) {
		let s, e, r;
		for (const l of t) {
			const t = l.il?.(i, n) ?? [];
			for (const i of t) {
				const t = Ri(i);
				h = i.zOrder, a = s?.zOrder, (!a || "top" === h && "top" !== a || "normal" === h && "bottom" === a || i.zOrder === s?.zOrder && void 0 !== e && ki(t, e) || i.zOrder === s?.zOrder && void 0 === e) && (s = i, e = t, r = l);
			}
		}
		var h, a;
		return s && r && e ? {
			Su: e,
			Cu: s,
			uu: r
		} : null;
	}(s, i, n);
	if ("top" === e?.Cu.zOrder) return Di(e);
	let r = null, h = null;
	for (const a of s) {
		if (e && e.uu === a && "bottom" !== e.Cu.zOrder && !e.Cu.isBackground) return r ?? Di(e);
		if (Vi(a)) {
			const s = Ii(a.jn(t), i, n, t);
			if (null !== s) {
				const t = {
					uu: a,
					xu: s.xu,
					bu: Ti(s.Su),
					gu: s.Su.gu,
					ee: s.Su.ee ?? "primitive"
				};
				(null === r || ki(s.Su, h)) && (r = t, h = s.Su);
			}
		}
		if (e && e.uu === a && "bottom" !== e.Cu.zOrder && e.Cu.isBackground) return r ?? Di(e);
	}
	return null !== r ? r : e?.Cu ? Di(e) : null;
}
var Ei = class {
	constructor(t, i, n = 50) {
		this.Vs = 0, this.Bs = 1, this.Es = 1, this.Ls = /* @__PURE__ */ new Map(), this.As = /* @__PURE__ */ new Map(), this.yu = t, this.Pu = i, this.zs = n;
	}
	ku(t) {
		const i = t.time, n = this.Pu.cacheKey(i), s = this.Ls.get(n);
		if (void 0 !== s) return s.Tu;
		if (this.Vs === this.zs) {
			const t = this.As.get(this.Es);
			this.As.delete(this.Es), this.Ls.delete(_(t)), this.Es++, this.Vs--;
		}
		const e = this.yu(t);
		return this.Ls.set(n, {
			Tu: e,
			Ws: this.Bs
		}), this.As.set(this.Bs, n), this.Vs++, this.Bs++, e;
	}
};
var Ai = class {
	constructor(t, i) {
		o(t <= i, "right should be >= left"), this.Ru = t, this.Du = i;
	}
	Na() {
		return this.Ru;
	}
	bi() {
		return this.Du;
	}
	Iu() {
		return this.Du - this.Ru + 1;
	}
	ze(t) {
		return this.Ru <= t && t <= this.Du;
	}
	Ze(t) {
		return this.Ru === t.Na() && this.Du === t.bi();
	}
};
function Li(t, i) {
	return null === t || null === i ? t === i : t.Ze(i);
}
var zi = class {
	constructor() {
		this.Vu = /* @__PURE__ */ new Map(), this.Ls = null, this.Bu = !1;
	}
	Eu(t) {
		this.Bu = t, this.Ls = null;
	}
	Au(t, i) {
		this.Lu(i), this.Ls = null;
		for (let n = i; n < t.length; ++n) {
			const i = t[n];
			let s = this.Vu.get(i.timeWeight);
			void 0 === s && (s = [], this.Vu.set(i.timeWeight, s)), s.push({
				index: n,
				time: i.time,
				weight: i.timeWeight,
				originalTime: i.originalTime
			});
		}
	}
	zu(t, i, n, s, e) {
		const r = Math.ceil(i / t);
		return null !== this.Ls && this.Ls.Ou === r && e === this.Ls.Nu && n === this.Ls.Fu || (this.Ls = {
			Nu: e,
			Fu: n,
			zl: this.Wu(r, n, s),
			Ou: r
		}), this.Ls.zl;
	}
	Lu(t) {
		if (0 === t) return void this.Vu.clear();
		const i = [];
		this.Vu.forEach(((n, s) => {
			t <= n[0].index ? i.push(s) : n.splice(Rt(n, t, ((i) => i.index < t)), 1 / 0);
		}));
		for (const t of i) this.Vu.delete(t);
	}
	Wu(t, i, n) {
		let s = [];
		const e = (t) => !i || n.has(t.index);
		for (const i of Array.from(this.Vu.keys()).sort(((t, i) => i - t))) {
			if (!this.Vu.get(i)) continue;
			const n = s;
			s = [];
			const r = n.length;
			let h = 0;
			const a = _(this.Vu.get(i)), l = a.length;
			let o = 1 / 0, u = -1 / 0;
			for (let i = 0; i < l; i++) {
				const l = a[i], _ = l.index;
				for (; h < r;) {
					const t = n[h], i = t.index;
					if (!(i < _ && e(t))) {
						o = i;
						break;
					}
					h++, s.push(t), u = i, o = 1 / 0;
				}
				if (o - _ >= t && _ - u >= t && e(l)) s.push(l), u = _;
				else if (this.Bu) return n;
			}
			for (; h < r; h++) e(n[h]) && s.push(n[h]);
		}
		return s;
	}
};
var Oi = class Oi {
	constructor(t) {
		this.Hu = t;
	}
	Uu() {
		return null === this.Hu ? null : new Ai(Math.floor(this.Hu.Na()), Math.ceil(this.Hu.bi()));
	}
	$u() {
		return this.Hu;
	}
	static ju() {
		return new Oi(null);
	}
};
function Ni(t, i) {
	return t.weight > i.weight ? t : i;
}
var Fi = class {
	constructor(t, i, n, s) {
		this.k_ = 0, this.qu = null, this.Yu = [], this.Po = null, this.yo = null, this.Ku = new zi(), this.Gu = /* @__PURE__ */ new Map(), this.Zu = Oi.ju(), this.Xu = !0, this.Ju = new d(), this.Qu = new d(), this.tc = new d(), this.nc = null, this.sc = null, this.ec = /* @__PURE__ */ new Map(), this.rc = -1, this.hc = [], this.ac = 1, this.yn = i, this.Do = n, this.lc = i.rightOffset, this.oc = i.barSpacing, this.sn = t, this._c(i), this.Pu = s, this.uc(), this.Ku.Eu(i.uniformDistribution), this.cc(), this.dc();
	}
	N() {
		return this.yn;
	}
	fc(t) {
		f(this.Do, t), this.vc(), this.uc();
	}
	vr(t, i) {
		f(this.yn, t), this.yn.fixLeftEdge && this.mc(), this.yn.fixRightEdge && this.wc(), void 0 !== t.barSpacing && this.sn.Ms(t.barSpacing), void 0 !== t.rightOffset && this.sn.gs(t.rightOffset), this._c(t), void 0 === t.minBarSpacing && void 0 === t.maxBarSpacing || this.sn.Ms(t.barSpacing ?? this.oc), void 0 !== t.ignoreWhitespaceIndices && t.ignoreWhitespaceIndices !== this.yn.ignoreWhitespaceIndices && this.dc(), this.vc(), this.uc(), void 0 === t.enableConflation && void 0 === t.conflationThresholdFactor || this.cc(), this.tc.p();
	}
	Rn(t) {
		return this.Yu[t]?.time ?? null;
	}
	en(t) {
		return this.Yu[t] ?? null;
	}
	Mc(t, i) {
		if (this.Yu.length < 1) return null;
		if (this.Pu.key(t) > this.Pu.key(this.Yu[this.Yu.length - 1].time)) return i ? this.Yu.length - 1 : null;
		const n = Rt(this.Yu, this.Pu.key(t), ((t, i) => this.Pu.key(t.time) < i));
		return this.Pu.key(t) < this.Pu.key(this.Yu[n].time) ? i ? n : null : n;
	}
	Zi() {
		return 0 === this.k_ || 0 === this.Yu.length || null === this.qu;
	}
	gc() {
		return this.Yu.length > 0;
	}
	Ee() {
		return this.bc(), this.Zu.Uu();
	}
	Sc() {
		return this.bc(), this.Zu.$u();
	}
	xc() {
		const t = this.Ee();
		if (null === t) return null;
		const i = {
			from: t.Na(),
			to: t.bi()
		};
		return this.Cc(i);
	}
	Cc(t) {
		const i = Math.round(t.from), n = Math.round(t.to), s = u(this.yc()), e = u(this.Pc());
		return {
			from: u(this.en(Math.max(s, i))),
			to: u(this.en(Math.min(e, n)))
		};
	}
	kc(t) {
		return {
			from: u(this.Mc(t.from, !0)),
			to: u(this.Mc(t.to, !0))
		};
	}
	nn() {
		return this.k_;
	}
	H_(t) {
		if (!isFinite(t) || t <= 0) return;
		if (this.k_ === t) return;
		const i = this.Sc(), n = this.k_;
		if (this.k_ = t, this.Xu = !0, this.yn.lockVisibleTimeRangeOnResize && 0 !== n) {
			const i = this.oc * t / n;
			this.oc = i;
		}
		if (this.yn.fixLeftEdge && null !== i && i.Na() <= 0) {
			const i = n - t;
			this.lc -= Math.round(i / this.oc) + 1, this.Xu = !0;
		}
		this.Tc(), this.Rc();
	}
	jt(t) {
		if (this.Zi() || !v(t)) return 0;
		const i = this.Dc() + this.lc - t;
		return this.k_ - (i + .5) * this.oc - 1;
	}
	Ic(t, i) {
		const n = this.Dc(), s = void 0 === i ? 0 : i.from, e = void 0 === i ? t.length : i.to;
		for (let i = s; i < e; i++) {
			const s = t[i].wt, e = n + this.lc - s, r = this.k_ - (e + .5) * this.oc - 1;
			t[i]._t = r;
		}
	}
	Vc(t, i) {
		const n = Math.ceil(this.Bc(t));
		return i && this.yn.ignoreWhitespaceIndices && !this.Ec(n) ? this.Ac(n) : n;
	}
	gs(t) {
		this.Xu = !0, this.lc = t, this.Rc(), this.sn.Lc(), this.sn.mr();
	}
	ml() {
		return this.oc;
	}
	Ms(t) {
		const i = this.oc;
		if (this.zc(t), void 0 !== this.yn.rightOffsetPixels && 0 !== i) {
			const t = this.lc * i / this.oc;
			this.lc = t;
		}
		this.Rc(), this.sn.Lc(), this.sn.mr();
	}
	Oc() {
		return this.lc;
	}
	zl() {
		if (this.Zi()) return null;
		if (null !== this.sc) return this.sc;
		const t = this.oc, i = 5 * (this.sn.N().layout.fontSize + 4) / 8 * (this.yn.tickMarkMaxCharacterLength || 8), n = Math.round(i / t), s = u(this.Ee()), e = Math.max(s.Na(), s.Na() - n), r = Math.max(s.bi(), s.bi() - n), h = this.Ku.zu(t, i, this.yn.ignoreWhitespaceIndices, this.ec, this.rc), a = this.yc() + n, l = this.Pc() - n, o = this.Nc(), _ = this.yn.fixLeftEdge || o, c = this.yn.fixRightEdge || o;
		let d = 0;
		for (const t of h) {
			if (!(e <= t.index && t.index <= r)) continue;
			let n;
			d < this.hc.length ? (n = this.hc[d], n.coord = this.jt(t.index), n.label = this.Fc(t), n.weight = t.weight) : (n = {
				needAlignCoordinate: !1,
				coord: this.jt(t.index),
				label: this.Fc(t),
				weight: t.weight
			}, this.hc.push(n)), this.oc > i / 2 && !o ? n.needAlignCoordinate = !1 : n.needAlignCoordinate = _ && t.index <= a || c && t.index >= l, d++;
		}
		return this.hc.length = d, this.sc = this.hc, this.hc;
	}
	Wc() {
		let t;
		this.Xu = !0, this.Ms(this.yn.barSpacing), t = void 0 !== this.yn.rightOffsetPixels ? this.yn.rightOffsetPixels / this.ml() : this.yn.rightOffset, this.gs(t);
	}
	Hc(t) {
		this.Xu = !0, this.qu = t, this.Rc(), this.mc();
	}
	Uc(t, i) {
		const n = this.Bc(t), s = this.ml(), e = s + i * (s / 10);
		this.Ms(e), this.yn.rightBarStaysOnScroll || this.gs(this.Oc() + (n - this.Bc(t)));
	}
	u_(t) {
		this.Po && this.v_(), null === this.yo && null === this.nc && (this.Zi() || (this.yo = t, this.$c()));
	}
	c_(t) {
		if (null === this.nc) return;
		const i = ni(this.k_ - t, 0, this.k_), n = ni(this.k_ - u(this.yo), 0, this.k_);
		0 !== i && 0 !== n && this.Ms(this.nc.ml * i / n);
	}
	d_() {
		null !== this.yo && (this.yo = null, this.jc());
	}
	f_(t) {
		null === this.Po && null === this.nc && (this.Zi() || (this.Po = t, this.$c()));
	}
	p_(t) {
		if (null === this.Po) return;
		const i = (this.Po - t) / this.ml();
		this.lc = u(this.nc).Oc + i, this.Xu = !0, this.Rc();
	}
	v_() {
		null !== this.Po && (this.Po = null, this.jc());
	}
	qc() {
		this.Yc(this.yn.rightOffset);
	}
	Yc(t, i = 400) {
		if (!isFinite(t)) throw new RangeError("offset is required and must be finite number");
		if (!isFinite(i) || i <= 0) throw new RangeError("animationDuration (optional) must be finite positive number");
		const n = this.lc, s = performance.now();
		this.sn.ps({
			Kc: (t) => (t - s) / i >= 1,
			Gc: (e) => {
				const r = (e - s) / i;
				return r >= 1 ? t : n + (t - n) * r;
			}
		});
	}
	Pt(t, i) {
		this.Xu = !0, this.Yu = t, this.Ku.Au(t, i), this.Rc();
	}
	Zc() {
		return this.Ju;
	}
	Xc() {
		return this.Qu;
	}
	Jc() {
		return this.tc;
	}
	Dc() {
		return this.qu || 0;
	}
	Qc(t, i) {
		const n = t.Iu(), s = i && this.yn.rightOffsetPixels || 0;
		this.zc((this.k_ - s) / n), this.lc = t.bi() - this.Dc(), i && (this.lc = s ? s / this.ml() : this.yn.rightOffset), this.Rc(), this.Xu = !0, this.sn.Lc(), this.sn.mr();
	}
	td() {
		const t = this.yc(), i = this.Pc();
		if (null === t || null === i) return;
		const n = !this.yn.rightOffsetPixels && this.yn.rightOffset || 0;
		this.Qc(new Ai(t, i + n), !0);
	}
	nd(t) {
		const i = new Ai(t.from, t.to);
		this.Qc(i);
	}
	rn(t) {
		return void 0 !== this.Do.timeFormatter ? this.Do.timeFormatter(t.originalTime) : this.Pu.formatHorzItem(t.time);
	}
	dc() {
		if (!this.yn.ignoreWhitespaceIndices) return;
		this.ec.clear();
		const t = this.sn.Jn();
		for (const i of t) for (const t of i.fl()) this.ec.set(t, !0);
		this.rc++;
	}
	sd() {
		return this.ac;
	}
	Sl() {
		const t = 1 / (window.devicePixelRatio || 1), i = this.yn.minBarSpacing;
		if (i >= t) return [1];
		const n = [1];
		let s = 2;
		for (; s <= 512;) i < t / s && n.push(s), s *= 2;
		return n;
	}
	Nc() {
		const t = this.sn.N().handleScroll, i = this.sn.N().handleScale;
		return !(t.horzTouchDrag || t.mouseWheel || t.pressedMouseMove || t.vertTouchDrag || i.axisDoubleClickReset.time || i.axisPressedMouseMove.time || i.mouseWheel || i.pinch);
	}
	yc() {
		return 0 === this.Yu.length ? null : 0;
	}
	Pc() {
		return 0 === this.Yu.length ? null : this.Yu.length - 1;
	}
	ed(t) {
		return (this.k_ - 1 - t) / this.oc;
	}
	Bc(t) {
		const i = this.ed(t), n = this.Dc() + this.lc - i;
		return Math.round(1e6 * n) / 1e6;
	}
	zc(t) {
		const i = this.oc;
		this.oc = t, this.Tc(), i !== this.oc && (this.Xu = !0, this.rd(), this.cc());
	}
	bc() {
		if (!this.Xu) return;
		if (this.Xu = !1, this.Zi()) return void this.hd(Oi.ju());
		const t = this.Dc(), i = this.k_ / this.oc, n = this.lc + t, s = new Ai(n - i + 1, n);
		this.hd(new Oi(s));
	}
	Tc() {
		const t = ni(this.oc, this.ad(), this.ld());
		this.oc !== t && (this.oc = t, this.Xu = !0);
	}
	ld() {
		return this.yn.maxBarSpacing > 0 ? this.yn.maxBarSpacing : .5 * this.k_;
	}
	ad() {
		return this.yn.fixLeftEdge && this.yn.fixRightEdge && 0 !== this.Yu.length ? this.k_ / this.Yu.length : this.yn.minBarSpacing;
	}
	cc() {
		if (!this.yn.enableConflation) return void (this.ac = 1);
		const t = 1 / (window.devicePixelRatio || 1) * (this.yn.conflationThresholdFactor ?? 1);
		if (this.oc >= t) return void (this.ac = 1);
		const i = t / this.oc, n = Math.pow(2, Math.floor(Math.log2(i)));
		this.ac = Math.min(n, 512);
	}
	Rc() {
		const t = this.od();
		null !== t && this.lc < t && (this.lc = t, this.Xu = !0);
		const i = this._d();
		this.lc > i && (this.lc = i, this.Xu = !0);
	}
	od() {
		const t = this.yc(), i = this.qu;
		if (null === t || null === i) return null;
		return t - i - 1 + (this.yn.fixLeftEdge ? this.k_ / this.oc : Math.min(2, this.Yu.length));
	}
	_d() {
		return this.yn.fixRightEdge ? 0 : this.k_ / this.oc - Math.min(2, this.Yu.length);
	}
	$c() {
		this.nc = {
			ml: this.ml(),
			Oc: this.Oc()
		};
	}
	jc() {
		this.nc = null;
	}
	Fc(t) {
		let i = this.Gu.get(t.weight);
		return void 0 === i && (i = new Ei(((t) => this.ud(t)), this.Pu), this.Gu.set(t.weight, i)), i.ku(t);
	}
	ud(t) {
		return this.Pu.formatTickmark(t, this.Do);
	}
	hd(t) {
		const i = this.Zu;
		this.Zu = t, Li(i.Uu(), this.Zu.Uu()) || this.Ju.p(), Li(i.$u(), this.Zu.$u()) || this.Qu.p(), this.rd();
	}
	rd() {
		this.sc = null;
	}
	vc() {
		this.rd(), this.Gu.clear();
	}
	uc() {
		this.Pu.updateFormatter(this.Do);
	}
	mc() {
		if (!this.yn.fixLeftEdge) return;
		const t = this.yc();
		if (null === t) return;
		const i = this.Ee();
		if (null === i) return;
		const n = i.Na() - t;
		if (n < 0) {
			const t = this.lc - n - 1;
			this.gs(t);
		}
		this.Tc();
	}
	wc() {
		this.Rc(), this.Tc();
	}
	Ec(t) {
		return !this.yn.ignoreWhitespaceIndices || this.ec.get(t) || !1;
	}
	Ac(t) {
		const i = function* (t) {
			const i = Math.round(t), n = i < t;
			let s = 1;
			for (;;) n ? (yield i + s, yield i - s) : (yield i - s, yield i + s), s++;
		}(t), n = this.Pc();
		for (; n;) {
			const t = i.next().value;
			if (this.ec.get(t)) return t;
			if (t < 0 || t > n) break;
		}
		return t;
	}
	_c(t) {
		if (void 0 !== t.rightOffsetPixels) {
			const i = t.rightOffsetPixels / (t.barSpacing || this.oc);
			this.sn.gs(i);
		}
	}
};
var Wi;
var Hi;
var Ui;
var $i;
var ji;
(function(t) {
	t[t.OnTouchEnd = 0] = "OnTouchEnd", t[t.OnNextTap = 1] = "OnNextTap";
})(Wi || (Wi = {}));
var qi = class {
	constructor(t, i, n) {
		this.dd = [], this.fd = [], this.pd = null, this.k_ = 0, this.vd = null, this.md = new d(), this.wd = new d(), this.Md = null, this.gd = t, this.yn = i, this.Pu = n, this.Io = new k(this.yn.layout.colorParsers), this.bd = new C(this), this.ia = new Fi(this, i.timeScale, this.yn.localization, n), this.Ct = new G(this, i.crosshair), this.Sd = new ii(i.crosshair), i.addDefaultPane && (this.xd(0), this.dd[0].W_(2)), this.Cd = this.yd(0), this.Pd = this.yd(1);
	}
	ka() {
		this.kd(X.ys());
	}
	mr() {
		this.kd(X.Cs());
	}
	Ya() {
		this.kd(new X(1));
	}
	Ta(t) {
		const i = this.Td(t);
		this.kd(i);
	}
	cu() {
		return this.vd;
	}
	Rd(t) {
		if (this.vd?.uu === t?.uu && this.vd?.bu?.te === t?.bu?.te && this.vd?.bu?.ie === t?.bu?.ie && this.vd?.gu === t?.gu && this.vd?.ee === t?.ee) return;
		const i = this.vd;
		this.vd = t, null !== i && this.Ta(i.uu), null !== t && t.uu !== i?.uu && this.Ta(t.uu);
	}
	N() {
		return this.yn;
	}
	vr(t) {
		f(this.yn, t), this.dd.forEach(((i) => i.z_(t))), void 0 !== t.timeScale && this.ia.vr(t.timeScale), void 0 !== t.localization && this.ia.fc(t.localization), (t.leftPriceScale || t.rightPriceScale) && this.md.p(), this.Cd = this.yd(0), this.Pd = this.yd(1), this.ka();
	}
	Dd(t, i, n = 0) {
		const s = this.dd[n];
		if (void 0 === s) return;
		if ("left" === t) return f(this.yn, { leftPriceScale: i }), s.z_({ leftPriceScale: i }), this.md.p(), void this.ka();
		if ("right" === t) return f(this.yn, { rightPriceScale: i }), s.z_({ rightPriceScale: i }), this.md.p(), void this.ka();
		const e = this.Id(t, n);
		null !== e && (e.Ft.vr(i), this.md.p());
	}
	Id(t, i) {
		const n = this.dd[i];
		if (void 0 === n) return null;
		const s = n.O_(t);
		return null !== s ? {
			Kn: n,
			Ft: s
		} : null;
	}
	Et() {
		return this.ia;
	}
	Gn() {
		return this.dd;
	}
	Vd() {
		return this.Ct;
	}
	Bd() {
		return this.wd;
	}
	Ed(t, i) {
		t.$o(i), this.Lc();
	}
	H_(t) {
		this.k_ = t, this.ia.H_(this.k_), this.dd.forEach(((i) => i.H_(t))), this.Lc();
	}
	Ad(t) {
		1 !== this.dd.length && (o(t >= 0 && t < this.dd.length, "Invalid pane index"), this.dd.splice(t, 1), this.ka());
	}
	Ld(t, i) {
		if (this.dd.length < 2) return;
		o(t >= 0 && t < this.dd.length, "Invalid pane index");
		const n = this.dd[t], s = this.dd.reduce(((t, i) => t + i.F_()), 0), e = this.dd.reduce(((t, i) => t + i.$t()), 0), r = e - 30 * (this.dd.length - 1);
		i = Math.min(r, Math.max(30, i));
		const h = s / e, a = n.$t();
		n.W_(i * h);
		let l = i - a, _ = this.dd.length - 1;
		for (const t of this.dd) if (t !== n) {
			const i = Math.min(r, Math.max(30, t.$t() - l / _));
			l -= t.$t() - i, _ -= 1;
			const n = i * h;
			t.W_(n);
		}
		this.ka();
	}
	zd(t, i) {
		o(t >= 0 && t < this.dd.length && i >= 0 && i < this.dd.length, "Invalid pane index");
		const n = this.dd[t], s = this.dd[i];
		this.dd[t] = s, this.dd[i] = n, this.ka();
	}
	Od(t, i) {
		if (o(t >= 0 && t < this.dd.length && i >= 0 && i < this.dd.length, "Invalid pane index"), t === i) return;
		const [n] = this.dd.splice(t, 1);
		this.dd.splice(i, 0, n), this.ka();
	}
	Q_(t, i, n) {
		t.Q_(i, n);
	}
	tu(t, i, n) {
		t.tu(i, n), this.Ra(), this.kd(this.Nd(t, 2));
	}
	iu(t, i) {
		t.iu(i), this.kd(this.Nd(t, 2));
	}
	nu(t, i, n) {
		i.zo() || t.nu(i, n);
	}
	su(t, i, n) {
		i.zo() || (t.su(i, n), this.Ra(), this.kd(this.Nd(t, 2)));
	}
	eu(t, i) {
		i.zo() || (t.eu(i), this.kd(this.Nd(t, 2)));
	}
	au(t, i) {
		t.au(i), this.kd(this.Nd(t, 2));
	}
	Fd(t) {
		this.ia.u_(t);
	}
	Wd(t, i) {
		const n = this.Et();
		if (n.Zi() || 0 === i) return;
		const s = n.nn();
		t = Math.max(1, Math.min(t, s)), n.Uc(t, i), this.Lc();
	}
	Hd(t) {
		this.Ud(0), this.$d(t), this.jd();
	}
	qd(t) {
		this.ia.c_(t), this.Lc();
	}
	Yd() {
		this.ia.d_(), this.mr();
	}
	Ud(t) {
		this.ia.f_(t);
	}
	$d(t) {
		this.ia.p_(t), this.Lc();
	}
	jd() {
		this.ia.v_(), this.mr();
	}
	Jn() {
		return this.fd;
	}
	Wn() {
		return null === this.pd && (this.pd = this.fd.filter(((t) => t.It()))), this.pd;
	}
	Pa() {
		this.pd = null;
	}
	Kd(t, i, n, s, e) {
		this.Ct.In(t, i);
		let r = NaN, h = this.ia.Vc(t, !0);
		const a = this.ia.Ee();
		null !== a && (h = Math.min(Math.max(a.Na(), h), a.bi())), h = this.Ct.Fn(h);
		const l = s.kn(), o = l.Lt();
		if (null !== o && (r = l.Tn(i, o)), r = this.Sd.Pl(r, h, s), this.Ct.An(h, r, s), this.Ya(), !e) {
			const e = Bi(s, t, i);
			this.Rd(e && {
				uu: e.uu,
				bu: e.bu,
				gu: e.gu || null,
				ee: e.ee
			}), this.wd.p(this.Ct.Bt(), {
				x: t,
				y: i
			}, n);
		}
	}
	Gd(t, i, n) {
		const s = n.kn(), e = s.Lt(), r = s.Nt(t, u(e)), h = this.ia.Mc(i, !0), a = this.ia.jt(u(h));
		this.Kd(a, r, null, n, !0);
	}
	Zd(t) {
		this.Vd().zn(), this.Ya(), t || this.wd.p(null, null, null);
	}
	Ra() {
		const t = this.Ct.Kn();
		if (null !== t) {
			const i = this.Ct.Bn(), n = this.Ct.En();
			this.Kd(i, n, null, t);
		}
		this.Ct.Nn();
	}
	Xd(t, i, n) {
		const s = this.ia.Rn(0);
		void 0 !== i && void 0 !== n && this.ia.Pt(i, n);
		const e = this.ia.Rn(0), r = this.ia.Dc(), h = this.ia.Ee();
		if (null !== h && null !== s && null !== e) {
			const i = h.ze(r), a = this.Pu.key(s) > this.Pu.key(e), l = null !== t && t > r && !a, o = this.ia.N().allowShiftVisibleRangeOnWhitespaceReplacement, _ = i && (!(void 0 === n) || o) && this.ia.N().shiftVisibleRangeOnNewBar;
			if (l && !_) {
				const i = t - r;
				this.ia.gs(this.ia.Oc() - i);
			}
		}
		this.ia.Hc(t);
	}
	Ba(t) {
		null !== t && t.ou();
	}
	Ks(t) {
		if (function(t) {
			return t instanceof Pi;
		}(t)) return t;
		const i = this.dd.find(((i) => i.Dt().includes(t)));
		return void 0 === i ? null : i;
	}
	Lc() {
		this.dd.forEach(((t) => t.ou())), this.Ra();
	}
	m() {
		this.dd.forEach(((t) => t.m())), this.dd.length = 0, this.yn.localization.priceFormatter = void 0, this.yn.localization.percentageFormatter = void 0, this.yn.localization.timeFormatter = void 0;
	}
	Jd() {
		return this.bd;
	}
	Js() {
		return this.bd.N();
	}
	N_() {
		return this.md;
	}
	Qd(t, i) {
		const n = this.xd(i);
		this.tf(t, n), this.fd.push(t), this.Pa(), 1 === this.fd.length ? this.ka() : this.mr();
	}
	if(t) {
		const i = this.Ks(t), n = this.fd.indexOf(t);
		o(-1 !== n, "Series not found");
		const s = u(i);
		this.fd.splice(n, 1), s.l_(t), t.m && t.m(), this.Pa(), this.ia.dc(), this.nf(s);
	}
	ya(t, i) {
		const n = u(this.Ks(t));
		n.l_(t, !0), n.h_(t, i, !0);
	}
	td() {
		const t = X.Cs();
		t.us(), this.kd(t);
	}
	sf(t) {
		const i = X.Cs();
		i.fs(t), this.kd(i);
	}
	ws() {
		const t = X.Cs();
		t.ws(), this.kd(t);
	}
	Ms(t) {
		const i = X.Cs();
		i.Ms(t), this.kd(i);
	}
	gs(t) {
		const i = X.Cs();
		i.gs(t), this.kd(i);
	}
	ps(t) {
		const i = X.Cs();
		i.ps(t), this.kd(i);
	}
	cs() {
		const t = X.Cs();
		t.cs(), this.kd(t);
	}
	ef() {
		const t = this.yn.defaultVisiblePriceScaleId, i = this.yn.leftPriceScale.visible;
		return i !== this.yn.rightPriceScale.visible ? i ? "left" : "right" : t;
	}
	rf(t, i) {
		o(i >= 0, "Index should be greater or equal to 0");
		if (i === this.hf(t)) return;
		const n = u(this.Ks(t));
		n.l_(t);
		const s = this.xd(i);
		this.tf(t, s);
		let e = !1;
		0 === n.kl().length && (e = this.nf(n)), e || this.ka();
	}
	af() {
		return this.Pd;
	}
	$() {
		return this.Cd;
	}
	Ut(t) {
		const i = this.Pd, n = this.Cd;
		if (i === n) return i;
		if (t = Math.max(0, Math.min(100, Math.round(100 * t))), null === this.Md || this.Md.ah !== n || this.Md.oh !== i) this.Md = {
			ah: n,
			oh: i,
			lf: /* @__PURE__ */ new Map()
		};
		else {
			const i = this.Md.lf.get(t);
			if (void 0 !== i) return i;
		}
		const s = this.Io.tt(n, i, t / 100);
		return this.Md.lf.set(t, s), s;
	}
	_f(t) {
		return this.dd.indexOf(t);
	}
	Xi() {
		return this.Io;
	}
	uf() {
		return this.cf();
	}
	cf(t) {
		const i = new Pi(this.ia, this);
		this.dd.push(i);
		const n = t ?? this.dd.length - 1, s = X.ys();
		return s.es(n, {
			rs: 0,
			hs: !0
		}), this.kd(s), i;
	}
	xd(t) {
		return o(t >= 0, "Index should be greater or equal to 0"), (t = Math.min(this.dd.length, t)) < this.dd.length ? this.dd[t] : this.cf(t);
	}
	hf(t) {
		return this.dd.findIndex(((i) => i.Y_().includes(t)));
	}
	Nd(t, i) {
		const n = new X(i);
		if (null !== t) {
			const s = this.dd.indexOf(t);
			n.es(s, { rs: i });
		}
		return n;
	}
	Td(t, i) {
		return void 0 === i && (i = 2), this.Nd(this.Ks(t), i);
	}
	kd(t) {
		this.gd && this.gd(t), this.dd.forEach(((t) => t.wu().wr().Pt()));
	}
	tf(t, i) {
		const n = t.N().priceScaleId, s = void 0 !== n ? n : this.ef();
		i.h_(t, s), Z(s) || t.vr(t.N());
	}
	yd(t) {
		const i = this.yn.layout;
		return "gradient" === i.background.type ? 0 === t ? i.background.topColor : i.background.bottomColor : i.background.color;
	}
	nf(t) {
		return !t.q_() && 0 === t.kl().length && this.dd.length > 1 && (this.dd.splice(this._f(t), 1), this.ka(), !0);
	}
};
function Yi(t) {
	if (t >= 1) return 0;
	let i = 0;
	for (; i < 8; i++) {
		if (Math.abs(Math.round(t) - t) < 1e-8) return i;
		t *= 10;
	}
	return i;
}
function Ki(t) {
	return !p(t) && !m(t);
}
function Gi(t) {
	return p(t);
}
(function(t) {
	t[t.Disabled = 0] = "Disabled", t[t.Continuous = 1] = "Continuous", t[t.OnDataUpdate = 2] = "OnDataUpdate";
})(Hi || (Hi = {})), function(t) {
	t[t.LastBar = 0] = "LastBar", t[t.LastVisible = 1] = "LastVisible";
}(Ui || (Ui = {})), function(t) {
	t.Solid = "solid", t.VerticalGradient = "gradient";
}($i || ($i = {})), function(t) {
	t[t.Year = 0] = "Year", t[t.Month = 1] = "Month", t[t.DayOfMonth = 2] = "DayOfMonth", t[t.Time = 3] = "Time", t[t.TimeWithSeconds = 4] = "TimeWithSeconds";
}(ji || (ji = {}));
var Zi = (t) => t.getUTCFullYear();
function Xi(t, i, n) {
	return i.replace(/yyyy/g, ((t) => tt(Zi(t), 4))(t)).replace(/yy/g, ((t) => tt(Zi(t) % 100, 2))(t)).replace(/MMMM/g, ((t, i) => new Date(t.getUTCFullYear(), t.getUTCMonth(), 1).toLocaleString(i, { month: "long" }))(t, n)).replace(/MMM/g, ((t, i) => new Date(t.getUTCFullYear(), t.getUTCMonth(), 1).toLocaleString(i, { month: "short" }))(t, n)).replace(/MM/g, ((t) => tt(((t) => t.getUTCMonth() + 1)(t), 2))(t)).replace(/dd/g, ((t) => tt(((t) => t.getUTCDate())(t), 2))(t));
}
var Ji = class {
	constructor(t = "yyyy-MM-dd", i = "default") {
		this.df = t, this.ff = i;
	}
	ku(t) {
		return Xi(t, this.df, this.ff);
	}
};
var Qi = class {
	constructor(t) {
		this.pf = t || "%h:%m:%s";
	}
	ku(t) {
		return this.pf.replace("%h", tt(t.getUTCHours(), 2)).replace("%m", tt(t.getUTCMinutes(), 2)).replace("%s", tt(t.getUTCSeconds(), 2));
	}
};
var tn = {
	vf: "yyyy-MM-dd",
	mf: "%h:%m:%s",
	wf: " ",
	Mf: "default"
};
var nn = class {
	constructor(t = {}) {
		const i = {
			...tn,
			...t
		};
		this.gf = new Ji(i.vf, i.Mf), this.bf = new Qi(i.mf), this.Sf = i.wf;
	}
	ku(t) {
		return `${this.gf.ku(t)}${this.Sf}${this.bf.ku(t)}`;
	}
};
function sn(t) {
	return 60 * t * 60 * 1e3;
}
function en(t) {
	return 60 * t * 1e3;
}
var rn = [
	{
		xf: (hn = 1, 1e3 * hn),
		Cf: 10
	},
	{
		xf: en(1),
		Cf: 20
	},
	{
		xf: en(5),
		Cf: 21
	},
	{
		xf: en(30),
		Cf: 22
	},
	{
		xf: sn(1),
		Cf: 30
	},
	{
		xf: sn(3),
		Cf: 31
	},
	{
		xf: sn(6),
		Cf: 32
	},
	{
		xf: sn(12),
		Cf: 33
	}
];
var hn;
function an(t, i) {
	if (t.getUTCFullYear() !== i.getUTCFullYear()) return 70;
	if (t.getUTCMonth() !== i.getUTCMonth()) return 60;
	if (t.getUTCDate() !== i.getUTCDate()) return 50;
	for (let n = rn.length - 1; n >= 0; --n) if (Math.floor(i.getTime() / rn[n].xf) !== Math.floor(t.getTime() / rn[n].xf)) return rn[n].Cf;
	return 0;
}
function ln(t) {
	let i = t;
	if (m(t) && (i = _n(t)), !Ki(i)) throw new Error("time must be of type BusinessDay");
	const n = new Date(Date.UTC(i.year, i.month - 1, i.day, 0, 0, 0, 0));
	return {
		yf: Math.round(n.getTime() / 1e3),
		Pf: i
	};
}
function on(t) {
	if (!Gi(t)) throw new Error("time must be of type isUTCTimestamp");
	return { yf: t };
}
function _n(t) {
	const i = new Date(t);
	if (isNaN(i.getTime())) throw new Error(`Invalid date string=${t}, expected format=yyyy-mm-dd`);
	return {
		day: i.getUTCDate(),
		month: i.getUTCMonth() + 1,
		year: i.getUTCFullYear()
	};
}
function un(t) {
	m(t.time) && (t.time = _n(t.time));
}
var cn = class {
	options() {
		return this.yn;
	}
	setOptions(t) {
		this.yn = t, this.updateFormatter(t.localization);
	}
	preprocessData(t) {
		Array.isArray(t) ? function(t) {
			t.forEach(un);
		}(t) : un(t);
	}
	createConverterToInternalObj(t) {
		return u(function(t) {
			return 0 === t.length ? null : Ki(t[0].time) || m(t[0].time) ? ln : on;
		}(t));
	}
	key(t) {
		return "object" == typeof t && "yf" in t ? t.yf : this.key(this.convertHorzItemToInternal(t));
	}
	cacheKey(t) {
		const i = t;
		return void 0 === i.Pf ? (/* @__PURE__ */ new Date(1e3 * i.yf)).getTime() : new Date(Date.UTC(i.Pf.year, i.Pf.month - 1, i.Pf.day)).getTime();
	}
	convertHorzItemToInternal(t) {
		return Gi(i = t) ? on(i) : Ki(i) ? ln(i) : ln(_n(i));
		var i;
	}
	updateFormatter(t) {
		if (!this.yn) return;
		const i = t.dateFormat;
		this.yn.timeScale.timeVisible ? this.kf = new nn({
			vf: i,
			mf: this.yn.timeScale.secondsVisible ? "%h:%m:%s" : "%h:%m",
			wf: "   ",
			Mf: t.locale
		}) : this.kf = new Ji(i, t.locale);
	}
	formatHorzItem(t) {
		const i = t;
		return this.kf.ku(/* @__PURE__ */ new Date(1e3 * i.yf));
	}
	formatTickmark(t, i) {
		const n = function(t, i, n) {
			switch (t) {
				case 0:
				case 10: return i ? n ? 4 : 3 : 2;
				case 20:
				case 21:
				case 22:
				case 30:
				case 31:
				case 32:
				case 33: return i ? 3 : 2;
				case 50: return 2;
				case 60: return 1;
				case 70: return 0;
			}
		}(t.weight, this.yn.timeScale.timeVisible, this.yn.timeScale.secondsVisible), s = this.yn.timeScale;
		if (void 0 !== s.tickMarkFormatter) {
			const e = s.tickMarkFormatter(t.originalTime, n, i.locale);
			if (null !== e) return e;
		}
		return function(t, i, n) {
			const s = {};
			switch (i) {
				case 0:
					s.year = "numeric";
					break;
				case 1:
					s.month = "short";
					break;
				case 2:
					s.day = "numeric";
					break;
				case 3:
					s.hour12 = !1, s.hour = "2-digit", s.minute = "2-digit";
					break;
				case 4: s.hour12 = !1, s.hour = "2-digit", s.minute = "2-digit", s.second = "2-digit";
			}
			const e = void 0 === t.Pf ? /* @__PURE__ */ new Date(1e3 * t.yf) : new Date(Date.UTC(t.Pf.year, t.Pf.month - 1, t.Pf.day));
			return new Date(e.getUTCFullYear(), e.getUTCMonth(), e.getUTCDate(), e.getUTCHours(), e.getUTCMinutes(), e.getUTCSeconds(), e.getUTCMilliseconds()).toLocaleString(n, s);
		}(t.time, n, i.locale);
	}
	maxTickMarkWeight(t) {
		let i = t.reduce(Ni, t[0]).weight;
		return i > 30 && i < 50 && (i = 30), i;
	}
	fillWeightsForPoints(t, i) {
		(function(t, i = 0) {
			if (0 === t.length) return;
			let n = 0 === i ? null : t[i - 1].time.yf, s = null !== n ? /* @__PURE__ */ new Date(1e3 * n) : null, e = 0;
			for (let r = i; r < t.length; ++r) {
				const i = t[r], h = /* @__PURE__ */ new Date(1e3 * i.time.yf);
				null !== s && (i.timeWeight = an(h, s)), e += i.time.yf - (n || i.time.yf), n = i.time.yf, s = h;
			}
			if (0 === i && t.length > 1) {
				const i = Math.ceil(e / (t.length - 1)), n = /* @__PURE__ */ new Date(1e3 * (t[0].time.yf - i));
				t[0].timeWeight = an(/* @__PURE__ */ new Date(1e3 * t[0].time.yf), n);
			}
		})(t, i);
	}
	static Tf(t) {
		return f({ localization: { dateFormat: "dd MMM 'yy" } }, t ?? {});
	}
};
var dn = "undefined" != typeof window;
function fn() {
	return !!dn && window.navigator.userAgent.toLowerCase().indexOf("firefox") > -1;
}
function pn() {
	return !!dn && /iPhone|iPad|iPod/.test(window.navigator.platform);
}
function vn(t, i) {
	switch (t) {
		case "custom": return void 0 !== i ? "custom-object" : "series";
		case "price-line": return "custom-price-line";
		case "marker": return "series-marker";
		case "primitive": return "primitive";
		default: return "series";
	}
}
function mn(t) {
	return t + t % 2;
}
function wn(t) {
	dn && void 0 !== window.chrome && t.addEventListener("mousedown", ((t) => {
		if (1 === t.button) return t.preventDefault(), !1;
	}));
}
var Mn = class {
	constructor(t, i, n) {
		this.Rf = 0, this.Df = null, this.If = {
			_t: Number.NEGATIVE_INFINITY,
			ut: Number.POSITIVE_INFINITY
		}, this.Vf = 0, this.Bf = null, this.Ef = {
			_t: Number.NEGATIVE_INFINITY,
			ut: Number.POSITIVE_INFINITY
		}, this.Af = null, this.Lf = !1, this.zf = null, this.Of = null, this.Nf = !1, this.Ff = !1, this.Wf = !1, this.Hf = null, this.Uf = null, this.$f = null, this.jf = null, this.qf = null, this.Yf = null, this.Kf = null, this.Gf = 0, this.Zf = !1, this.Xf = !1, this.Jf = !1, this.Qf = 0, this.tp = null, this.ip = !pn(), this.np = (t) => {
			this.sp(t);
		}, this.ep = (t) => {
			if (this.rp(t)) {
				const i = this.hp(t);
				if (++this.Vf, this.Bf && this.Vf > 1) {
					const { ap: n } = this.lp(Sn(t), this.Ef);
					n < 30 && !this.Wf && this.op(i, this.up._p), this.cp();
				}
			} else {
				const i = this.hp(t);
				if (++this.Rf, this.Df && this.Rf > 1) {
					const { ap: n } = this.lp(Sn(t), this.If);
					n < 5 && !this.Ff && this.dp(i, this.up.fp), this.pp();
				}
			}
		}, this.vp = t, this.up = i, this.yn = n, this.mp();
	}
	m() {
		null !== this.Hf && (this.Hf(), this.Hf = null), null !== this.Uf && (this.Uf(), this.Uf = null), null !== this.jf && (this.jf(), this.jf = null), null !== this.qf && (this.qf(), this.qf = null), null !== this.Yf && (this.Yf(), this.Yf = null), null !== this.$f && (this.$f(), this.$f = null), this.wp(), this.pp();
	}
	Mp(t) {
		this.jf && this.jf();
		const i = this.gp.bind(this);
		if (this.jf = () => {
			this.vp.removeEventListener("mousemove", i);
		}, this.vp.addEventListener("mousemove", i), this.rp(t)) return;
		const n = this.hp(t);
		this.dp(n, this.up.bp), this.ip = !0;
	}
	pp() {
		null !== this.Df && clearTimeout(this.Df), this.Rf = 0, this.Df = null, this.If = {
			_t: Number.NEGATIVE_INFINITY,
			ut: Number.POSITIVE_INFINITY
		};
	}
	cp() {
		null !== this.Bf && clearTimeout(this.Bf), this.Vf = 0, this.Bf = null, this.Ef = {
			_t: Number.NEGATIVE_INFINITY,
			ut: Number.POSITIVE_INFINITY
		};
	}
	gp(t) {
		if (this.Jf || null !== this.Of) return;
		if (this.rp(t)) return;
		const i = this.hp(t);
		this.dp(i, this.up.Sp), this.ip = !0;
	}
	xp(t) {
		const i = Cn(t.changedTouches, u(this.tp));
		if (null === i) return;
		if (this.Qf = xn(t), null !== this.Kf) return;
		if (this.Xf) return;
		this.Zf = !0;
		const { Cp: s, yp: e, ap: r } = this.lp(Sn(i), u(this.Of));
		if (this.Nf || !(r < 5)) {
			if (!this.Nf) {
				const t = .5 * s, i = e >= t && !this.yn.Pp(), n = t > e && !this.yn.kp();
				i || n || (this.Xf = !0), this.Nf = !0, this.Wf = !0, this.wp(), this.cp();
			}
			if (!this.Xf) {
				const n = this.hp(t, i);
				this.op(n, this.up.Tp), bn(t);
			}
		}
	}
	Rp(t) {
		if (0 !== t.button) return;
		const { ap: n } = this.lp(Sn(t), u(this.zf));
		if (n >= 5 && (this.Ff = !0, this.pp()), this.Ff) {
			const i = this.hp(t);
			this.dp(i, this.up.Dp);
		}
	}
	lp(t, i) {
		const n = Math.abs(i._t - t._t), s = Math.abs(i.ut - t.ut);
		return {
			Cp: n,
			yp: s,
			ap: n + s
		};
	}
	Ip(t) {
		let i = Cn(t.changedTouches, u(this.tp));
		if (null === i && 0 === t.touches.length && (i = t.changedTouches[0]), null === i) return;
		this.tp = null, this.Qf = xn(t), this.wp(), this.Of = null, this.Yf && (this.Yf(), this.Yf = null);
		const n = this.hp(t, i);
		if (this.op(n, this.up.Vp), ++this.Vf, this.Bf && this.Vf > 1) {
			const { ap: t } = this.lp(Sn(i), this.Ef);
			t < 30 && !this.Wf && this.op(n, this.up._p), this.cp();
		} else this.Wf || (this.op(n, this.up.Bp), this.up.Bp && bn(t));
		0 === this.Vf && bn(t), 0 === t.touches.length && this.Lf && (this.Lf = !1, bn(t));
	}
	sp(t) {
		if (0 !== t.button) return;
		const i = this.hp(t);
		if (this.zf = null, this.Jf = !1, this.qf && (this.qf(), this.qf = null), fn()) this.vp.ownerDocument.documentElement.removeEventListener("mouseleave", this.np);
		if (!this.rp(t)) if (this.dp(i, this.up.Ep), ++this.Rf, this.Df && this.Rf > 1) {
			const { ap: n } = this.lp(Sn(t), this.If);
			n < 5 && !this.Ff && this.dp(i, this.up.fp), this.pp();
		} else this.Ff || this.dp(i, this.up.Ap);
	}
	wp() {
		null !== this.Af && (clearTimeout(this.Af), this.Af = null);
	}
	Lp(t) {
		if (null !== this.tp) return;
		const i = t.changedTouches[0];
		this.tp = i.identifier, this.Qf = xn(t);
		const n = this.vp.ownerDocument.documentElement;
		this.Wf = !1, this.Nf = !1, this.Xf = !1, this.Of = Sn(i), this.Yf && (this.Yf(), this.Yf = null);
		{
			const i = this.xp.bind(this), s = this.Ip.bind(this);
			this.Yf = () => {
				n.removeEventListener("touchmove", i), n.removeEventListener("touchend", s);
			}, n.addEventListener("touchmove", i, { passive: !1 }), n.addEventListener("touchend", s, { passive: !1 }), this.wp(), this.Af = setTimeout(this.zp.bind(this, t), 240);
		}
		const s = this.hp(t, i);
		this.op(s, this.up.Op), this.Bf || (this.Vf = 0, this.Bf = setTimeout(this.cp.bind(this), 500), this.Ef = Sn(i));
	}
	Np(t) {
		if (0 !== t.button) return;
		const i = this.vp.ownerDocument.documentElement;
		fn() && i.addEventListener("mouseleave", this.np), this.Ff = !1, this.zf = Sn(t), this.qf && (this.qf(), this.qf = null);
		{
			const t = this.Rp.bind(this), n = this.sp.bind(this);
			this.qf = () => {
				i.removeEventListener("mousemove", t), i.removeEventListener("mouseup", n);
			}, i.addEventListener("mousemove", t), i.addEventListener("mouseup", n);
		}
		if (this.Jf = !0, this.rp(t)) return;
		const n = this.hp(t);
		this.dp(n, this.up.Fp), this.Df || (this.Rf = 0, this.Df = setTimeout(this.pp.bind(this), 500), this.If = Sn(t));
	}
	mp() {
		this.vp.addEventListener("mouseenter", this.Mp.bind(this)), this.vp.addEventListener("touchcancel", this.wp.bind(this));
		{
			const t = this.vp.ownerDocument, i = (t) => {
				this.up.Wp && (t.composed && this.vp.contains(t.composedPath()[0]) || t.target && this.vp.contains(t.target) || this.up.Wp());
			};
			this.Uf = () => {
				t.removeEventListener("touchstart", i);
			}, this.Hf = () => {
				t.removeEventListener("mousedown", i);
			}, t.addEventListener("mousedown", i), t.addEventListener("touchstart", i, { passive: !0 });
		}
		pn() && (this.$f = () => {
			this.vp.removeEventListener("dblclick", this.ep);
		}, this.vp.addEventListener("dblclick", this.ep)), this.vp.addEventListener("mouseleave", this.Hp.bind(this)), this.vp.addEventListener("touchstart", this.Lp.bind(this), { passive: !0 }), wn(this.vp), this.vp.addEventListener("mousedown", this.Np.bind(this)), this.Up(), this.vp.addEventListener("touchmove", (() => {}), { passive: !1 });
	}
	Up() {
		void 0 === this.up.$p && void 0 === this.up.jp && void 0 === this.up.qp || (this.vp.addEventListener("touchstart", ((t) => this.Yp(t.touches)), { passive: !0 }), this.vp.addEventListener("touchmove", ((t) => {
			if (2 === t.touches.length && null !== this.Kf && void 0 !== this.up.jp) {
				const i = gn(t.touches[0], t.touches[1]) / this.Gf;
				this.up.jp(this.Kf, i), bn(t);
			}
		}), { passive: !1 }), this.vp.addEventListener("touchend", ((t) => {
			this.Yp(t.touches);
		})));
	}
	Yp(t) {
		1 === t.length && (this.Zf = !1), 2 !== t.length || this.Zf || this.Lf ? this.Kp() : this.Gp(t);
	}
	Gp(t) {
		const i = this.vp.getBoundingClientRect() || {
			left: 0,
			top: 0
		};
		this.Kf = {
			_t: (t[0].clientX - i.left + (t[1].clientX - i.left)) / 2,
			ut: (t[0].clientY - i.top + (t[1].clientY - i.top)) / 2
		}, this.Gf = gn(t[0], t[1]), void 0 !== this.up.$p && this.up.$p(), this.wp();
	}
	Kp() {
		null !== this.Kf && (this.Kf = null, void 0 !== this.up.qp && this.up.qp());
	}
	Hp(t) {
		if (this.jf && this.jf(), this.rp(t)) return;
		if (!this.ip) return;
		const i = this.hp(t);
		this.dp(i, this.up.Zp), this.ip = !pn();
	}
	zp(t) {
		const i = Cn(t.touches, u(this.tp));
		if (null === i) return;
		const n = this.hp(t, i);
		this.op(n, this.up.Xp), this.Wf = !0, this.Lf = !0;
	}
	rp(t) {
		return t.sourceCapabilities && void 0 !== t.sourceCapabilities.firesTouchEvents ? t.sourceCapabilities.firesTouchEvents : xn(t) < this.Qf + 500;
	}
	op(t, i) {
		i && i.call(this.up, t);
	}
	dp(t, i) {
		i && i.call(this.up, t);
	}
	hp(t, i) {
		const n = i || t, s = this.vp.getBoundingClientRect() || {
			left: 0,
			top: 0
		};
		return {
			clientX: n.clientX,
			clientY: n.clientY,
			pageX: n.pageX,
			pageY: n.pageY,
			screenX: n.screenX,
			screenY: n.screenY,
			localX: n.clientX - s.left,
			localY: n.clientY - s.top,
			ctrlKey: t.ctrlKey,
			altKey: t.altKey,
			shiftKey: t.shiftKey,
			metaKey: t.metaKey,
			Jp: !t.type.startsWith("mouse") && "contextmenu" !== t.type && "click" !== t.type,
			Qp: t.type,
			tv: n.target,
			xu: t.view,
			iv: () => {
				"touchstart" !== t.type && bn(t);
			}
		};
	}
};
function gn(t, i) {
	const n = t.clientX - i.clientX, s = t.clientY - i.clientY;
	return Math.sqrt(n * n + s * s);
}
function bn(t) {
	t.cancelable && t.preventDefault();
}
function Sn(t) {
	return {
		_t: t.pageX,
		ut: t.pageY
	};
}
function xn(t) {
	return t.timeStamp || performance.now();
}
function Cn(t, i) {
	for (let n = 0; n < t.length; ++n) if (t[n].identifier === i) return t[n];
	return null;
}
var yn = class {
	constructor(t, i, n) {
		this.nv = null, this.sv = null, this.ev = !0, this.rv = null, this.hv = t, this.av = t.lv()[i], this.ov = t.lv()[n], this._v = document.createElement("tr"), this._v.style.height = "1px", this.uv = document.createElement("td"), this.uv.style.position = "relative", this.uv.style.padding = "0", this.uv.style.margin = "0", this.uv.setAttribute("colspan", "3"), this.cv(), this._v.appendChild(this.uv), this.ev = this.hv.N().layout.panes.enableResize, this.ev ? this.dv() : (this.nv = null, this.sv = null);
	}
	m() {
		null !== this.sv && this.sv.m();
	}
	fv() {
		return this._v;
	}
	pv() {
		return size({
			width: this.av.pv().width,
			height: 1
		});
	}
	vv() {
		return size({
			width: this.av.vv().width,
			height: 1 * window.devicePixelRatio
		});
	}
	mv(t, i, n) {
		const s = this.vv();
		t.fillStyle = this.hv.N().layout.panes.separatorColor, t.fillRect(i, n, s.width, s.height);
	}
	Pt() {
		this.cv(), this.hv.N().layout.panes.enableResize !== this.ev && (this.ev = this.hv.N().layout.panes.enableResize, this.ev ? this.dv() : (null !== this.nv && (this.uv.removeChild(this.nv.wv), this.uv.removeChild(this.nv.Mv), this.nv = null), null !== this.sv && (this.sv.m(), this.sv = null)));
	}
	dv() {
		const t = document.createElement("div"), i = t.style;
		i.position = "fixed", i.display = "none", i.zIndex = "49", i.top = "0", i.left = "0", i.width = "100%", i.height = "100%", i.cursor = "row-resize", this.uv.appendChild(t);
		const n = document.createElement("div"), s = n.style;
		s.position = "absolute", s.zIndex = "50", s.top = "-4px", s.height = "9px", s.width = "100%", s.backgroundColor = "", s.cursor = "row-resize", this.uv.appendChild(n);
		const e = {
			bp: this.gv.bind(this),
			Zp: this.bv.bind(this),
			Fp: this.Sv.bind(this),
			Op: this.Sv.bind(this),
			Dp: this.xv.bind(this),
			Tp: this.xv.bind(this),
			Ep: this.Cv.bind(this),
			Vp: this.Cv.bind(this)
		};
		this.sv = new Mn(n, e, {
			Pp: () => !1,
			kp: () => !0
		}), this.nv = {
			Mv: n,
			wv: t
		};
	}
	cv() {
		this.uv.style.background = this.hv.N().layout.panes.separatorColor;
	}
	gv(t) {
		null !== this.nv && (this.nv.Mv.style.backgroundColor = this.hv.N().layout.panes.separatorHoverColor);
	}
	bv(t) {
		null !== this.nv && null === this.rv && (this.nv.Mv.style.backgroundColor = "");
	}
	Sv(t) {
		if (null === this.nv) return;
		const i = this.av.yv().F_() + this.ov.yv().F_(), n = i / (this.av.pv().height + this.ov.pv().height), s = 30 * n;
		i <= 2 * s || (this.rv = {
			Pv: t.pageY,
			kv: this.av.yv().F_(),
			Tv: i - s,
			Rv: i,
			Dv: n,
			Iv: s
		}, this.nv.wv.style.display = "block");
	}
	xv(t) {
		const i = this.rv;
		if (null === i) return;
		const n = (t.pageY - i.Pv) * i.Dv, s = ni(i.kv + n, i.Iv, i.Tv);
		this.av.yv().W_(s), this.ov.yv().W_(i.Rv - s), this.hv.Qt().ka();
	}
	Cv(t) {
		null !== this.rv && null !== this.nv && (this.rv = null, this.nv.wv.style.display = "none");
	}
};
function Pn(t, i) {
	return t.Vv - i.Vv;
}
function kn(t, i, n) {
	const s = (t.Vv - i.Vv) / (t.wt - i.wt);
	return Math.sign(s) * Math.min(Math.abs(s), n);
}
var Tn = class {
	constructor(t, i, n, s) {
		this.Bv = null, this.Ev = null, this.Av = null, this.Lv = null, this.zv = null, this.Ov = 0, this.Nv = 0, this.Fv = t, this.Wv = i, this.Hv = n, this.Ps = s;
	}
	Uv(t, i) {
		if (null !== this.Bv) {
			if (this.Bv.wt === i) return void (this.Bv.Vv = t);
			if (Math.abs(this.Bv.Vv - t) < this.Ps) return;
		}
		this.Lv = this.Av, this.Av = this.Ev, this.Ev = this.Bv, this.Bv = {
			wt: i,
			Vv: t
		};
	}
	me(t, i) {
		if (null === this.Bv || null === this.Ev) return;
		if (i - this.Bv.wt > 50) return;
		let n = 0;
		const s = kn(this.Bv, this.Ev, this.Wv), e = Pn(this.Bv, this.Ev), r = [s], h = [e];
		if (n += e, null !== this.Av) {
			const t = kn(this.Ev, this.Av, this.Wv);
			if (Math.sign(t) === Math.sign(s)) {
				const i = Pn(this.Ev, this.Av);
				if (r.push(t), h.push(i), n += i, null !== this.Lv) {
					const t = kn(this.Av, this.Lv, this.Wv);
					if (Math.sign(t) === Math.sign(s)) {
						const i = Pn(this.Av, this.Lv);
						r.push(t), h.push(i), n += i;
					}
				}
			}
		}
		let a = 0;
		for (let t = 0; t < r.length; ++t) a += h[t] / n * r[t];
		Math.abs(a) < this.Fv || (this.zv = {
			Vv: t,
			wt: i
		}, this.Nv = a, this.Ov = function(t, i) {
			const n = Math.log(i);
			return Math.log(1 * n / -t) / n;
		}(Math.abs(a), this.Hv));
	}
	Gc(t) {
		const i = u(this.zv), n = t - i.wt;
		return i.Vv + this.Nv * (Math.pow(this.Hv, n) - 1) / Math.log(this.Hv);
	}
	Kc(t) {
		return null === this.zv || this.$v(t) === this.Ov;
	}
	$v(t) {
		const i = t - u(this.zv).wt;
		return Math.min(i, this.Ov);
	}
};
var Rn = class {
	constructor(t, i) {
		this.jv = void 0, this.qv = void 0, this.Yv = void 0, this.vn = !1, this.Kv = t, this.Gv = i, this.Zv();
	}
	Pt() {
		this.Zv();
	}
	Xv() {
		this.jv && this.Kv.removeChild(this.jv), this.qv && this.Kv.removeChild(this.qv), this.jv = void 0, this.qv = void 0;
	}
	Jv() {
		return this.vn !== this.Qv() || this.Yv !== this.tm();
	}
	tm() {
		return this.Gv.Qt().Xi().J(this.Gv.N().layout.textColor) > 160 ? "dark" : "light";
	}
	Qv() {
		return this.Gv.N().layout.attributionLogo;
	}
	im() {
		const t = new URL(location.href);
		return t.hostname ? "&utm_source=" + t.hostname + t.pathname : "";
	}
	Zv() {
		this.Jv() && (this.Xv(), this.vn = this.Qv(), this.vn && (this.Yv = this.tm(), this.qv = document.createElement("style"), this.qv.innerText = "a#tv-attr-logo{--fill:#131722;--stroke:#fff;position:absolute;left:10px;bottom:10px;height:19px;width:35px;margin:0;padding:0;border:0;z-index:3;}a#tv-attr-logo[data-dark]{--fill:#D1D4DC;--stroke:#131722;}", this.jv = document.createElement("a"), this.jv.href = `https://www.tradingview.com/?utm_medium=lwc-link&utm_campaign=lwc-chart${this.im()}`, this.jv.title = "Charting by TradingView", this.jv.id = "tv-attr-logo", this.jv.target = "_blank", this.jv.innerHTML = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"35\" height=\"19\" fill=\"none\"><g fill-rule=\"evenodd\" clip-path=\"url(#a)\" clip-rule=\"evenodd\"><path fill=\"var(--stroke)\" d=\"M2 0H0v10h6v9h21.4l.5-1.3 6-15 1-2.7H23.7l-.5 1.3-.2.6a5 5 0 0 0-7-.9V0H2Zm20 17h4l5.2-13 .8-2h-7l-1 2.5-.2.5-1.5 3.8-.3.7V17Zm-.8-10a3 3 0 0 0 .7-2.7A3 3 0 1 0 16.8 7h4.4ZM14 7V2H2v6h6v9h4V7h2Z\"/><path fill=\"var(--fill)\" d=\"M14 2H2v6h6v9h6V2Zm12 15h-7l6-15h7l-6 15Zm-7-9a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z\"/></g><defs><clipPath id=\"a\"><path fill=\"var(--stroke)\" d=\"M0 0h35v19H0z\"/></clipPath></defs></svg>", this.jv.toggleAttribute("data-dark", "dark" === this.Yv), this.Kv.appendChild(this.qv), this.Kv.appendChild(this.jv)));
	}
};
function Dn(t, n) {
	const s = u(t.ownerDocument).createElement("canvas");
	t.appendChild(s);
	const e = bindTo(s, {
		type: "device-pixel-content-box",
		options: { allowResizeObserver: !0 },
		transform: (t, i) => ({
			width: Math.max(t.width, i.width),
			height: Math.max(t.height, i.height)
		})
	});
	return e.resizeCanvasElement(n), e;
}
function In(t) {
	t.width = 1, t.height = 1, t.getContext("2d")?.clearRect(0, 0, 1, 1);
}
function Vn(t, i, n, s) {
	t.qh && t.qh(i, n, s);
}
function Bn(t, i, n, s) {
	t.st(i, n, s);
}
function En(t, i, n, s) {
	An(t(n, s), i, s);
}
function An(t, i, n) {
	for (const s of t) {
		const t = s.Tt(n);
		null !== t && i(t);
	}
}
function Ln(t, i) {
	return (n) => {
		if (!function(t) {
			return void 0 !== t.Ft;
		}(n)) return [];
		return (n.Ft()?.pl() ?? "") !== i ? [] : n.Qa?.(t) ?? [];
	};
}
function zn(t, i, n, s) {
	if (!t.length) return;
	let e = 0;
	const r = t[0].$t(s, !0);
	let h = 1 === i ? n / 2 - (t[0].Hi() - r / 2) : t[0].Hi() - r / 2 - n / 2;
	h = Math.max(0, h);
	for (let r = 1; r < t.length; r++) {
		const a = t[r], l = t[r - 1], o = l.$t(s, !1), _ = a.Hi(), u = l.Hi();
		if (1 === i ? _ > u - o : _ < u + o) {
			const s = u - o * i;
			a.Ui(s);
			const r = s - i * o / 2;
			if ((1 === i ? r < 0 : r > n) && h > 0) {
				const s = 1 === i ? -1 - r : r - n, a = Math.min(s, h);
				for (let n = e; n < t.length; n++) t[n].Ui(t[n].Hi() + i * a);
				h -= a;
			}
		} else e = r, h = 1 === i ? u - o - _ : _ - (u + o);
	}
}
var On = class {
	constructor(i, n, s, e) {
		this.Ki = null, this.nm = null, this.sm = !1, this.rm = new rt(200), this.hm = null, this.am = 0, this.lm = !1, this.om = () => {
			this.lm || this.yt._m().Qt().mr();
		}, this.um = () => {
			this.lm || this.yt._m().Qt().mr();
		}, this.yt = i, this.yn = n, this.Ro = n.layout, this.bd = s, this.dm = "left" === e, this.fm = Ln("normal", e), this.pm = Ln("top", e), this.vm = Ln("bottom", e), this.uv = document.createElement("div"), this.uv.style.height = "100%", this.uv.style.overflow = "hidden", this.uv.style.width = "25px", this.uv.style.left = "0", this.uv.style.position = "relative", this.wm = Dn(this.uv, size({
			width: 16,
			height: 16
		})), this.wm.subscribeSuggestedBitmapSizeChanged(this.om);
		const r = this.wm.canvasElement;
		r.style.position = "absolute", r.style.zIndex = "1", r.style.left = "0", r.style.top = "0", this.Mm = Dn(this.uv, size({
			width: 16,
			height: 16
		})), this.Mm.subscribeSuggestedBitmapSizeChanged(this.um);
		const h = this.Mm.canvasElement;
		h.style.position = "absolute", h.style.zIndex = "2", h.style.left = "0", h.style.top = "0";
		const a = {
			Fp: this.Sv.bind(this),
			Op: this.Sv.bind(this),
			Dp: this.xv.bind(this),
			Tp: this.xv.bind(this),
			Wp: this.gm.bind(this),
			Ep: this.Cv.bind(this),
			Vp: this.Cv.bind(this),
			fp: this.bm.bind(this),
			_p: this.bm.bind(this),
			bp: this.Sm.bind(this),
			Zp: this.bv.bind(this)
		};
		this.sv = new Mn(this.Mm.canvasElement, a, {
			Pp: () => !this.yn.handleScroll.vertTouchDrag,
			kp: () => !0
		});
	}
	m() {
		this.sv.m(), this.Mm.unsubscribeSuggestedBitmapSizeChanged(this.um), In(this.Mm.canvasElement), this.Mm.dispose(), this.wm.unsubscribeSuggestedBitmapSizeChanged(this.om), In(this.wm.canvasElement), this.wm.dispose(), null !== this.Ki && this.Ki.__().u(this), this.Ki = null;
	}
	fv() {
		return this.uv;
	}
	P() {
		return this.Ro.fontSize;
	}
	xm() {
		const t = this.bd.N();
		return this.hm !== t.k && (this.rm.Os(), this.hm = t.k), t;
	}
	Cm() {
		if (null === this.Ki) return 0;
		let t = 0;
		const i = this.xm(), n = u(this.wm.canvasElement.getContext("2d", { colorSpace: this.yt._m().N().layout.colorSpace }));
		n.save();
		const s = this.Ki.zl();
		n.font = this.ym(), s.length > 0 && (t = Math.max(this.rm.Ii(n, s[0].eo), this.rm.Ii(n, s[s.length - 1].eo)));
		const e = this.Pm();
		for (let i = e.length; i--;) {
			const s = this.rm.Ii(n, e[i].ri());
			s > t && (t = s);
		}
		const r = this.Ki.Lt();
		if (null !== r && null !== this.nm && 2 !== (h = this.yn.crosshair).mode && h.horzLine.visible && h.horzLine.labelVisible) {
			const i = this.Ki.Tn(1, r), s = this.Ki.Tn(this.nm.height - 2, r);
			t = Math.max(t, this.rm.Ii(n, this.Ki.Ji(Math.floor(Math.min(i, s)) + .11111111111111, r)), this.rm.Ii(n, this.Ki.Ji(Math.ceil(Math.max(i, s)) - .11111111111111, r)));
		}
		var h;
		n.restore();
		const a = t || 34;
		return mn(Math.ceil(i.S + i.C + i.V + i.B + 5 + a));
	}
	km(t) {
		null !== this.nm && equalSizes(this.nm, t) || (this.nm = t, this.lm = !0, this.wm.resizeCanvasElement(t), this.Mm.resizeCanvasElement(t), this.lm = !1, this.uv.style.width = `${t.width}px`, this.uv.style.height = `${t.height}px`);
	}
	Tm() {
		return u(this.nm).width;
	}
	un(t) {
		this.Ki !== t && (null !== this.Ki && this.Ki.__().u(this), this.Ki = t, t.__().i(this.wo.bind(this), this));
	}
	Ft() {
		return this.Ki;
	}
	Os() {
		const t = this.yt.yv();
		this.yt._m().Qt().au(t, u(this.Ft()));
	}
	Rm(t) {
		if (null === this.nm) return;
		const i = { colorSpace: this.yt._m().N().layout.colorSpace };
		if (1 !== t) {
			this.Dm(), this.wm.applySuggestedBitmapSize();
			const t = tryCreateCanvasRenderingTarget2D(this.wm, i);
			null !== t && (t.useBitmapCoordinateSpace(((t) => {
				this.Im(t), this.Vm(t);
			})), this.yt.Bm(t, this.vm), this.Em(t), this.yt.Bm(t, this.fm), this.Am(t));
		}
		this.Mm.applySuggestedBitmapSize();
		const n = tryCreateCanvasRenderingTarget2D(this.Mm, i);
		null !== n && (n.useBitmapCoordinateSpace((({ context: t, bitmapSize: i }) => {
			t.clearRect(0, 0, i.width, i.height);
		})), this.Lm(n), this.yt.Bm(n, this.pm));
	}
	vv() {
		return this.wm.bitmapSize;
	}
	mv(t, i, n, s) {
		const e = this.vv();
		if (e.width > 0 && e.height > 0 && (t.drawImage(this.wm.canvasElement, i, n), s)) {
			const s = this.Mm.canvasElement;
			t.drawImage(s, i, n);
		}
	}
	Pt() {
		this.Ki?.zl();
	}
	Sv(t) {
		if (null === this.Ki || this.Ki.Zi() || !this.yn.handleScale.axisPressedMouseMove.price) return;
		const i = this.yt._m().Qt(), n = this.yt.yv();
		this.sm = !0, i.Q_(n, this.Ki, t.localY);
	}
	xv(t) {
		if (null === this.Ki || !this.yn.handleScale.axisPressedMouseMove.price) return;
		const i = this.yt._m().Qt(), n = this.yt.yv(), s = this.Ki;
		i.tu(n, s, t.localY);
	}
	gm() {
		if (null === this.Ki || !this.yn.handleScale.axisPressedMouseMove.price) return;
		const t = this.yt._m().Qt(), i = this.yt.yv(), n = this.Ki;
		this.sm && (this.sm = !1, t.iu(i, n));
	}
	Cv(t) {
		if (null === this.Ki || !this.yn.handleScale.axisPressedMouseMove.price) return;
		const i = this.yt._m().Qt(), n = this.yt.yv();
		this.sm = !1, i.iu(n, this.Ki);
	}
	bm(t) {
		this.yn.handleScale.axisDoubleClickReset.price && this.Os();
	}
	Sm(t) {
		if (null === this.Ki) return;
		!this.yt._m().Qt().N().handleScale.axisPressedMouseMove.price || this.Ki.je() || this.Ki.No() || this.zm(1);
	}
	bv(t) {
		this.zm(0);
	}
	Pm() {
		const t = [], i = null === this.Ki ? void 0 : this.Ki;
		return ((n) => {
			for (let s = 0; s < n.length; ++s) {
				const e = n[s].qn(this.yt.yv(), i);
				for (let i = 0; i < e.length; i++) t.push(e[i]);
			}
		})(this.yt.yv().Dt()), t;
	}
	Im({ context: t, bitmapSize: i }) {
		const { width: n, height: s } = i, e = this.yt.yv().Qt(), r = e.$(), h = e.af();
		r === h ? z(t, 0, 0, n, s, r) : F(t, 0, 0, n, s, r, h);
	}
	Vm({ context: t, bitmapSize: i, horizontalPixelRatio: n }) {
		if (null === this.nm || null === this.Ki || !this.Ki.N().borderVisible) return;
		t.fillStyle = this.Ki.N().borderColor;
		const s = Math.max(1, Math.floor(this.xm().S * n));
		let e;
		e = this.dm ? i.width - s : 0, t.fillRect(e, 0, s, i.height);
	}
	Em(t) {
		if (null === this.nm || null === this.Ki) return;
		const i = this.Ki.zl(), n = this.Ki.N(), s = this.xm(), e = this.dm ? this.nm.width - s.C : 0;
		n.borderVisible && n.ticksVisible && t.useBitmapCoordinateSpace((({ context: t, horizontalPixelRatio: r, verticalPixelRatio: h }) => {
			t.fillStyle = n.borderColor;
			const a = Math.max(1, Math.floor(h)), l = Math.floor(.5 * h), o = Math.round(s.C * r);
			t.beginPath();
			for (const n of i) t.rect(Math.floor(e * r), Math.round(n.Vl * h) - l, o, a);
			t.fill();
		})), t.useMediaCoordinateSpace((({ context: t }) => {
			t.font = this.ym(), t.fillStyle = n.textColor ?? this.Ro.textColor, t.textAlign = this.dm ? "right" : "left", t.textBaseline = "middle";
			const r = this.dm ? Math.round(e - s.V) : Math.round(e + s.C + s.V), h = i.map(((i) => this.rm.Di(t, i.eo)));
			for (let n = i.length; n--;) {
				const s = i[n];
				t.fillText(s.eo, r, s.Vl + h[n]);
			}
		}));
	}
	Dm() {
		if (null === this.nm || null === this.Ki) return;
		let t = this.nm.height / 2;
		const i = [], n = this.Ki.Dt().slice(), s = this.yt.yv(), e = this.xm();
		this.Ki === s.Zs() && this.yt.yv().Dt().forEach(((t) => {
			s.Gs(t) && n.push(t);
		}));
		const r = this.Ki.kl()[0], h = this.Ki;
		n.forEach(((n) => {
			const e = n.qn(s, h);
			e.forEach(((t) => {
				t.$i() && null === t.Wi() && (t.Ui(null), i.push(t));
			})), r === n && e.length > 0 && (t = e[0].Ei());
		}));
		this.Ki.N().alignLabels && this.Om(i, e, t);
	}
	Om(t, i, n) {
		if (null === this.nm) return;
		const s = t.filter(((t) => t.Ei() <= n)), e = t.filter(((t) => t.Ei() > n));
		s.sort(((t, i) => i.Ei() - t.Ei())), s.length && e.length && e.push(s[0]), e.sort(((t, i) => t.Ei() - i.Ei()));
		for (const n of t) {
			const t = Math.floor(n.$t(i) / 2), s = n.Ei();
			s > -t && s < t && n.Ui(t), s > this.nm.height - t && s < this.nm.height + t && n.Ui(this.nm.height - t);
		}
		zn(s, 1, this.nm.height, i), zn(e, -1, this.nm.height, i);
	}
	Am(t) {
		if (null === this.nm) return;
		const i = this.Pm(), n = this.xm(), s = this.dm ? "right" : "left";
		i.forEach(((i) => {
			if (i.ji()) i.Tt(u(this.Ki)).st(t, n, this.rm, s);
		}));
	}
	Lm(t) {
		if (null === this.nm || null === this.Ki) return;
		const i = this.yt._m().Qt(), n = [], s = this.yt.yv(), e = i.Vd().qn(s, this.Ki);
		e.length && n.push(e);
		const r = this.xm(), h = this.dm ? "right" : "left";
		n.forEach(((i) => {
			i.forEach(((i) => {
				i.Tt(u(this.Ki)).st(t, r, this.rm, h);
			}));
		}));
	}
	zm(t) {
		this.uv.style.cursor = 1 === t ? "ns-resize" : "default";
	}
	wo() {
		const t = this.Cm();
		this.am < t && this.yt._m().Qt().ka(), this.am = t;
	}
	ym() {
		return x(this.Ro.fontSize, this.Ro.fontFamily);
	}
};
function Nn(t, i) {
	return t.Xa?.(i) ?? [];
}
function Fn(t, i) {
	return t.jn?.(i) ?? [];
}
function Wn(t, i) {
	return t.cn?.(i) ?? [];
}
function Hn(t, i) {
	return t.qa?.(i) ?? [];
}
var Un = class Un {
	constructor(i, n) {
		this.nm = size({
			width: 0,
			height: 0
		}), this.Nm = null, this.Fm = null, this.Wm = null, this.Hm = null, this.Um = !1, this.$m = new d(), this.jm = new d(), this.qm = 0, this.Ym = !1, this.Km = null, this.Gm = !1, this.Zm = null, this.Xm = null, this.lm = !1, this.om = () => {
			this.lm || null === this.Jm || this.sn().mr();
		}, this.um = () => {
			this.lm || null === this.Jm || this.sn().mr();
		}, this.Gv = i, this.Jm = n, this.Jm.mu().i(this.Qm.bind(this), this, !0), this.tw = document.createElement("td"), this.tw.style.padding = "0", this.tw.style.position = "relative";
		const s = document.createElement("div");
		s.style.width = "100%", s.style.height = "100%", s.style.position = "relative", s.style.overflow = "hidden", this.iw = document.createElement("td"), this.iw.style.padding = "0", this.nw = document.createElement("td"), this.nw.style.padding = "0", this.tw.appendChild(s), this.wm = Dn(s, size({
			width: 16,
			height: 16
		})), this.wm.subscribeSuggestedBitmapSizeChanged(this.om);
		const e = this.wm.canvasElement;
		e.style.position = "absolute", e.style.zIndex = "1", e.style.left = "0", e.style.top = "0", this.Mm = Dn(s, size({
			width: 16,
			height: 16
		})), this.Mm.subscribeSuggestedBitmapSizeChanged(this.um);
		const r = this.Mm.canvasElement;
		r.style.position = "absolute", r.style.zIndex = "2", r.style.left = "0", r.style.top = "0", this._v = document.createElement("tr"), this._v.appendChild(this.iw), this._v.appendChild(this.tw), this._v.appendChild(this.nw), this.sw(), this.sv = new Mn(this.Mm.canvasElement, this, {
			Pp: () => null === this.Km && !this.Gv.N().handleScroll.vertTouchDrag,
			kp: () => null === this.Km && !this.Gv.N().handleScroll.horzTouchDrag
		});
	}
	m() {
		null !== this.Nm && this.Nm.m(), null !== this.Fm && this.Fm.m(), this.Wm = null, this.Mm.unsubscribeSuggestedBitmapSizeChanged(this.um), In(this.Mm.canvasElement), this.Mm.dispose(), this.wm.unsubscribeSuggestedBitmapSizeChanged(this.om), In(this.wm.canvasElement), this.wm.dispose(), null !== this.Jm && (this.Jm.mu().u(this), this.Jm.m()), this.sv.m();
	}
	yv() {
		return u(this.Jm);
	}
	ew(t) {
		null !== this.Jm && this.Jm.mu().u(this), this.Jm = t, null !== this.Jm && this.Jm.mu().i(Un.prototype.Qm.bind(this), this, !0), this.sw(), this.Gv.lv().indexOf(this) === this.Gv.lv().length - 1 ? (this.Wm = this.Wm ?? new Rn(this.tw, this.Gv), this.Wm.Pt()) : (this.Wm?.Xv(), this.Wm = null);
	}
	_m() {
		return this.Gv;
	}
	fv() {
		return this._v;
	}
	sw() {
		if (null !== this.Jm && (this.rw(), 0 !== this.sn().Jn().length)) {
			if (null !== this.Nm) {
				const t = this.Jm.X_();
				this.Nm.un(u(t));
			}
			if (null !== this.Fm) {
				const t = this.Jm.J_();
				this.Fm.un(u(t));
			}
		}
	}
	hw() {
		null !== this.Nm && this.Nm.Pt(), null !== this.Fm && this.Fm.Pt();
	}
	F_() {
		return null !== this.Jm ? this.Jm.F_() : 0;
	}
	W_(t) {
		this.Jm && this.Jm.W_(t);
	}
	bp(t) {
		if (!this.Jm) return;
		this.aw();
		const i = t.localX, n = t.localY;
		this.lw(i, n, t);
	}
	Fp(t) {
		this.aw(), this.ow(), this.lw(t.localX, t.localY, t);
	}
	Sp(t) {
		if (!this.Jm) return;
		this.aw();
		const i = t.localX, n = t.localY;
		this.lw(i, n, t);
	}
	Ap(t) {
		null !== this.Jm && (this.aw(), this.lw(t.localX, t.localY, t), this._w(t));
	}
	fp(t) {
		null !== this.Jm && this.uw(this.jm, t);
	}
	_p(t) {
		this.fp(t);
	}
	Dp(t) {
		this.aw(), this.cw(t), this.lw(t.localX, t.localY, t);
	}
	Ep(t) {
		null !== this.Jm && (this.aw(), this.Ym = !1, this.dw(t));
	}
	Bp(t) {
		null !== this.Jm && this._w(t);
	}
	Xp(t) {
		if (this.Ym = !0, null === this.Km) {
			const i = {
				x: t.localX,
				y: t.localY
			};
			this.fw(i, i, t);
		}
	}
	Zp(t) {
		null !== this.Jm && (this.aw(), this.Jm.Qt().Rd(null), this.pw());
	}
	mw() {
		return this.$m;
	}
	ww() {
		return this.jm;
	}
	$p() {
		this.qm = 1, this.sn().cs();
	}
	jp(t, i) {
		if (!this.Gv.N().handleScale.pinch) return;
		const n = 5 * (i - this.qm);
		this.qm = i, this.sn().Wd(t._t, n);
	}
	Op(t) {
		this.Ym = !1, this.Gm = null !== this.Km, this.ow();
		const i = this.sn().Vd();
		null !== this.Km && i.It() && (this.Zm = {
			x: i.ni(),
			y: i.si()
		}, this.Km = {
			x: t.localX,
			y: t.localY
		});
	}
	Tp(t) {
		if (null === this.Jm) return;
		const i = t.localX, n = t.localY;
		if (null === this.Km) this.cw(t);
		else {
			this.Gm = !1;
			const s = u(this.Zm), e = s.x + (i - this.Km.x), r = s.y + (n - this.Km.y);
			this.lw(e, r, t);
		}
	}
	Vp(t) {
		0 === this._m().N().trackingMode.exitMode && (this.Gm = !0), this.Mw(), this.dw(t);
	}
	Qs(t, i) {
		const n = this.Jm;
		return null === n ? null : Bi(n, t, i);
	}
	gw(i, n) {
		u("left" === n ? this.Nm : this.Fm).km(size({
			width: i,
			height: this.nm.height
		}));
	}
	pv() {
		return this.nm;
	}
	km(t) {
		equalSizes(this.nm, t) || (this.nm = t, this.lm = !0, this.wm.resizeCanvasElement(t), this.Mm.resizeCanvasElement(t), this.lm = !1, this.tw.style.width = t.width + "px", this.tw.style.height = t.height + "px");
	}
	bw() {
		const t = u(this.Jm);
		t.G_(t.X_()), t.G_(t.J_());
		for (const i of t.kl()) if (t.Gs(i)) {
			const n = i.Ft();
			null !== n && t.G_(n), i.Nn();
		}
		for (const i of t.Mu()) i.Nn();
	}
	vv() {
		return this.wm.bitmapSize;
	}
	mv(t, i, n, s) {
		const e = this.vv();
		if (e.width > 0 && e.height > 0 && (t.drawImage(this.wm.canvasElement, i, n), s)) {
			const s = this.Mm.canvasElement;
			null !== t && t.drawImage(s, i, n);
		}
	}
	Rm(t) {
		if (0 === t) return;
		if (null === this.Jm) return;
		t > 1 && this.bw(), null !== this.Nm && this.Nm.Rm(t), null !== this.Fm && this.Fm.Rm(t);
		const i = { colorSpace: this.Gv.N().layout.colorSpace };
		if (1 !== t) {
			this.wm.applySuggestedBitmapSize();
			const t = tryCreateCanvasRenderingTarget2D(this.wm, i);
			null !== t && (t.useBitmapCoordinateSpace(((t) => {
				this.Im(t);
			})), this.Jm && (this.Sw(t, Nn), this.xw(t), this.Sw(t, Fn), this.Sw(t, Wn)));
		}
		this.Mm.applySuggestedBitmapSize();
		const n = tryCreateCanvasRenderingTarget2D(this.Mm, i);
		null !== n && (n.useBitmapCoordinateSpace((({ context: t, bitmapSize: i }) => {
			t.clearRect(0, 0, i.width, i.height);
		})), this.Cw(n), this.Sw(n, Hn), this.Sw(n, Wn));
	}
	yw() {
		return this.Nm;
	}
	Pw() {
		return this.Fm;
	}
	Bm(t, i) {
		this.Sw(t, i);
	}
	Qm() {
		null !== this.Jm && this.Jm.mu().u(this), this.Jm = null;
	}
	_w(t) {
		this.uw(this.$m, t);
	}
	uw(t, i) {
		const n = i.localX, s = i.localY;
		t.v() && t.p(this.sn().Et().Vc(n), {
			x: n,
			y: s
		}, i);
	}
	Im({ context: t, bitmapSize: i }) {
		const { width: n, height: s } = i, e = this.sn(), r = e.$(), h = e.af();
		r === h ? z(t, 0, 0, n, s, h) : F(t, 0, 0, n, s, r, h);
	}
	xw(t) {
		const i = u(this.Jm), n = i.wu().wr().Tt(i);
		null !== n && n.st(t, !1);
	}
	Cw(t) {
		this.kw(t, Fn, Bn, this.sn().Vd());
	}
	Sw(t, i) {
		const n = u(this.Jm), s = i === Fn ? this.Tw() : null, e = null === s ? null : this.Rw(s, n), r = n.Mu();
		if (null === e || null === s) {
			const s = n._u();
			this.Dw(t, i, Vn, r, s), this.Dw(t, i, Bn, r, s);
			return;
		}
		const h = n.Dt(), a = (t) => t === s ? e.Za : void 0;
		this.Dw(t, i, Vn, r, h, a), this.Dw(t, i, Bn, r, h, a), this.kw(t, i, Vn, s, e.qa), this.kw(t, i, Bn, s, e.qa);
	}
	Dw(t, i, n, s, e, r) {
		for (const e of s) this.kw(t, i, n, e);
		if (void 0 !== r) for (const s of e) this.kw(t, i, n, s, r(s));
		else for (const s of e) this.kw(t, i, n, s);
	}
	Tw() {
		const t = u(this.Jm), i = t.Qt().cu()?.uu;
		if (!t.Qt().N().hoveredSeriesOnTop || void 0 === i) return null;
		for (const n of t.Dt()) if (n === i) return n;
		return null;
	}
	Rw(t, i) {
		const n = t.Ga?.(i) ?? null;
		return null === n || 0 === n.qa.length ? null : n;
	}
	kw(t, i, n, s, e) {
		const r = u(this.Jm), h = r.Qt().cu(), a = null !== h && h.uu === s, l = null !== h && a && void 0 !== h.bu ? h.bu.ie : void 0, o = (i) => n(i, t, a, l);
		void 0 === e ? En(i, o, s, r) : An(e, o, r);
	}
	rw() {
		if (null === this.Jm) return;
		const t = this.Gv, i = this.Jm.X_().N().visible, n = this.Jm.J_().N().visible;
		i || null === this.Nm || (this.iw.removeChild(this.Nm.fv()), this.Nm.m(), this.Nm = null), n || null === this.Fm || (this.nw.removeChild(this.Fm.fv()), this.Fm.m(), this.Fm = null);
		const s = t.Qt().Jd();
		i && null === this.Nm && (this.Nm = new On(this, t.N(), s, "left"), this.iw.appendChild(this.Nm.fv())), n && null === this.Fm && (this.Fm = new On(this, t.N(), s, "right"), this.nw.appendChild(this.Fm.fv()));
	}
	Iw(t) {
		return t.Jp && this.Ym || null !== this.Km;
	}
	lw(t, i, n) {
		t = Math.max(0, Math.min(t, this.nm.width - 1)), i = Math.max(0, Math.min(i, this.nm.height - 1)), this.sn().Kd(t, i, n, u(this.Jm));
	}
	pw() {
		this.sn().Zd();
	}
	Mw() {
		this.Gm && (this.Km = null, this.pw());
	}
	fw(t, i, n) {
		this.Km = t, this.Gm = !1, this.lw(i.x, i.y, n);
		const s = this.sn().Vd();
		this.Zm = {
			x: s.ni(),
			y: s.si()
		};
	}
	sn() {
		return this.Gv.Qt();
	}
	dw(t) {
		if (!this.Um) return;
		const i = this.sn(), n = this.yv();
		if (i.eu(n, n.kn()), this.Hm = null, this.Um = !1, i.jd(), null !== this.Xm) {
			const t = performance.now(), n = i.Et();
			this.Xm.me(n.Oc(), t), this.Xm.Kc(t) || i.ps(this.Xm);
		}
	}
	aw() {
		this.Km = null;
	}
	ow() {
		if (!this.Jm) return;
		if (this.sn().cs(), document.activeElement !== document.body && document.activeElement !== document.documentElement) u(document.activeElement).blur();
		else {
			const t = document.getSelection();
			null !== t && t.removeAllRanges();
		}
		!this.Jm.kn().Zi() && this.sn().Et().Zi();
	}
	cw(t) {
		if (null === this.Jm) return;
		const i = this.sn(), n = i.Et();
		if (n.Zi()) return;
		const s = this.Gv.N(), e = s.handleScroll, r = s.kineticScroll;
		if ((!e.pressedMouseMove || t.Jp) && (!e.horzTouchDrag && !e.vertTouchDrag || !t.Jp)) return;
		const h = this.Jm.kn(), a = performance.now();
		if (null !== this.Hm || this.Iw(t) || (this.Hm = {
			x: t.clientX,
			y: t.clientY,
			yf: a,
			Vw: t.localX,
			Bw: t.localY
		}), null !== this.Hm && !this.Um && (this.Hm.x !== t.clientX || this.Hm.y !== t.clientY)) {
			if (t.Jp && r.touch || !t.Jp && r.mouse) {
				const t = n.ml();
				this.Xm = new Tn(.2 / t, 7 / t, .997, 15 / t), this.Xm.Uv(n.Oc(), this.Hm.yf);
			} else this.Xm = null;
			h.Zi() || i.nu(this.Jm, h, t.localY), i.Ud(t.localX), this.Um = !0;
		}
		this.Um && (h.Zi() || i.su(this.Jm, h, t.localY), i.$d(t.localX), null !== this.Xm && this.Xm.Uv(n.Oc(), a));
	}
};
var $n = class {
	constructor(i, n, s, e, r) {
		this.xt = !0, this.nm = size({
			width: 0,
			height: 0
		}), this.om = () => this.Rm(3), this.dm = "left" === i, this.bd = s.Jd, this.yn = n, this.Ew = e, this.Aw = r, this.uv = document.createElement("div"), this.uv.style.width = "25px", this.uv.style.height = "100%", this.uv.style.overflow = "hidden", this.wm = Dn(this.uv, size({
			width: 16,
			height: 16
		})), this.wm.subscribeSuggestedBitmapSizeChanged(this.om);
	}
	m() {
		this.wm.unsubscribeSuggestedBitmapSizeChanged(this.om), In(this.wm.canvasElement), this.wm.dispose();
	}
	fv() {
		return this.uv;
	}
	pv() {
		return this.nm;
	}
	km(t) {
		equalSizes(this.nm, t) || (this.nm = t, this.wm.resizeCanvasElement(t), this.uv.style.width = `${t.width}px`, this.uv.style.height = `${t.height}px`, this.xt = !0);
	}
	Rm(t) {
		if (t < 3 && !this.xt) return;
		if (0 === this.nm.width || 0 === this.nm.height) return;
		this.xt = !1, this.wm.applySuggestedBitmapSize();
		const i = tryCreateCanvasRenderingTarget2D(this.wm, { colorSpace: this.yn.layout.colorSpace });
		null !== i && i.useBitmapCoordinateSpace(((t) => {
			this.Im(t), this.Vm(t);
		}));
	}
	vv() {
		return this.wm.bitmapSize;
	}
	mv(t, i, n) {
		const s = this.vv();
		s.width > 0 && s.height > 0 && t.drawImage(this.wm.canvasElement, i, n);
	}
	Vm({ context: t, bitmapSize: i, horizontalPixelRatio: n, verticalPixelRatio: s }) {
		if (!this.Ew()) return;
		t.fillStyle = this.yn.timeScale.borderColor;
		const e = Math.floor(this.bd.N().S * n), r = Math.floor(this.bd.N().S * s), h = this.dm ? i.width - e : 0;
		t.fillRect(h, 0, e, r);
	}
	Im({ context: t, bitmapSize: i }) {
		z(t, 0, 0, i.width, i.height, this.Aw());
	}
};
function jn(t) {
	return (i) => i.tl?.(t) ?? [];
}
var qn = jn("normal");
var Yn = jn("top");
var Kn = jn("bottom");
var Gn = class {
	constructor(i, n) {
		this.Lw = null, this.zw = null, this.M = null, this.Ow = !1, this.nm = size({
			width: 0,
			height: 0
		}), this.Nw = new d(), this.rm = new rt(5), this.lm = !1, this.om = () => {
			this.lm || this.Gv.Qt().mr();
		}, this.um = () => {
			this.lm || this.Gv.Qt().mr();
		}, this.Gv = i, this.Pu = n, this.yn = i.N().layout, this.jv = document.createElement("tr"), this.Fw = document.createElement("td"), this.Fw.style.padding = "0", this.Ww = document.createElement("td"), this.Ww.style.padding = "0", this.uv = document.createElement("td"), this.uv.style.height = "25px", this.uv.style.padding = "0", this.Hw = document.createElement("div"), this.Hw.style.width = "100%", this.Hw.style.height = "100%", this.Hw.style.position = "relative", this.Hw.style.overflow = "hidden", this.uv.appendChild(this.Hw), this.wm = Dn(this.Hw, size({
			width: 16,
			height: 16
		})), this.wm.subscribeSuggestedBitmapSizeChanged(this.om);
		const s = this.wm.canvasElement;
		s.style.position = "absolute", s.style.zIndex = "1", s.style.left = "0", s.style.top = "0", this.Mm = Dn(this.Hw, size({
			width: 16,
			height: 16
		})), this.Mm.subscribeSuggestedBitmapSizeChanged(this.um);
		const e = this.Mm.canvasElement;
		e.style.position = "absolute", e.style.zIndex = "2", e.style.left = "0", e.style.top = "0", this.jv.appendChild(this.Fw), this.jv.appendChild(this.uv), this.jv.appendChild(this.Ww), this.Uw(), this.Gv.Qt().N_().i(this.Uw.bind(this), this), this.sv = new Mn(this.Mm.canvasElement, this, {
			Pp: () => !0,
			kp: () => !this.Gv.N().handleScroll.horzTouchDrag
		});
	}
	m() {
		this.sv.m(), null !== this.Lw && this.Lw.m(), null !== this.zw && this.zw.m(), this.Mm.unsubscribeSuggestedBitmapSizeChanged(this.um), In(this.Mm.canvasElement), this.Mm.dispose(), this.wm.unsubscribeSuggestedBitmapSizeChanged(this.om), In(this.wm.canvasElement), this.wm.dispose();
	}
	fv() {
		return this.jv;
	}
	$w() {
		return this.Lw;
	}
	jw() {
		return this.zw;
	}
	Fp(t) {
		if (this.Ow) return;
		this.Ow = !0;
		const i = this.Gv.Qt();
		!i.Et().Zi() && this.Gv.N().handleScale.axisPressedMouseMove.time && i.Fd(t.localX);
	}
	Op(t) {
		this.Fp(t);
	}
	Wp() {
		const t = this.Gv.Qt();
		!t.Et().Zi() && this.Ow && (this.Ow = !1, this.Gv.N().handleScale.axisPressedMouseMove.time && t.Yd());
	}
	Dp(t) {
		const i = this.Gv.Qt();
		!i.Et().Zi() && this.Gv.N().handleScale.axisPressedMouseMove.time && i.qd(t.localX);
	}
	Tp(t) {
		this.Dp(t);
	}
	Ep() {
		this.Ow = !1;
		const t = this.Gv.Qt();
		t.Et().Zi() && !this.Gv.N().handleScale.axisPressedMouseMove.time || t.Yd();
	}
	Vp() {
		this.Ep();
	}
	fp() {
		this.Gv.N().handleScale.axisDoubleClickReset.time && this.Gv.Qt().ws();
	}
	_p() {
		this.fp();
	}
	bp() {
		this.Gv.Qt().N().handleScale.axisPressedMouseMove.time && this.zm(1);
	}
	Zp() {
		this.zm(0);
	}
	pv() {
		return this.nm;
	}
	qw() {
		return this.Nw;
	}
	Yw(i, s, e) {
		equalSizes(this.nm, i) || (this.nm = i, this.lm = !0, this.wm.resizeCanvasElement(i), this.Mm.resizeCanvasElement(i), this.lm = !1, this.uv.style.width = `${i.width}px`, this.uv.style.height = `${i.height}px`, this.Nw.p(i)), null !== this.Lw && this.Lw.km(size({
			width: s,
			height: i.height
		})), null !== this.zw && this.zw.km(size({
			width: e,
			height: i.height
		}));
	}
	Kw() {
		const t = this.Gw();
		return Math.ceil(t.S + t.C + t.P + t.A + t.I + t.Zw);
	}
	Pt() {
		this.Gv.Qt().Et().zl();
	}
	vv() {
		return this.wm.bitmapSize;
	}
	mv(t, i, n, s) {
		const e = this.vv();
		if (e.width > 0 && e.height > 0 && (t.drawImage(this.wm.canvasElement, i, n), s)) {
			const s = this.Mm.canvasElement;
			t.drawImage(s, i, n);
		}
	}
	Rm(t) {
		if (0 === t) return;
		const i = { colorSpace: this.yn.colorSpace };
		if (1 !== t) {
			this.wm.applySuggestedBitmapSize();
			const n = tryCreateCanvasRenderingTarget2D(this.wm, i);
			null !== n && (n.useBitmapCoordinateSpace(((t) => {
				this.Im(t), this.Vm(t), this.Xw(n, Kn);
			})), this.Em(n), this.Xw(n, qn)), null !== this.Lw && this.Lw.Rm(t), null !== this.zw && this.zw.Rm(t);
		}
		this.Mm.applySuggestedBitmapSize();
		const n = tryCreateCanvasRenderingTarget2D(this.Mm, i);
		null !== n && (n.useBitmapCoordinateSpace((({ context: t, bitmapSize: i }) => {
			t.clearRect(0, 0, i.width, i.height);
		})), this.Jw([...this.Gv.Qt().Jn(), this.Gv.Qt().Vd()], n), this.Xw(n, Yn));
	}
	Xw(t, i) {
		const n = this.Gv.Qt().Jn();
		for (const s of n) En(i, ((i) => Vn(i, t, !1, void 0)), s, void 0);
		for (const s of n) En(i, ((i) => Bn(i, t, !1, void 0)), s, void 0);
	}
	Im({ context: t, bitmapSize: i }) {
		z(t, 0, 0, i.width, i.height, this.Gv.Qt().af());
	}
	Vm({ context: t, bitmapSize: i, verticalPixelRatio: n }) {
		if (this.Gv.N().timeScale.borderVisible) {
			t.fillStyle = this.Qw();
			const s = Math.max(1, Math.floor(this.Gw().S * n));
			t.fillRect(0, 0, i.width, s);
		}
	}
	Em(t) {
		const i = this.Gv.Qt().Et(), n = i.zl();
		if (!n || 0 === n.length) return;
		const s = this.Pu.maxTickMarkWeight(n), e = this.Gw(), r = i.N();
		r.borderVisible && r.ticksVisible && t.useBitmapCoordinateSpace((({ context: t, horizontalPixelRatio: i, verticalPixelRatio: s }) => {
			t.strokeStyle = this.Qw(), t.fillStyle = this.Qw();
			const r = Math.max(1, Math.floor(i)), h = Math.floor(.5 * i);
			t.beginPath();
			const a = Math.round(e.C * s);
			for (let s = n.length; s--;) {
				const e = Math.round(n[s].coord * i);
				t.rect(e - h, 0, r, a);
			}
			t.fill();
		})), t.useMediaCoordinateSpace((({ context: t }) => {
			const i = e.S + e.C + e.A + e.P / 2;
			t.textAlign = "center", t.textBaseline = "middle", t.fillStyle = this.H(), t.font = this.ym();
			for (const e of n) if (e.weight < s) {
				const n = e.needAlignCoordinate ? this.tM(t, e.coord, e.label) : e.coord;
				t.fillText(e.label, n, i);
			}
			this.Gv.N().timeScale.allowBoldLabels && (t.font = this.iM());
			for (const e of n) if (e.weight >= s) {
				const n = e.needAlignCoordinate ? this.tM(t, e.coord, e.label) : e.coord;
				t.fillText(e.label, n, i);
			}
		}));
	}
	tM(t, i, n) {
		const s = this.rm.Ii(t, n), e = s / 2, r = Math.floor(i - e) + .5;
		return r < 0 ? i += Math.abs(0 - r) : r + s > this.nm.width && (i -= Math.abs(this.nm.width - (r + s))), i;
	}
	Jw(t, i) {
		const n = this.Gw();
		for (const s of t) for (const t of s.dn()) t.Tt().st(i, n);
	}
	Qw() {
		return this.Gv.N().timeScale.borderColor;
	}
	H() {
		return this.yn.textColor;
	}
	F() {
		return this.yn.fontSize;
	}
	ym() {
		return x(this.F(), this.yn.fontFamily);
	}
	iM() {
		return x(this.F(), this.yn.fontFamily, "bold");
	}
	Gw() {
		null === this.M && (this.M = {
			S: 1,
			L: NaN,
			A: NaN,
			I: NaN,
			tn: NaN,
			C: 5,
			P: NaN,
			k: "",
			Qi: new rt(),
			Zw: 0
		});
		const t = this.M, i = this.ym();
		if (t.k !== i) {
			const n = this.F();
			t.P = n, t.k = i, t.A = 3 * n / 12, t.I = 3 * n / 12, t.tn = 9 * n / 12, t.L = 0, t.Zw = 4 * n / 12, t.Qi.Os();
		}
		return this.M;
	}
	zm(t) {
		this.uv.style.cursor = 1 === t ? "ew-resize" : "default";
	}
	Uw() {
		const t = this.Gv.Qt(), i = t.N();
		i.leftPriceScale.visible || null === this.Lw || (this.Fw.removeChild(this.Lw.fv()), this.Lw.m(), this.Lw = null), i.rightPriceScale.visible || null === this.zw || (this.Ww.removeChild(this.zw.fv()), this.zw.m(), this.zw = null);
		const n = { Jd: this.Gv.Qt().Jd() }, s = () => i.leftPriceScale.borderVisible && t.Et().N().borderVisible, e = () => t.af();
		i.leftPriceScale.visible && null === this.Lw && (this.Lw = new $n("left", i, n, s, e), this.Fw.appendChild(this.Lw.fv())), i.rightPriceScale.visible && null === this.zw && (this.zw = new $n("right", i, n, s, e), this.Ww.appendChild(this.zw.fv()));
	}
};
var Zn = !!dn && !!navigator.userAgentData && navigator.userAgentData.brands.some(((t) => t.brand.includes("Chromium"))) && !!dn && (navigator?.userAgentData?.platform ? "Windows" === navigator.userAgentData.platform : navigator.userAgent.toLowerCase().indexOf("win") >= 0);
var Xn = class {
	constructor(t, i, n) {
		var s;
		this.nM = [], this.sM = [], this.eM = 0, this.oo = 0, this.k_ = 0, this.rM = 0, this.hM = 0, this.aM = null, this.lM = !1, this.$m = new d(), this.jm = new d(), this.wd = new d(), this.oM = null, this._M = null, this.Kv = t, this.yn = i, this.Pu = n, this.jv = document.createElement("div"), this.jv.classList.add("tv-lightweight-charts"), this.jv.style.overflow = "hidden", this.jv.style.direction = "ltr", this.jv.style.width = "100%", this.jv.style.height = "100%", (s = this.jv).style.userSelect = "none", s.style.webkitUserSelect = "none", s.style.msUserSelect = "none", s.style.MozUserSelect = "none", s.style.webkitTapHighlightColor = "transparent", this.uM = document.createElement("table"), this.uM.setAttribute("cellspacing", "0"), this.jv.appendChild(this.uM), this.cM = this.dM.bind(this), Jn(this.yn) && this.fM(!0), this.sn = new qi(this.gd.bind(this), this.yn, n), this.Qt().Bd().i(this.pM.bind(this), this), this.vM = new Gn(this, this.Pu), this.uM.appendChild(this.vM.fv());
		const e = i.autoSize && this.mM();
		let r = this.yn.width, h = this.yn.height;
		if (e || 0 === r || 0 === h) {
			const i = t.getBoundingClientRect();
			r = r || i.width, h = h || i.height;
		}
		this.wM(r, h), this.MM(), t.appendChild(this.jv), this.gM(), this.sn.Et().Jc().i(this.sn.ka.bind(this.sn), this), this.sn.N_().i(this.sn.ka.bind(this.sn), this);
	}
	Qt() {
		return this.sn;
	}
	N() {
		return this.yn;
	}
	lv() {
		return this.nM;
	}
	bM() {
		return this.vM;
	}
	m() {
		this.fM(!1), 0 !== this.eM && window.cancelAnimationFrame(this.eM), this.sn.Bd().u(this), this.sn.Et().Jc().u(this), this.sn.N_().u(this), this.sn.m();
		for (const t of this.nM) this.uM.removeChild(t.fv()), t.mw().u(this), t.ww().u(this), t.m();
		this.nM = [];
		for (const t of this.sM) this.SM(t);
		this.sM = [], u(this.vM).m(), null !== this.jv.parentElement && this.jv.parentElement.removeChild(this.jv), this.wd.m(), this.$m.m(), this.jm.m(), this.xM();
	}
	wM(i, n, s = !1) {
		if (this.oo === n && this.k_ === i) return;
		const e = function(i) {
			const n = Math.floor(i.width), s = Math.floor(i.height);
			return size({
				width: n - n % 2,
				height: s - s % 2
			});
		}(size({
			width: i,
			height: n
		}));
		this.oo = e.height, this.k_ = e.width;
		const r = this.oo + "px", h = this.k_ + "px";
		if (this.CM() || (u(this.jv).style.height = r, u(this.jv).style.width = h), this.uM.style.height = r, this.uM.style.width = h, s) {
			0 !== this.eM && (window.cancelAnimationFrame(this.eM), this.eM = 0), this.lM = !1;
			const t = X.ys();
			null !== this.aM && (t.Ss(this.aM), this.aM = null), this.yM(t, performance.now());
		} else this.sn.ka();
	}
	Rm(t) {
		void 0 === t && (t = X.ys());
		for (let i = 0; i < this.nM.length; i++) this.nM[i].Rm(t._s(i).rs);
		this.yn.timeScale.visible && this.vM.Rm(t.ls());
	}
	vr(t) {
		const i = Jn(this.yn);
		this.sn.vr(t);
		const n = Jn(this.yn);
		n !== i && this.fM(n), t.layout?.panes && this.PM(), this.gM(), this.kM(t);
	}
	mw() {
		return this.$m;
	}
	ww() {
		return this.jm;
	}
	Bd() {
		return this.wd;
	}
	TM(t = !1) {
		null !== this.aM && (this.yM(this.aM, performance.now()), this.aM = null);
		const i = this.RM(null), n = document.createElement("canvas");
		n.width = i.width, n.height = i.height;
		const s = u(n.getContext("2d"));
		return this.RM(s, t), n;
	}
	DM(t) {
		if ("left" === t && !this.IM()) return 0;
		if ("right" === t && !this.VM()) return 0;
		if (0 === this.nM.length) return 0;
		return u("left" === t ? this.nM[0].yw() : this.nM[0].Pw()).Tm();
	}
	CM() {
		return this.yn.autoSize && null !== this.oM;
	}
	Mv() {
		return this.jv;
	}
	BM(t) {
		this._M = t, this._M ? this.Mv().style.setProperty("cursor", t) : this.Mv().style.removeProperty("cursor");
	}
	EM() {
		return this._M;
	}
	AM(t) {
		return _(this.nM[t]).pv();
	}
	PM() {
		this.sM.forEach(((t) => {
			t.Pt();
		}));
	}
	kM(t) {
		(void 0 !== t.autoSize || !this.oM || void 0 === t.width && void 0 === t.height) && (t.autoSize && !this.oM && this.mM(), !1 === t.autoSize && null !== this.oM && this.xM(), t.autoSize || void 0 === t.width && void 0 === t.height || this.wM(t.width || this.k_, t.height || this.oo));
	}
	RM(i, n) {
		let s = 0, e = 0;
		const r = this.nM[0], h = (t, s) => {
			let e = 0;
			for (let r = 0; r < this.nM.length; r++) {
				const h = this.nM[r], a = u("left" === t ? h.yw() : h.Pw()), l = a.vv();
				if (null !== i && a.mv(i, s, e, n), e += l.height, r < this.nM.length - 1) {
					const t = this.sM[r], n = t.vv();
					null !== i && t.mv(i, s, e), e += n.height;
				}
			}
		};
		if (this.IM()) {
			h("left", 0);
			s += u(r.yw()).vv().width;
		}
		for (let t = 0; t < this.nM.length; t++) {
			const r = this.nM[t], h = r.vv();
			if (null !== i && r.mv(i, s, e, n), e += h.height, t < this.nM.length - 1) {
				const n = this.sM[t], r = n.vv();
				null !== i && n.mv(i, s, e), e += r.height;
			}
		}
		if (s += r.vv().width, this.VM()) {
			h("right", s);
			s += u(r.Pw()).vv().width;
		}
		const a = (t, n, s) => {
			u("left" === t ? this.vM.$w() : this.vM.jw()).mv(u(i), n, s);
		};
		if (this.yn.timeScale.visible) {
			const t = this.vM.vv();
			if (null !== i) {
				let s = 0;
				this.IM() && (a("left", s, e), s = u(r.yw()).vv().width), this.vM.mv(i, s, e, n), s += t.width, this.VM() && a("right", s, e);
			}
			e += t.height;
		}
		return size({
			width: s,
			height: e
		});
	}
	LM() {
		let i = 0, n = 0, s = 0;
		for (const t of this.nM) this.IM() && (n = Math.max(n, u(t.yw()).Cm(), this.yn.leftPriceScale.minimumWidth)), this.VM() && (s = Math.max(s, u(t.Pw()).Cm(), this.yn.rightPriceScale.minimumWidth)), i += t.F_();
		n = mn(n), s = mn(s);
		const e = this.k_, r = this.oo, h = Math.max(e - n - s, 0), a = 1 * this.sM.length, l = this.yn.timeScale.visible;
		let o = l ? Math.max(this.vM.Kw(), this.yn.timeScale.minimumHeight) : 0;
		var _;
		o = (_ = o) + _ % 2;
		const c = a + o, d = r < c ? 0 : r - c, f = d / i;
		let p = 0;
		const v = window.devicePixelRatio || 1;
		for (let i = 0; i < this.nM.length; ++i) {
			const e = this.nM[i];
			e.ew(this.sn.Gn()[i]);
			let r = 0, a = 0;
			a = i === this.nM.length - 1 ? Math.ceil((d - p) * v) / v : Math.round(e.F_() * f * v) / v, r = Math.max(a, 2), p += r, e.km(size({
				width: h,
				height: r
			})), this.IM() && e.gw(n, "left"), this.VM() && e.gw(s, "right"), e.yv() && this.sn.Ed(e.yv(), r);
		}
		this.vM.Yw(size({
			width: l ? h : 0,
			height: o
		}), l ? n : 0, l ? s : 0), this.sn.H_(h), this.rM !== n && (this.rM = n), this.hM !== s && (this.hM = s);
	}
	fM(t) {
		t ? this.jv.addEventListener("wheel", this.cM, { passive: !1 }) : this.jv.removeEventListener("wheel", this.cM);
	}
	zM(t) {
		switch (t.deltaMode) {
			case t.DOM_DELTA_PAGE: return 120;
			case t.DOM_DELTA_LINE: return 32;
		}
		return Zn ? 1 / window.devicePixelRatio : 1;
	}
	dM(t) {
		if (!(0 !== t.deltaX && this.yn.handleScroll.mouseWheel || 0 !== t.deltaY && this.yn.handleScale.mouseWheel)) return;
		const i = this.zM(t), n = i * t.deltaX / 100, s = -i * t.deltaY / 100;
		if (t.cancelable && t.preventDefault(), 0 !== s && this.yn.handleScale.mouseWheel) {
			const i = Math.sign(s) * Math.min(1, Math.abs(s)), n = t.clientX - this.jv.getBoundingClientRect().left;
			this.Qt().Wd(n, i);
		}
		0 !== n && this.yn.handleScroll.mouseWheel && this.Qt().Hd(-80 * n);
	}
	yM(t, i) {
		const n = t.ls();
		3 === n && this.OM(), 3 !== n && 2 !== n || (this.NM(t), this.FM(t, i), this.vM.Pt(), this.nM.forEach(((t) => {
			t.hw();
		})), 3 === this.aM?.ls() && (this.aM.Ss(t), this.OM(), this.NM(this.aM), this.FM(this.aM, i), t = this.aM, this.aM = null)), this.Rm(t);
	}
	FM(t, i) {
		for (const n of t.bs()) this.xs(n, i);
	}
	NM(t) {
		const i = this.sn.Gn();
		for (let n = 0; n < i.length; n++) t._s(n).hs && i[n].lu();
	}
	xs(t, i) {
		const n = this.sn.Et();
		switch (t.ds) {
			case 0:
				n.td();
				break;
			case 1:
				n.nd(t.Wt);
				break;
			case 2:
				n.Ms(t.Wt);
				break;
			case 3:
				n.gs(t.Wt);
				break;
			case 4:
				n.Wc();
				break;
			case 5: t.Wt.Kc(i) || n.gs(t.Wt.Gc(i));
		}
	}
	gd(t) {
		null !== this.aM ? this.aM.Ss(t) : this.aM = t, this.lM || (this.lM = !0, this.eM = window.requestAnimationFrame(((t) => {
			if (this.lM = !1, this.eM = 0, null !== this.aM) {
				const i = this.aM;
				this.aM = null, this.yM(i, t);
				for (const n of i.bs()) if (5 === n.ds && !n.Wt.Kc(t)) {
					this.Qt().ps(n.Wt);
					break;
				}
			}
		})));
	}
	OM() {
		this.MM();
	}
	SM(t) {
		this.uM.removeChild(t.fv()), t.m();
	}
	MM() {
		const t = this.sn.Gn(), i = t.length, n = this.nM.length;
		for (let t = i; t < n; t++) {
			const t = _(this.nM.pop());
			this.uM.removeChild(t.fv()), t.mw().u(this), t.ww().u(this), t.m();
			const i = this.sM.pop();
			void 0 !== i && this.SM(i);
		}
		for (let s = n; s < i; s++) {
			const i = new Un(this, t[s]);
			if (i.mw().i(this.WM.bind(this, i), this), i.ww().i(this.HM.bind(this, i), this), this.nM.push(i), s > 0) {
				const t = new yn(this, s - 1, s);
				this.sM.push(t), this.uM.insertBefore(t.fv(), this.vM.fv());
			}
			this.uM.insertBefore(i.fv(), this.vM.fv());
		}
		for (let n = 0; n < i; n++) {
			const i = t[n], s = this.nM[n];
			s.yv() !== i ? s.ew(i) : s.sw();
		}
		this.gM(), this.LM();
	}
	UM(t, i, n, s) {
		const e = /* @__PURE__ */ new Map();
		if (null !== t) this.sn.Jn().forEach(((i) => {
			const n = i.Un().Hn(t);
			null !== n && e.set(i, n);
		}));
		let r;
		if (null !== t) {
			const i = this.sn.Et().en(t)?.originalTime;
			void 0 !== i && (r = i);
		}
		const h = this.Qt().cu(), a = this.$M(s), l = function(t, i) {
			const n = null !== t && t.uu instanceof Jt ? t.uu : void 0, s = t?.bu?.te, e = void 0 !== i && -1 !== i ? i : void 0;
			return null === t || void 0 === t.ee ? {
				jM: n,
				qM: s
			} : {
				jM: n,
				qM: s,
				YM: {
					ds: t.ee,
					KM: (r = t.uu, h = t.ee, r instanceof Pi ? "pane-primitive" : "marker" === h || "primitive" === h ? "series-primitive" : "series"),
					GM: vn(t.ee, s),
					Y_: n,
					ZM: s,
					XM: e
				}
			};
			var r, h;
		}(h, a);
		return {
			Qr: r,
			$n: t ?? void 0,
			JM: i ?? void 0,
			XM: -1 !== a ? a : void 0,
			jM: l.jM,
			QM: e,
			qM: l.qM,
			YM: l.YM,
			tg: n ?? void 0
		};
	}
	$M(t) {
		let i = -1;
		if (t) i = this.nM.indexOf(t);
		else {
			const t = this.Qt().Vd().Kn();
			null !== t && (i = this.Qt().Gn().indexOf(t));
		}
		return i;
	}
	WM(t, i, n, s) {
		this.$m.p((() => this.UM(i, n, s, t)));
	}
	HM(t, i, n, s) {
		this.jm.p((() => this.UM(i, n, s, t)));
	}
	pM(t, i, n) {
		this.BM(this.Qt().cu()?.gu ?? null), this.wd.p((() => this.UM(t, i, n)));
	}
	gM() {
		const t = this.yn.timeScale.visible ? "" : "none";
		this.vM.fv().style.display = t;
	}
	IM() {
		return this.nM[0].yv().X_().N().visible;
	}
	VM() {
		return this.nM[0].yv().J_().N().visible;
	}
	mM() {
		return "ResizeObserver" in window && (this.oM = new ResizeObserver(((t) => {
			const i = t[t.length - 1];
			if (!i) return;
			const n = i.contentRect.width, s = i.contentRect.height;
			this.wM(n, s, !0);
		})), this.oM.observe(this.Kv, { box: "border-box" }), !0);
	}
	xM() {
		null !== this.oM && this.oM.disconnect(), this.oM = null;
	}
};
function Jn(t) {
	return Boolean(t.handleScroll.mouseWheel || t.handleScale.mouseWheel);
}
function Qn(t) {
	return void 0 === t.open && void 0 === t.value;
}
function ts(t) {
	return function(t) {
		return void 0 !== t.open;
	}(t) || function(t) {
		return void 0 !== t.value;
	}(t);
}
function is(t, i, n, s) {
	const e = n.value, r = {
		$n: i,
		wt: t,
		Wt: [
			e,
			e,
			e,
			e
		],
		Qr: s
	};
	return void 0 !== n.color && (r.R = n.color), r;
}
function ns(t, i, n, s) {
	const e = n.value, r = {
		$n: i,
		wt: t,
		Wt: [
			e,
			e,
			e,
			e
		],
		Qr: s
	};
	return void 0 !== n.lineColor && (r.vt = n.lineColor), void 0 !== n.topColor && (r.ah = n.topColor), void 0 !== n.bottomColor && (r.oh = n.bottomColor), r;
}
function ss(t, i, n, s) {
	const e = n.value, r = {
		$n: i,
		wt: t,
		Wt: [
			e,
			e,
			e,
			e
		],
		Qr: s
	};
	return void 0 !== n.topLineColor && (r._h = n.topLineColor), void 0 !== n.bottomLineColor && (r.uh = n.bottomLineColor), void 0 !== n.topFillColor1 && (r.dh = n.topFillColor1), void 0 !== n.topFillColor2 && (r.fh = n.topFillColor2), void 0 !== n.bottomFillColor1 && (r.ph = n.bottomFillColor1), void 0 !== n.bottomFillColor2 && (r.mh = n.bottomFillColor2), r;
}
function es(t, i, n, s) {
	const e = {
		$n: i,
		wt: t,
		Wt: [
			n.open,
			n.high,
			n.low,
			n.close
		],
		Qr: s
	};
	return void 0 !== n.color && (e.R = n.color), e;
}
function rs(t, i, n, s) {
	const e = {
		$n: i,
		wt: t,
		Wt: [
			n.open,
			n.high,
			n.low,
			n.close
		],
		Qr: s
	};
	return void 0 !== n.color && (e.R = n.color), void 0 !== n.borderColor && (e.Ht = n.borderColor), void 0 !== n.wickColor && (e.hh = n.wickColor), e;
}
function hs(t, i, n, s, e) {
	const r = _(e)(n), h = Math.max(...r), a = Math.min(...r), l = r[r.length - 1], o = [
		l,
		h,
		a,
		l
	], { time: u, color: c, ...d } = n;
	return {
		$n: i,
		wt: t,
		Wt: o,
		Qr: s,
		ue: d,
		R: c
	};
}
function as(t) {
	return void 0 !== t.Wt;
}
function ls(t, i) {
	return void 0 !== i.customValues && (t.ig = i.customValues), t;
}
function os(t) {
	return (i, n, s, e, r, h) => function(t, i) {
		return i ? i(t) : Qn(t);
	}(s, h) ? ls({
		wt: i,
		$n: n,
		Qr: e
	}, s) : ls(t(i, n, s, e, r), s);
}
function _s(t) {
	return {
		Candlestick: os(rs),
		Bar: os(es),
		Area: os(ns),
		Baseline: os(ss),
		Histogram: os(is),
		Line: os(is),
		Custom: os(hs)
	}[t];
}
function us(t) {
	return {
		$n: 0,
		ng: /* @__PURE__ */ new Map(),
		Oa: t
	};
}
function cs(t, i) {
	if (void 0 !== t && 0 !== t.length) return {
		sg: i.key(t[0].wt),
		eg: i.key(t[t.length - 1].wt)
	};
}
function ds(t) {
	let i;
	return t.forEach(((t) => {
		void 0 === i && (i = t.Qr);
	})), _(i);
}
var fs = class {
	constructor(t) {
		this.rg = /* @__PURE__ */ new Map(), this.hg = /* @__PURE__ */ new Map(), this.ag = /* @__PURE__ */ new Map(), this.lg = [], this.Pu = t;
	}
	m() {
		this.rg.clear(), this.hg.clear(), this.ag.clear(), this.lg = [];
	}
	og(t, i) {
		let n = 0 !== this.rg.size, s = !1;
		const e = this.hg.get(t);
		if (void 0 !== e) if (1 === this.hg.size) n = !1, s = !0, this.rg.clear();
		else for (const i of this.lg) i.pointData.ng.delete(t) && (s = !0);
		let r = [];
		if (0 !== i.length) {
			const n = i.map(((t) => t.time)), e = this.Pu.createConverterToInternalObj(i), h = _s(t.bh()), a = t.ul(), l = t.cl();
			r = i.map(((i, r) => {
				const o = e(i.time), _ = this.Pu.key(o);
				let u = this.rg.get(_);
				void 0 === u && (u = us(o), this.rg.set(_, u), s = !0);
				const c = h(o, u.$n, i, n[r], a, l);
				return u.ng.set(t, c), c;
			}));
		}
		n && this._g(), this.ug(t, r);
		let h = -1;
		if (s) {
			const t = [];
			this.rg.forEach(((i) => {
				t.push({
					timeWeight: 0,
					time: i.Oa,
					pointData: i,
					originalTime: ds(i.ng)
				});
			})), t.sort(((t, i) => this.Pu.key(t.time) - this.Pu.key(i.time))), h = this.cg(t);
		}
		return this.dg(t, h, function(t, i, n) {
			const s = cs(t, n), e = cs(i, n);
			if (void 0 !== s && void 0 !== e) return {
				fg: !1,
				Va: s.eg >= e.eg && s.sg >= e.sg
			};
		}(this.hg.get(t), e, this.Pu));
	}
	if(t) {
		return this.og(t, []);
	}
	pg(t, i, n) {
		if (n && t.Fa()) throw new Error("Historical updates are not supported when conflation is enabled. Conflation requires data to be processed in order.");
		const s = i;
		(function(t) {
			void 0 === t.Qr && (t.Qr = t.time);
		})(s), this.Pu.preprocessData(i);
		const e = this.Pu.createConverterToInternalObj([i])(i.time), r = this.ag.get(t);
		if (!n && void 0 !== r && this.Pu.key(e) < this.Pu.key(r)) throw new Error(`Cannot update oldest data, last time=${r}, new time=${e}`);
		let h = this.rg.get(this.Pu.key(e));
		if (n && void 0 === h) throw new Error("Cannot update non-existing data point when historicalUpdate is true");
		const a = void 0 === h;
		void 0 === h && (h = us(e), this.rg.set(this.Pu.key(e), h));
		const l = _s(t.bh()), o = t.ul(), _ = t.cl(), u = l(e, h.$n, i, s.Qr, o, _), c = !n && !a && void 0 !== r && this.Pu.key(e) === this.Pu.key(r);
		h.ng.set(t, u), n ? this.vg(t, u, h.$n) : c && t.Fa() && as(u) ? (t.Rr(u), this.mg(t, u)) : this.mg(t, u);
		const d = {
			Va: as(u),
			fg: n
		};
		if (!a) return this.dg(t, -1, d);
		const f = {
			timeWeight: 0,
			time: h.Oa,
			pointData: h,
			originalTime: ds(h.ng)
		}, p = Rt(this.lg, this.Pu.key(f.time), ((t, i) => this.Pu.key(t.time) < i));
		this.lg.splice(p, 0, f);
		for (let t = p; t < this.lg.length; ++t) ps(this.lg[t].pointData, t);
		return this.Pu.fillWeightsForPoints(this.lg, p), this.dg(t, p, d);
	}
	wg(t, i) {
		const n = this.hg.get(t);
		if (void 0 === n || i <= 0) return [[], this.Mg()];
		i = Math.min(i, n.length);
		const s = n.splice(-i).reverse();
		0 === n.length ? this.ag.delete(t) : this.ag.set(t, n[n.length - 1].wt);
		for (const i of s) {
			const n = this.rg.get(this.Pu.key(i.wt));
			if (n && (n.ng.delete(t), 0 === n.ng.size)) {
				this.rg.delete(this.Pu.key(n.Oa)), this.lg.splice(n.$n, 1);
				for (let t = n.$n; t < this.lg.length; ++t) ps(this.lg[t].pointData, t);
			}
		}
		return [s, this.dg(t, this.lg.length - 1, {
			fg: !1,
			Va: !1
		})];
	}
	mg(t, i) {
		let n = this.hg.get(t);
		void 0 === n && (n = [], this.hg.set(t, n));
		const s = 0 !== n.length ? n[n.length - 1] : null;
		null === s || this.Pu.key(i.wt) > this.Pu.key(s.wt) ? as(i) && n.push(i) : as(i) ? n[n.length - 1] = i : n.splice(-1, 1), this.ag.set(t, i.wt);
	}
	vg(t, i, n) {
		const s = this.hg.get(t);
		if (void 0 === s) return;
		const e = Rt(s, n, ((t, i) => t.$n < i));
		as(i) ? s[e] = i : s.splice(e, 1);
	}
	ug(t, i) {
		0 !== i.length ? (this.hg.set(t, i.filter(as)), this.ag.set(t, i[i.length - 1].wt)) : (this.hg.delete(t), this.ag.delete(t));
	}
	_g() {
		for (const t of this.lg) 0 === t.pointData.ng.size && this.rg.delete(this.Pu.key(t.time));
	}
	cg(t) {
		let i = -1;
		for (let n = 0; n < this.lg.length && n < t.length; ++n) {
			const s = this.lg[n], e = t[n];
			if (this.Pu.key(s.time) !== this.Pu.key(e.time)) {
				i = n;
				break;
			}
			e.timeWeight = s.timeWeight, ps(e.pointData, n);
		}
		if (-1 === i && this.lg.length !== t.length && (i = Math.min(this.lg.length, t.length)), -1 === i) return -1;
		for (let n = i; n < t.length; ++n) ps(t[n].pointData, n);
		return this.Pu.fillWeightsForPoints(t, i), this.lg = t, i;
	}
	gg() {
		if (0 === this.hg.size) return null;
		let t = 0;
		return this.hg.forEach(((i) => {
			0 !== i.length && (t = Math.max(t, i[i.length - 1].$n));
		})), t;
	}
	dg(t, i, n) {
		const s = this.Mg();
		if (-1 !== i) this.hg.forEach(((i, e) => {
			s.Y_.set(e, {
				ue: i,
				bg: e === t ? n : void 0
			});
		})), this.hg.has(t) || s.Y_.set(t, {
			ue: [],
			bg: n
		}), s.Et.Sg = this.lg, s.Et.xg = i;
		else {
			const i = this.hg.get(t);
			s.Y_.set(t, {
				ue: i || [],
				bg: n
			});
		}
		return s;
	}
	Mg() {
		return {
			Y_: /* @__PURE__ */ new Map(),
			Et: { Dc: this.gg() }
		};
	}
};
function ps(t, i) {
	t.$n = i, t.ng.forEach(((t) => {
		t.$n = i;
	}));
}
function vs(t, i) {
	return t._t < i;
}
function ms(t, i) {
	return i < t._t;
}
function ws(t, i, n, s) {
	return Rt(t, i, vs, n, s);
}
function Ms(t, i, n, s) {
	return Dt(t, i, ms, n, s);
}
function gs(t, i, n) {
	return {
		ne: t,
		se: i,
		ee: n
	};
}
function bs(t, i, n, s) {
	return t >= i - s && t <= n + s;
}
function Ss(t, i, n, s, e, r) {
	const h = e - n, a = r - s;
	if (0 === h && 0 === a) return Math.hypot(t - n, i - s);
	const l = ((t - n) * h + (i - s) * a) / (h * h + a * a), o = Math.max(0, Math.min(1, l)), _ = n + h * o, u = s + a * o;
	return Math.hypot(t - _, i - u);
}
var xs = [0, 0];
function Cs(t, i, n) {
	return void 0 === i || i.wt !== t.wt - 1 ? t._t - n / 2 : (i._t + t._t) / 2;
}
function ys(t, i, n) {
	return void 0 === i || i.wt !== t.wt + 1 ? t._t + n / 2 : (t._t + i._t) / 2;
}
function Ps(t, i, n, s, e, r, h) {
	if (null === i || i.from >= i.to || 0 === t.length) return null;
	const a = e / 2 + r, l = ws(t, n - a, i.from, i.to), o = Ms(t, n + a, l, i.to);
	if (l >= o) return null;
	let _ = Number.POSITIVE_INFINITY;
	for (let a = l; a < o; a++) {
		const l = t[a], o = a > i.from ? t[a - 1] : void 0, u = a < i.to - 1 ? t[a + 1] : void 0, c = Cs(l, o, e) - r, d = ys(l, u, e) + r;
		if (n < c || n > d) continue;
		h(l, xs);
		const f = xs[0], p = xs[1], v = Math.min(f, p), m = Math.max(f, p), w = v - r, M = m + r;
		if (s >= v && s <= m) _ = Math.min(_, 0);
		else if (s >= w && s <= M) {
			const t = Math.min(Math.abs(s - v), Math.abs(m - s));
			_ = Math.min(_, t);
		}
	}
	return Number.isFinite(_) ? gs(_, 0, "series-range") : null;
}
function ks(t, i) {
	return t.wt < i;
}
function Ts(t, i) {
	return i < t.wt;
}
function Rs(t, i, n) {
	const s = i.Na(), e = i.bi(), r = Rt(t, s, ks), h = Dt(t, e, Ts);
	if (!n) return {
		from: r,
		to: h
	};
	let a = r, l = h;
	return r > 0 && r < t.length && t[r].wt >= s && (a = r - 1), h > 0 && h < t.length && t[h - 1].wt <= e && (l = h + 1), {
		from: a,
		to: l
	};
}
var Ds = class {
	constructor(t, i, n) {
		this.Cg = !0, this.yg = !0, this.Pg = !0, this.kg = [], this.Tg = null, this.Rg = -1, this.ae = t, this.le = i, this.Dg = n;
	}
	Pt(t) {
		this.Cg = !0, "data" === t && (this.yg = !0), "options" === t && (this.Pg = !0);
	}
	Tt() {
		return this.ae.It() ? (this.Ig(), null === this.Tg ? null : this.Vg) : null;
	}
	Qs(t, i) {
		return this.ae.It() ? (this.Ig(), null === this.Tg ? null : this.Bg(t, i)) : null;
	}
	Bg(t, i) {
		return null;
	}
	Eg() {
		this.kg = this.kg.map(((t) => ({
			...t,
			...this.ae.Sa().Sh(t.wt)
		})));
	}
	Ag() {
		this.Tg = null;
	}
	Ig() {
		const t = this.le.Et(), i = t.N().enableConflation ? t.sd() : 0;
		i !== this.Rg && (this.yg = !0, this.Rg = i), this.yg && (this.Lg(), this.yg = !1), this.Pg && (this.Eg(), this.Pg = !1), this.Cg && (this.zg(), this.Cg = !1);
	}
	zg() {
		const t = this.ae.Ft(), i = this.le.Et();
		if (this.Ag(), i.Zi() || t.Zi()) return;
		const n = i.Ee();
		if (null === n) return;
		if (0 === this.ae.Un().Th()) return;
		const s = this.ae.Lt();
		null !== s && (this.Tg = Rs(this.kg, n, this.Dg), this.Og(t, i, s.Wt), this.Ng());
	}
};
var Is = class {
	constructor(t, i) {
		this.Fg = t, this.Ki = i;
	}
	st(t, i, n) {
		this.Fg.draw(t, this.Ki, i, n);
	}
};
function Vs(t) {
	switch (t) {
		case "point": return 2;
		case "range": return 0;
		default: return 1;
	}
}
var Bs = class extends Ds {
	constructor(t, i, n) {
		super(t, i, !1), this.Yh = n, this.Fg = this.Yh.renderer(), this.Vg = new Is(this.Fg, ((t) => this.Wg(t)));
	}
	get ga() {
		return this.Yh.conflationReducer;
	}
	Ha(t) {
		return this.Yh.priceValueBuilder(t);
	}
	dl(t) {
		return this.Yh.isWhitespace(t);
	}
	Bg(t, i) {
		const n = this.Fg.hitTest?.(t, i, ((t) => this.Wg(t)));
		if (null != n) return {
			ne: (s = n).distance,
			se: Vs(s.type),
			ee: "custom",
			gu: s.cursorStyle,
			te: s.objectId,
			ie: s.hitTestData
		};
		var s;
		const e = Ps(this.kg, this.Tg, t, i, this.le.Et().ml(), this.ae.N().hitTestTolerance, ((t, i) => {
			const n = t.Hg;
			let s = NaN, e = NaN;
			if (void 0 !== n && !this.Yh.isWhitespace(n)) for (const t of this.Yh.priceValueBuilder(n)) {
				const i = this.Wg(t);
				null !== i && (s = Number.isNaN(s) ? i : Math.min(s, i), e = Number.isNaN(e) ? i : Math.max(e, i));
			}
			i[0] = s, i[1] = e;
		}));
		return null === e ? null : {
			...e,
			ee: "custom"
		};
	}
	Lg() {
		const t = this.ae.Sa();
		this.kg = this.ae.Ua().Bh().map(((i) => ({
			wt: i.$n,
			_t: NaN,
			...t.Sh(i.$n),
			Hg: i.ue
		})));
	}
	Og(t, i) {
		i.Ic(this.kg, b(this.Tg));
	}
	Ng() {
		this.Yh.update({
			bars: this.kg.map(Es),
			barSpacing: this.le.Et().ml(),
			visibleRange: this.Tg,
			conflationFactor: this.le.Et().sd()
		}, this.ae.N());
	}
	Wg(t) {
		const i = this.ae.Lt();
		return null === i ? null : this.ae.Ft().Nt(t, i.Wt);
	}
};
function Es(t) {
	return {
		x: t._t,
		time: t.wt,
		originalData: t.Hg,
		barColor: t.sh
	};
}
var As = { color: "#2196f3" };
var Ls = (t, i, n) => {
	return new Bs(t, i, c(n));
};
function zs(t) {
	const i = {
		value: t.Wt[3],
		time: t.Qr
	};
	return void 0 !== t.ig && (i.customValues = t.ig), i;
}
function Os(t) {
	const i = zs(t);
	return void 0 !== t.R && (i.color = t.R), i;
}
function Ns(t) {
	const i = zs(t);
	return void 0 !== t.vt && (i.lineColor = t.vt), void 0 !== t.ah && (i.topColor = t.ah), void 0 !== t.oh && (i.bottomColor = t.oh), i;
}
function Fs(t) {
	const i = zs(t);
	return void 0 !== t._h && (i.topLineColor = t._h), void 0 !== t.uh && (i.bottomLineColor = t.uh), void 0 !== t.dh && (i.topFillColor1 = t.dh), void 0 !== t.fh && (i.topFillColor2 = t.fh), void 0 !== t.ph && (i.bottomFillColor1 = t.ph), void 0 !== t.mh && (i.bottomFillColor2 = t.mh), i;
}
function Ws(t) {
	const i = {
		open: t.Wt[0],
		high: t.Wt[1],
		low: t.Wt[2],
		close: t.Wt[3],
		time: t.Qr
	};
	return void 0 !== t.ig && (i.customValues = t.ig), i;
}
function Hs(t) {
	const i = Ws(t);
	return void 0 !== t.R && (i.color = t.R), i;
}
function Us(t) {
	const i = Ws(t), { R: n, Ht: s, hh: e } = t;
	return void 0 !== n && (i.color = n), void 0 !== s && (i.borderColor = s), void 0 !== e && (i.wickColor = e), i;
}
function $s(t) {
	return {
		Area: Ns,
		Line: Os,
		Baseline: Fs,
		Histogram: Os,
		Bar: Hs,
		Candlestick: Us,
		Custom: js
	}[t];
}
function js(t) {
	const i = t.Qr;
	return {
		...t.ue,
		time: i
	};
}
var qs = {
	vertLine: {
		color: "#9598A1",
		width: 1,
		style: 3,
		visible: !0,
		labelVisible: !0,
		labelBackgroundColor: "#131722"
	},
	horzLine: {
		color: "#9598A1",
		width: 1,
		style: 3,
		visible: !0,
		labelVisible: !0,
		labelBackgroundColor: "#131722"
	},
	mode: 1,
	doNotSnapToHiddenSeriesIndices: !1
};
var Ys = {
	vertLines: {
		color: "#D6DCDE",
		style: 0,
		visible: !0
	},
	horzLines: {
		color: "#D6DCDE",
		style: 0,
		visible: !0
	}
};
var Ks = {
	background: {
		type: "solid",
		color: "#FFFFFF"
	},
	textColor: "#191919",
	fontSize: 12,
	fontFamily: S,
	panes: {
		enableResize: !0,
		separatorColor: "#E0E3EB",
		separatorHoverColor: "rgba(178, 181, 189, 0.2)"
	},
	attributionLogo: !0,
	colorSpace: "srgb",
	colorParsers: []
};
var Gs = {
	autoScale: !0,
	mode: 0,
	invertScale: !1,
	alignLabels: !0,
	borderVisible: !0,
	borderColor: "#2B2B43",
	entireTextOnly: !1,
	visible: !1,
	ticksVisible: !1,
	scaleMargins: {
		bottom: .1,
		top: .2
	},
	minimumWidth: 0,
	ensureEdgeTickMarksVisible: !1,
	tickMarkDensity: 2.5
};
var Zs = {
	rightOffset: 0,
	barSpacing: 6,
	minBarSpacing: .5,
	maxBarSpacing: 0,
	fixLeftEdge: !1,
	fixRightEdge: !1,
	lockVisibleTimeRangeOnResize: !1,
	rightBarStaysOnScroll: !1,
	borderVisible: !0,
	borderColor: "#2B2B43",
	visible: !0,
	timeVisible: !1,
	secondsVisible: !0,
	shiftVisibleRangeOnNewBar: !0,
	allowShiftVisibleRangeOnWhitespaceReplacement: !1,
	ticksVisible: !1,
	uniformDistribution: !1,
	minimumHeight: 0,
	allowBoldLabels: !0,
	ignoreWhitespaceIndices: !1,
	enableConflation: !1,
	conflationThresholdFactor: 1,
	precomputeConflationOnInit: !1,
	precomputeConflationPriority: "background"
};
function Xs() {
	return {
		addDefaultPane: !0,
		hoveredSeriesOnTop: !0,
		width: 0,
		height: 0,
		autoSize: !1,
		layout: Ks,
		crosshair: qs,
		grid: Ys,
		overlayPriceScales: { ...Gs },
		leftPriceScale: {
			...Gs,
			visible: !1
		},
		rightPriceScale: {
			...Gs,
			visible: !0
		},
		defaultVisiblePriceScaleId: "right",
		timeScale: Zs,
		localization: {
			locale: dn ? navigator.language : "",
			dateFormat: "dd MMM 'yy"
		},
		handleScroll: {
			mouseWheel: !0,
			pressedMouseMove: !0,
			horzTouchDrag: !0,
			vertTouchDrag: !0
		},
		handleScale: {
			axisPressedMouseMove: {
				time: !0,
				price: !0
			},
			axisDoubleClickReset: {
				time: !0,
				price: !0
			},
			mouseWheel: !0,
			pinch: !0
		},
		kineticScroll: {
			mouse: !1,
			touch: !0
		},
		trackingMode: { exitMode: 1 }
	};
}
var Js = class {
	constructor(t, i, n) {
		this.hv = t, this.Ug = i, this.$g = n ?? 0;
	}
	applyOptions(t) {
		this.hv.Qt().Dd(this.Ug, t, this.$g);
	}
	options() {
		return this.Ki().N();
	}
	width() {
		return Z(this.Ug) ? this.hv.DM(this.Ug) : 0;
	}
	setVisibleRange(t) {
		this.setAutoScale(!1), this.Ki().Go(new mt(t.from, t.to));
	}
	getVisibleRange() {
		let t, i, n = this.Ki().ar();
		if (null === n) return null;
		if (this.Ki().ho()) {
			const s = this.Ki().S_(), e = Yi(s);
			n = vi(n, this.Ki().lo()), t = Number((Math.round(n.Je() / s) * s).toFixed(e)), i = Number((Math.round(n.Qe() / s) * s).toFixed(e));
		} else t = n.Je(), i = n.Qe();
		return {
			from: t,
			to: i
		};
	}
	setAutoScale(t) {
		this.applyOptions({ autoScale: t });
	}
	Ki() {
		return u(this.hv.Qt().Id(this.Ug, this.$g)).Ft;
	}
};
var Qs = class {
	constructor(t, i, n, s) {
		this.hv = t, this.yt = n, this.jg = i, this.qg = s;
	}
	getHeight() {
		return this.yt.$t();
	}
	setHeight(t) {
		const i = this.hv.Qt(), n = i._f(this.yt);
		i.Ld(n, t);
	}
	getStretchFactor() {
		return this.yt.F_();
	}
	setStretchFactor(t) {
		this.yt.W_(t), this.hv.Qt().ka();
	}
	paneIndex() {
		return this.hv.Qt()._f(this.yt);
	}
	moveTo(t) {
		const i = this.paneIndex();
		i !== t && (o(t >= 0 && t < this.hv.lv().length, "Invalid pane index"), this.hv.Qt().Od(i, t));
	}
	getSeries() {
		return this.yt.Y_().map(((t) => this.jg(t))) ?? [];
	}
	getHTMLElement() {
		const t = this.hv.lv();
		return t && 0 !== t.length && t[this.paneIndex()] ? t[this.paneIndex()].fv() : null;
	}
	attachPrimitive(t) {
		this.yt.ol(t), t.attached && t.attached({
			chart: this.qg,
			requestUpdate: () => this.yt.Qt().ka()
		});
	}
	detachPrimitive(t) {
		this.yt._l(t);
	}
	priceScale(t) {
		if (null === this.yt.O_(t)) throw new Error(`Cannot find price scale with id: ${t}`);
		return new Js(this.hv, t, this.paneIndex());
	}
	setPreserveEmptyPane(t) {
		this.yt.j_(t);
	}
	preserveEmptyPane() {
		return this.yt.q_();
	}
	addCustomSeries(t, i = {}, n = 0) {
		return this.qg.addCustomSeries(t, i, n);
	}
	addSeries(t, i = {}) {
		return this.qg.addSeries(t, i, this.paneIndex());
	}
};
var te = {
	color: "#FF0000",
	price: 0,
	lineStyle: 2,
	lineWidth: 1,
	lineVisible: !0,
	axisLabelVisible: !0,
	title: "",
	axisLabelColor: "",
	axisLabelTextColor: ""
};
var ie = class {
	constructor(t) {
		this._r = t;
	}
	applyOptions(t) {
		this._r.vr(t);
	}
	options() {
		return this._r.N();
	}
	Yg() {
		return this._r;
	}
};
var ne = class {
	constructor(t, i, n, s, e, r) {
		this.Kg = new d(), this.ae = t, this.Gg = i, this.Zg = n, this.Pu = e, this.qg = s, this.Xg = r;
	}
	m() {
		this.Kg.m();
	}
	priceFormatter() {
		return this.ae.sl();
	}
	priceToCoordinate(t) {
		const i = this.ae.Lt();
		return null === i ? null : this.ae.Ft().Nt(t, i.Wt);
	}
	coordinateToPrice(t) {
		const i = this.ae.Lt();
		return null === i ? null : this.ae.Ft().Tn(t, i.Wt);
	}
	barsInLogicalRange(t) {
		if (null === t) return null;
		const i = new Oi(new Ai(t.from, t.to)).Uu(), n = this.ae.Un();
		if (n.Zi()) return null;
		const s = n.Hn(i.Na(), 1), e = n.Hn(i.bi(), -1), r = u(n.Rh()), h = u(n.Qn());
		if (null !== s && null !== e && s.$n > e.$n) return {
			barsBefore: t.from - r,
			barsAfter: h - t.to
		};
		const a = {
			barsBefore: null === s || s.$n === r ? t.from - r : s.$n - r,
			barsAfter: null === e || e.$n === h ? h - t.to : h - e.$n
		};
		return null !== s && null !== e && (a.from = s.Qr, a.to = e.Qr), a;
	}
	setData(t) {
		this.Pu, this.ae.bh(), this.Gg.Jg(this.ae, t), this.Qg("full");
	}
	update(t, i = !1) {
		this.ae.bh(), this.Gg.tb(this.ae, t, i), this.Qg("update");
	}
	pop(t = 1) {
		const i = this.Gg.ib(this.ae, t);
		0 !== i.length && this.Qg("update");
		const n = $s(this.seriesType());
		return i.map(((t) => n(t)));
	}
	dataByIndex(t, i) {
		const n = this.ae.Un().Hn(t, i);
		if (null === n) return null;
		return $s(this.seriesType())(n);
	}
	data() {
		const t = $s(this.seriesType());
		return this.ae.Un().Bh().map(((i) => t(i)));
	}
	subscribeDataChanged(t) {
		this.Kg.i(t);
	}
	unsubscribeDataChanged(t) {
		this.Kg._(t);
	}
	applyOptions(t) {
		this.ae.vr(t);
	}
	options() {
		return M(this.ae.N());
	}
	priceScale() {
		return this.Zg.priceScale(this.ae.Ft().pl(), this.getPane().paneIndex());
	}
	createPriceLine(t) {
		const i = f(M(te), t);
		return new ie(this.ae.Ea(i));
	}
	removePriceLine(t) {
		this.ae.Aa(t.Yg());
	}
	priceLines() {
		return this.ae.La().map(((t) => new ie(t)));
	}
	seriesType() {
		return this.ae.bh();
	}
	lastValueData(t) {
		const i = this.ae.Ae(t);
		return i.Le ? { noData: !0 } : {
			noData: !1,
			price: i.Mt,
			color: i.R
		};
	}
	attachPrimitive(t) {
		this.ae.ol(t), t.attached && t.attached({
			chart: this.qg,
			series: this,
			requestUpdate: () => this.ae.Qt().ka(),
			horzScaleBehavior: this.Pu
		});
	}
	detachPrimitive(t) {
		this.ae._l(t), t.detached && t.detached(), this.ae.Qt().ka();
	}
	getPane() {
		const t = this.ae, i = u(this.ae.Qt().Ks(t));
		return this.Xg(i);
	}
	moveToPane(t) {
		this.ae.Qt().rf(this.ae, t);
	}
	seriesOrder() {
		const t = this.ae.Qt().Ks(this.ae);
		return null === t ? -1 : t.Y_().indexOf(this.ae);
	}
	setSeriesOrder(t) {
		const i = this.ae.Qt().Ks(this.ae);
		null !== i && i.vu(this.ae, t);
	}
	Qg(t) {
		this.Kg.v() && this.Kg.p(t);
	}
};
var se = class {
	constructor(t, i, n) {
		this.nb = new d(), this.Qu = new d(), this.Nw = new d(), this.sn = t, this.ia = t.Et(), this.vM = i, this.ia.Zc().i(this.sb.bind(this)), this.ia.Xc().i(this.eb.bind(this)), this.vM.qw().i(this.rb.bind(this)), this.Pu = n;
	}
	m() {
		this.ia.Zc().u(this), this.ia.Xc().u(this), this.vM.qw().u(this), this.nb.m(), this.Qu.m(), this.Nw.m();
	}
	scrollPosition() {
		return this.ia.Oc();
	}
	scrollToPosition(t, i) {
		i ? this.ia.Yc(t, 1e3) : this.sn.gs(t);
	}
	scrollToRealTime() {
		this.ia.qc();
	}
	getVisibleRange() {
		const t = this.ia.xc();
		return null === t ? null : {
			from: t.from.originalTime,
			to: t.to.originalTime
		};
	}
	setVisibleRange(t) {
		const i = {
			from: this.Pu.convertHorzItemToInternal(t.from),
			to: this.Pu.convertHorzItemToInternal(t.to)
		}, n = this.ia.kc(i);
		this.sn.sf(n);
	}
	getVisibleLogicalRange() {
		const t = this.ia.Sc();
		return null === t ? null : {
			from: t.Na(),
			to: t.bi()
		};
	}
	setVisibleLogicalRange(t) {
		o(t.from <= t.to, "The from index cannot be after the to index."), this.sn.sf(t);
	}
	resetTimeScale() {
		this.sn.ws();
	}
	fitContent() {
		this.sn.td();
	}
	logicalToCoordinate(t) {
		const i = this.sn.Et();
		return i.Zi() ? null : i.jt(t);
	}
	coordinateToLogical(t) {
		return this.ia.Zi() ? null : this.ia.Vc(t);
	}
	timeToIndex(t, i) {
		const n = this.Pu.convertHorzItemToInternal(t);
		return this.ia.Mc(n, i);
	}
	timeToCoordinate(t) {
		const i = this.timeToIndex(t, !1);
		return null === i ? null : this.ia.jt(i);
	}
	coordinateToTime(t) {
		const i = this.sn.Et(), n = i.Vc(t), s = i.en(n);
		return null === s ? null : s.originalTime;
	}
	width() {
		return this.vM.pv().width;
	}
	height() {
		return this.vM.pv().height;
	}
	subscribeVisibleTimeRangeChange(t) {
		this.nb.i(t);
	}
	unsubscribeVisibleTimeRangeChange(t) {
		this.nb._(t);
	}
	subscribeVisibleLogicalRangeChange(t) {
		this.Qu.i(t);
	}
	unsubscribeVisibleLogicalRangeChange(t) {
		this.Qu._(t);
	}
	subscribeSizeChange(t) {
		this.Nw.i(t);
	}
	unsubscribeSizeChange(t) {
		this.Nw._(t);
	}
	applyOptions(t) {
		this.ia.vr(t);
	}
	options() {
		return {
			...M(this.ia.N()),
			barSpacing: this.ia.ml()
		};
	}
	sb() {
		this.nb.v() && this.nb.p(this.getVisibleRange());
	}
	eb() {
		this.Qu.v() && this.Qu.p(this.getVisibleLogicalRange());
	}
	rb(t) {
		this.Nw.p(t.width, t.height);
	}
};
function ee(t) {
	return function(t) {
		if (w(t.handleScale)) {
			const i = t.handleScale;
			t.handleScale = {
				axisDoubleClickReset: {
					time: i,
					price: i
				},
				axisPressedMouseMove: {
					time: i,
					price: i
				},
				mouseWheel: i,
				pinch: i
			};
		} else if (void 0 !== t.handleScale) {
			const { axisPressedMouseMove: i, axisDoubleClickReset: n } = t.handleScale;
			w(i) && (t.handleScale.axisPressedMouseMove = {
				time: i,
				price: i
			}), w(n) && (t.handleScale.axisDoubleClickReset = {
				time: n,
				price: n
			});
		}
		const i = t.handleScroll;
		w(i) && (t.handleScroll = {
			horzTouchDrag: i,
			vertTouchDrag: i,
			mouseWheel: i,
			pressedMouseMove: i
		});
	}(t), t;
}
var re = class {
	constructor(t, i, n) {
		this.hb = /* @__PURE__ */ new Map(), this.ab = /* @__PURE__ */ new Map(), this.lb = new d(), this.ob = new d(), this._b = new d(), this.dd = /* @__PURE__ */ new WeakMap(), this.ub = new fs(i);
		const s = void 0 === n ? M(Xs()) : f(M(Xs()), ee(n));
		this.cb = i, this.hv = new Xn(t, s, i), this.hv.mw().i(((t) => {
			this.lb.v() && this.lb.p(this.fb(t()));
		}), this), this.hv.ww().i(((t) => {
			this.ob.v() && this.ob.p(this.fb(t()));
		}), this), this.hv.Bd().i(((t) => {
			this._b.v() && this._b.p(this.fb(t()));
		}), this);
		const e = this.hv.Qt();
		this.pb = new se(e, this.hv.bM(), this.cb);
	}
	remove() {
		this.hv.mw().u(this), this.hv.ww().u(this), this.hv.Bd().u(this), this.pb.m(), this.hv.m(), this.hb.clear(), this.ab.clear(), this.lb.m(), this.ob.m(), this._b.m(), this.ub.m();
	}
	resize(t, i, n) {
		this.autoSizeActive() || this.hv.wM(t, i, n);
	}
	addCustomSeries(t, i = {}, n = 0) {
		const s = ((t) => ({
			type: "Custom",
			isBuiltIn: !1,
			defaultOptions: {
				...As,
				...t.defaultOptions()
			},
			mb: Ls,
			wb: t
		}))(c(t));
		return this.Mb(s, i, n);
	}
	addSeries(t, i = {}, n = 0) {
		return this.Mb(t, i, n);
	}
	removeSeries(t) {
		const i = _(this.hb.get(t)), n = this.ub.if(i);
		this.hv.Qt().if(i), this.gb(n), this.hb.delete(t), this.ab.delete(i);
	}
	Jg(t, i) {
		this.gb(this.ub.og(t, i));
	}
	tb(t, i, n) {
		this.gb(this.ub.pg(t, i, n));
	}
	ib(t, i) {
		const [n, s] = this.ub.wg(t, i);
		return 0 !== n.length && this.gb(s), n;
	}
	subscribeClick(t) {
		this.lb.i(t);
	}
	unsubscribeClick(t) {
		this.lb._(t);
	}
	subscribeCrosshairMove(t) {
		this._b.i(t);
	}
	unsubscribeCrosshairMove(t) {
		this._b._(t);
	}
	subscribeDblClick(t) {
		this.ob.i(t);
	}
	unsubscribeDblClick(t) {
		this.ob._(t);
	}
	priceScale(t, i = 0) {
		return new Js(this.hv, t, i);
	}
	timeScale() {
		return this.pb;
	}
	applyOptions(t) {
		this.hv.vr(ee(t));
	}
	options() {
		return this.hv.N();
	}
	takeScreenshot(t = !1, i = !1) {
		let n, s;
		try {
			i || (n = this.hv.Qt().N().crosshair.mode, this.hv.vr({ crosshair: { mode: 2 } })), s = this.hv.TM(t);
		} finally {
			i || void 0 === n || this.hv.Qt().vr({ crosshair: { mode: n } });
		}
		return s;
	}
	addPane(t = !1) {
		const i = this.hv.Qt().uf();
		return i.j_(t), this.bb(i);
	}
	removePane(t) {
		this.hv.Qt().Ad(t);
	}
	swapPanes(t, i) {
		this.hv.Qt().zd(t, i);
	}
	autoSizeActive() {
		return this.hv.CM();
	}
	chartElement() {
		return this.hv.Mv();
	}
	panes() {
		return this.hv.Qt().Gn().map(((t) => this.bb(t)));
	}
	paneSize(t = 0) {
		const i = this.hv.AM(t);
		return {
			height: i.height,
			width: i.width
		};
	}
	setCrosshairPosition(t, i, n) {
		const s = this.hb.get(n);
		if (void 0 === s) return;
		const e = this.hv.Qt().Ks(s);
		null !== e && this.hv.Qt().Gd(t, i, e);
	}
	clearCrosshairPosition() {
		this.hv.Qt().Zd(!0);
	}
	horzBehaviour() {
		return this.cb;
	}
	Mb(t, i = {}, n = 0) {
		o(void 0 !== t.mb), function(t) {
			if (void 0 === t || "custom" === t.type) return;
			const i = t;
			void 0 !== i.minMove && void 0 === i.precision && (i.precision = Yi(i.minMove));
		}(i.priceFormat), "Candlestick" === t.type && function(t) {
			void 0 !== t.borderColor && (t.borderUpColor = t.borderColor, t.borderDownColor = t.borderColor), void 0 !== t.wickColor && (t.wickUpColor = t.wickColor, t.wickDownColor = t.wickColor);
		}(i);
		const s = f(M(e), M(t.defaultOptions), i), r = t.mb, h = new Jt(this.hv.Qt(), t.type, s, r, t.wb);
		this.hv.Qt().Qd(h, n);
		const a = new ne(h, this, this, this, this.cb, ((t) => this.bb(t)));
		return this.hb.set(a, h), this.ab.set(h, a), a;
	}
	gb(t) {
		const i = this.hv.Qt();
		for (const i of t.Y_.keys()) i.Ia();
		i.Xd(t.Et.Dc, t.Et.Sg, t.Et.xg), t.Y_.forEach(((t, i) => i.ht(t.ue, t.bg))), i.Et().dc(), i.Lc();
	}
	Sb(t) {
		return _(this.ab.get(t));
	}
	xb(t) {
		return void 0 !== t && this.ab.has(t) ? this.Sb(t) : void 0;
	}
	fb(t) {
		const i = /* @__PURE__ */ new Map();
		t.QM.forEach(((t, n) => {
			const s = n.bh(), e = $s(s)(t);
			if ("Custom" !== s) o(ts(e));
			else {
				const t = n.cl();
				o(!t || !1 === t(e));
			}
			i.set(this.Sb(n), e);
		}));
		const n = this.xb(t.jM), s = void 0 === t.YM ? void 0 : {
			type: t.YM.ds,
			sourceKind: t.YM.KM,
			objectKind: t.YM.GM,
			series: this.xb(t.YM.Y_),
			objectId: t.YM.ZM,
			paneIndex: t.YM.XM
		};
		return {
			time: t.Qr,
			logical: t.$n,
			point: t.JM,
			paneIndex: t.XM,
			hoveredInfo: s,
			hoveredSeries: n,
			hoveredObjectId: t.qM,
			seriesData: i,
			sourceEvent: t.tg
		};
	}
	bb(t) {
		let i = this.dd.get(t);
		return i || (i = new Qs(this.hv, ((t) => this.Sb(t)), t, this), this.dd.set(t, i)), i;
	}
};
function he(t) {
	if (m(t)) {
		const i = document.getElementById(t);
		return o(null !== i, `Cannot find element in DOM with id=${t}`), i;
	}
	return t;
}
function ae(t, i, n) {
	const e = new re(he(t), i, n);
	return i.setOptions(e.options()), e;
}
function le(t, i) {
	return ae(t, new cn(), cn.Tf(i));
}
function _e(t, i, n, s) {
	return Math.hypot(n - t, s - i);
}
function ue(t, i, n, s, e, r, h, a = 0) {
	if (0 === i.length || s.from >= i.length || s.to <= 0) return;
	const { context: l, horizontalPixelRatio: o, verticalPixelRatio: _ } = t, u = i[s.from];
	let c = r(t, u), d = u;
	if (s.to - s.from < 2) {
		const i = e / 2;
		l.beginPath();
		const n = {
			_t: u._t - i,
			ut: u.ut
		}, s = {
			_t: u._t + i,
			ut: u.ut
		};
		l.moveTo(n._t * o, n.ut * _), l.lineTo(s._t * o, s.ut * _), h(t, c, n, s);
	} else {
		const e = a > 0;
		let f = 0;
		const p = (i, n) => {
			if (h(t, c, d, n), l.beginPath(), c = i, d = n, e) {
				const t = f % a;
				l.lineDashOffset = t, f = t;
			}
		};
		let v = d;
		l.beginPath(), l.moveTo(u._t * o, u.ut * _);
		for (let h = s.from + 1; h < s.to; ++h) {
			v = i[h];
			const s = v._t * o, a = v.ut * _, u = r(t, v);
			switch (n) {
				case 0:
					if (l.lineTo(s, a), e) {
						const t = i[h - 1], n = t._t * o, e = t.ut * _;
						f += _e(n, e, s, a);
					}
					break;
				case 1: {
					const t = i[h - 1], n = t.ut * _;
					l.lineTo(s, n), e && (f += Math.abs(v._t - t._t) * o), u !== c && (p(u, v), l.lineTo(s, n)), l.lineTo(s, a), e && (f += Math.abs(v.ut - t.ut) * _);
					break;
				}
				case 2: {
					const [t, n] = pe(i, h - 1, h), r = t._t * o, u = t.ut * _, c = n._t * o, d = n.ut * _;
					if (l.bezierCurveTo(r, u, c, d, s, a), e) {
						const t = i[h - 1], n = t._t * o, e = t.ut * _, l = _e(n, e, s, a), p = _e(n, e, r, u) + _e(r, u, c, d) + _e(c, d, s, a);
						f += (l + p) / 2;
					}
					break;
				}
			}
			1 !== n && u !== c && (p(u, v), l.moveTo(s, a));
		}
		(d !== v || d === v && 1 === n) && h(t, c, d, v), e && (l.lineDashOffset = 0);
	}
}
var ce = 6;
function de(t, i) {
	return {
		_t: t._t - i._t,
		ut: t.ut - i.ut
	};
}
function fe(t, i) {
	return {
		_t: t._t / i,
		ut: t.ut / i
	};
}
function pe(t, i, n) {
	const s = Math.max(0, i - 1), e = Math.min(t.length - 1, n + 1);
	var r, h;
	return [(r = t[i], h = fe(de(t[n], t[s]), ce), {
		_t: r._t + h._t,
		ut: r.ut + h.ut
	}), de(t[n], fe(de(t[e], t[i]), ce))];
}
function ve(t, i) {
	const n = t.context;
	n.strokeStyle = i, n.stroke();
}
var me = class extends R {
	constructor() {
		super(...arguments), this.rt = null;
	}
	ht(t) {
		this.rt = t;
	}
	et(t) {
		if (null === this.rt) return;
		const { ot: i, lt: n, Cb: s, yb: e, ct: r, Gt: h, Pb: l } = this.rt;
		if (null === n) return;
		const o = t.context;
		o.lineCap = "butt", o.lineWidth = r * t.verticalPixelRatio;
		const _ = a(o, h);
		o.lineJoin = "round";
		const u = this.kb.bind(this), c = function(t) {
			return t.reduce(((t, i) => t + i), 0);
		}(_);
		void 0 !== e && ue(t, i, e, n, s, u, ve, c), l && function(t, i, n, s, e) {
			if (s.to - s.from <= 0) return;
			const { horizontalPixelRatio: r, verticalPixelRatio: h, context: a } = t;
			let l = null;
			const o = Math.max(1, Math.floor(r)) % 2 / 2, _ = n * h + o;
			for (let n = s.to - 1; n >= s.from; --n) {
				const s = i[n];
				if (s) {
					const i = e(t, s);
					i !== l && (null !== l && a.fill(), a.beginPath(), a.fillStyle = i, l = i);
					const n = Math.round(s._t * r) + o, u = s.ut * h;
					a.moveTo(n, u), a.arc(n, u, _, 0, 2 * Math.PI);
				}
			}
			a.fill();
		}(t, i, l, n, u);
	}
};
var we = class extends me {
	kb(t, i) {
		return i.vt;
	}
};
function Me(t, i, n, s, e) {
	const r = 1 - e;
	return r * r * r * t + 3 * r * r * e * i + 3 * r * e * e * n + e * e * e * s;
}
function ge(t, i, n, s, e) {
	if (2 === n) {
		const [n, r] = pe(s, e - 1, e);
		return [Math.min(t._t, i._t, n._t, r._t), Math.max(t._t, i._t, n._t, r._t)];
	}
	return [Math.min(t._t, i._t), Math.max(t._t, i._t)];
}
function be(t, i, n, s, e, r, h, a) {
	switch (e) {
		case 1: {
			const e = Ss(t, i, n._t, n.ut, s._t, n.ut), r = Ss(t, i, s._t, n.ut, s._t, s.ut), h = Math.min(e, r);
			return h <= a ? h : null;
		}
		case 2: {
			const [e, l] = pe(r, h - 1, h), o = function(t, i, n) {
				let s = Number.POSITIVE_INFINITY, e = n[0];
				for (let r = 1; r <= 12; r++) {
					const h = r / 12, a = {
						_t: Me(n[0]._t, n[1]._t, n[2]._t, n[3]._t, h),
						ut: Me(n[0].ut, n[1].ut, n[2].ut, n[3].ut, h)
					};
					s = Math.min(s, Ss(t, i, e._t, e.ut, a._t, a.ut)), e = a;
				}
				return s;
			}(t, i, [
				n,
				e,
				l,
				s
			]);
			return o <= a ? o : null;
		}
		default: {
			const e = Ss(t, i, n._t, n.ut, s._t, s.ut);
			return e <= a ? e : null;
		}
	}
}
var Se = class extends Ds {
	constructor(t, i) {
		super(t, i, !0);
	}
	Og(t, i, n) {
		i.Ic(this.kg, b(this.Tg)), t.Jo(this.kg, n, b(this.Tg));
	}
	Tb(t, i) {
		return {
			wt: t,
			Mt: i,
			_t: NaN,
			ut: NaN
		};
	}
	Lg() {
		const t = this.ae.Sa();
		this.kg = this.ae.Ua().Bh().map(((i) => {
			let n;
			if ((i.Gr ?? 1) > 1) {
				const t = i.Wt[1], s = i.Wt[2], e = i.Wt[3];
				n = Math.abs(t - e) > Math.abs(s - e) ? t : s;
			} else n = i.Wt[3];
			return this.Rb(i.$n, n, t);
		}));
	}
};
var xe = class extends Se {
	Bg(t, i) {
		const n = this.ae.N();
		return function(t, i, n, s, e, r, h, a = 0, l = 0) {
			if (null === i || i.from >= i.to || 0 === t.length) return null;
			const o = Math.max(r / 2, h ?? 0) + l;
			let _ = Number.POSITIVE_INFINITY;
			if (void 0 !== h) {
				const e = h + l, r = ws(t, n - e, i.from, i.to), a = Ms(t, n + e, r, i.to);
				for (let i = r; i < a; i++) {
					const e = t[i];
					if (!bs(n, e._t, e._t, h + l)) continue;
					const r = Math.hypot(n - e._t, s - e.ut);
					r <= h + l && (_ = Math.min(_, r));
				}
			}
			if (i.to - i.from < 2) {
				const e = t[i.from], r = Math.max(a / 2, o), h = Ss(n, s, e._t - r, e.ut, e._t + r, e.ut);
				return h <= o && (_ = Math.min(_, h)), Number.isFinite(_) ? gs(_, 2, "series-point") : null;
			}
			let u = Number.POSITIVE_INFINITY;
			const c = ws(t, n - o, i.from, i.to), d = Ms(t, n + o, c, i.to), f = Math.max(i.from + 1, c), p = Math.min(i.to, d + 1);
			for (let i = f; i < p; i++) {
				const r = t[i - 1], h = t[i], [a, l] = ge(r, h, e, t, i);
				if (!bs(n, a, l, o)) continue;
				const _ = be(n, s, r, h, e, t, i, o);
				null !== _ && (u = Math.min(u, _));
			}
			return Number.isFinite(_) ? gs(_, 2, "series-point") : Number.isFinite(u) ? gs(u, 1, "series-line") : null;
		}(this.kg, this.Tg, t, i, n.lineType, n.lineVisible ? n.lineWidth : 1, n.pointMarkersVisible ? n.pointMarkersRadius || n.lineWidth / 2 + 2 : void 0, this.le.Et().ml(), n.hitTestTolerance);
	}
};
var Ce = class extends xe {
	constructor() {
		super(...arguments), this.Vg = new we();
	}
	Rb(t, i, n) {
		return {
			...this.Tb(t, i),
			...n.Sh(t)
		};
	}
	Ng() {
		const t = this.ae.N(), i = {
			ot: this.kg,
			Gt: t.lineStyle,
			yb: t.lineVisible ? t.lineType : void 0,
			ct: t.lineWidth,
			Pb: t.pointMarkersVisible ? t.pointMarkersRadius || t.lineWidth / 2 + 2 : void 0,
			lt: this.Tg,
			Cb: this.le.Et().ml()
		};
		this.Vg.ht(i);
	}
};
var ye = {
	type: "Line",
	isBuiltIn: !0,
	defaultOptions: {
		color: "#2196f3",
		lineStyle: 0,
		lineWidth: 3,
		lineType: 0,
		lineVisible: !0,
		crosshairMarkerVisible: !0,
		crosshairMarkerRadius: 4,
		crosshairMarkerBorderColor: "",
		crosshairMarkerBorderWidth: 2,
		crosshairMarkerBackgroundColor: "",
		lastPriceAnimation: 0,
		pointMarkersVisible: !1
	},
	mb: (t, i) => new Ce(t, i)
};
var Ke = class extends Ds {
	constructor(t, i) {
		super(t, i, !1);
	}
	Bg(t, i) {
		return Ps(this.kg, this.Tg, t, i, this.le.Et().ml(), this.ae.N().hitTestTolerance, ((t, i) => {
			i[0] = t.n_, i[1] = t.s_;
		}));
	}
	Og(t, i, n) {
		i.Ic(this.kg, b(this.Tg)), t.t_(this.kg, n, b(this.Tg));
	}
	fS(t, i, n) {
		return {
			wt: t,
			jr: i.Wt[0],
			qr: i.Wt[1],
			Yr: i.Wt[2],
			Kr: i.Wt[3],
			_t: NaN,
			i_: NaN,
			n_: NaN,
			s_: NaN,
			e_: NaN
		};
	}
	Lg() {
		const t = this.ae.Sa();
		this.kg = this.ae.Ua().Bh().map(((i) => this.Rb(i.$n, i, t)));
	}
};
var Xe = class extends R {
	constructor() {
		super(...arguments), this.qt = null, this.oS = 0;
	}
	ht(t) {
		this.qt = t;
	}
	et(t) {
		if (null === this.qt || 0 === this.qt.Un.length || null === this.qt.lt) return;
		const { horizontalPixelRatio: i } = t;
		if (this.oS = function(t, i) {
			if (t >= 2.5 && t <= 4) return Math.floor(3 * i);
			const n = 1 - .2 * Math.atan(Math.max(4, t) - 4) / (.5 * Math.PI), s = Math.floor(t * n * i), e = Math.floor(t * i);
			return Math.max(Math.floor(i), Math.min(s, e));
		}(this.qt.ml, i), this.oS >= 2) Math.floor(i) % 2 != this.oS % 2 && this.oS--;
		const n = this.qt.Un;
		this.qt.pS && this.vS(t, n, this.qt.lt), this.qt.gi && this.Vm(t, n, this.qt.lt);
		const s = this.mS(i);
		(!this.qt.gi || this.oS > 2 * s) && this.wS(t, n, this.qt.lt);
	}
	vS(t, i, n) {
		if (null === this.qt) return;
		const { context: s, horizontalPixelRatio: e, verticalPixelRatio: r } = t;
		let h = "", a = Math.min(Math.floor(e), Math.floor(this.qt.ml * e));
		a = Math.max(Math.floor(e), Math.min(a, this.oS));
		const l = Math.floor(.5 * a);
		let o = null;
		for (let t = n.from; t < n.to; t++) {
			const n = i[t];
			n.rh !== h && (s.fillStyle = n.rh, h = n.rh);
			const _ = Math.round(Math.min(n.i_, n.e_) * r), u = Math.round(Math.max(n.i_, n.e_) * r), c = Math.round(n.n_ * r), d = Math.round(n.s_ * r);
			let f = Math.round(e * n._t) - l;
			const p = f + a - 1;
			null !== o && (f = Math.max(o + 1, f), f = Math.min(f, p));
			const v = p - f + 1;
			s.fillRect(f, c, v, _ - c), s.fillRect(f, u + 1, v, d - u), o = p;
		}
	}
	mS(t) {
		let i = Math.floor(1 * t);
		this.oS <= 2 * i && (i = Math.floor(.5 * (this.oS - 1)));
		const n = Math.max(Math.floor(t), i);
		return this.oS <= 2 * n ? Math.max(Math.floor(t), Math.floor(1 * t)) : n;
	}
	Vm(t, i, n) {
		if (null === this.qt) return;
		const { context: s, horizontalPixelRatio: e, verticalPixelRatio: r } = t;
		let h = "";
		const a = this.mS(e);
		let l = null;
		for (let t = n.from; t < n.to; t++) {
			const n = i[t];
			n.eh !== h && (s.fillStyle = n.eh, h = n.eh);
			let o = Math.round(n._t * e) - Math.floor(.5 * this.oS);
			const _ = o + this.oS - 1, u = Math.round(Math.min(n.i_, n.e_) * r), c = Math.round(Math.max(n.i_, n.e_) * r);
			if (null !== l && (o = Math.max(l + 1, o), o = Math.min(o, _)), this.qt.ml * e > 2 * a) L(s, o, u, _ - o + 1, c - u + 1, a);
			else {
				const t = _ - o + 1;
				s.fillRect(o, u, t, c - u + 1);
			}
			l = _;
		}
	}
	wS(t, i, n) {
		if (null === this.qt) return;
		const { context: s, horizontalPixelRatio: e, verticalPixelRatio: r } = t;
		let h = "";
		const a = this.mS(e);
		for (let t = n.from; t < n.to; t++) {
			const n = i[t];
			let l = Math.round(Math.min(n.i_, n.e_) * r), o = Math.round(Math.max(n.i_, n.e_) * r), _ = Math.round(n._t * e) - Math.floor(.5 * this.oS), u = _ + this.oS - 1;
			if (n.sh !== h) {
				const t = n.sh;
				s.fillStyle = t, h = t;
			}
			this.qt.gi && (_ += a, l += a, u -= a, o -= a), l > o || s.fillRect(_, l, u - _ + 1, o - l + 1);
		}
	}
};
var Je = class extends Ke {
	constructor() {
		super(...arguments), this.Vg = new Xe();
	}
	Rb(t, i, n) {
		return {
			...this.fS(t, i, n),
			...n.Sh(t)
		};
	}
	Ng() {
		const t = this.ae.N();
		this.Vg.ht({
			Un: this.kg,
			ml: this.le.Et().ml(),
			pS: t.wickVisible,
			gi: t.borderVisible,
			lt: this.Tg
		});
	}
};
var Qe = {
	type: "Candlestick",
	isBuiltIn: !0,
	defaultOptions: {
		upColor: "#26a69a",
		downColor: "#ef5350",
		wickVisible: !0,
		borderVisible: !0,
		borderColor: "#378658",
		borderUpColor: "#26a69a",
		borderDownColor: "#ef5350",
		wickColor: "#737375",
		wickUpColor: "#26a69a",
		wickDownColor: "#ef5350"
	},
	mb: (t, i) => new Je(t, i)
};
({ ...e });
//#endregion
export { lightweight_charts_production_exports as t };
