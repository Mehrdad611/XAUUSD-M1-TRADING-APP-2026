import { useEffect } from "react";
import { CircleHelp, Shuffle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SCENARIOS } from "@/lib/xau/scenarios";
import { pct, usd } from "@/lib/xau/format";
import { useDesk } from "@/lib/xau/store";
import { HowTo } from "./HowTo";

export function StartMenu() {
  const startScenario = useDesk((s) => s.startScenario);
  const startRandom = useDesk((s) => s.startRandom);
  const scores = useDesk((s) => s.scores);
  const howTo = useDesk((s) => s.howTo);
  const openHowTo = useDesk((s) => s.openHowTo);
  const hydrateScores = useDesk((s) => s.hydrateScores);
  const startingCash = useDesk((s) => s.startingCash);

  useEffect(() => {
    hydrateScores();
  }, [hydrateScores]);

  return (
    <main className="mx-auto flex min-h-dvh w-full max-w-5xl flex-col px-4 pb-16 pt-10 sm:px-6 sm:pt-16">
      <header className="stagger-in mb-10 max-w-xl">
        <p className="mb-3 font-mono text-xs tracking-widest text-metal">XAUUSD DESK</p>
        <h1 className="text-4xl font-medium leading-tight tracking-tight text-fg sm:text-5xl">میز طلا</h1>
        <p className="mt-4 text-base leading-relaxed text-muted">
          شبیه‌ساز معامله روی تاریخچه واقعی طلا. کندل‌های آینده را نمی‌بینی؛ با سرمایه مجازی تصمیم می‌گیری و در پایان با نگهداری طلا مقایسه می‌شوی.
        </p>
        <div className="mt-6 flex flex-wrap items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => openHowTo(true)}>
            <CircleHelp className="size-4" />
            راهنما
          </Button>
          <p className="text-sm text-faint">سرمایه {usd(startingCash, true)} · داده روزانه ۲۰۱۰ تا ۲۰۲۵</p>
        </div>
      </header>

      <section className="stagger-in grid grid-cols-1 gap-3 sm:grid-cols-2">
        {SCENARIOS.map((sc) => {
          const best = scores.best[sc.id];
          return (
            <button
              key={sc.id}
              type="button"
              onClick={() => startScenario(sc.id)}
              className="rounded-xl border border-border bg-surface p-4 text-right transition-[border-color,background-color,transform] duration-[var(--motion-fast)] ease-[var(--ease-out)] hover:border-border-strong hover:bg-raised active:scale-[0.99]"
            >
              <div className="mb-3 flex items-baseline justify-between gap-3">
                <h2 className="text-lg font-medium tracking-tight">{sc.title}</h2>
                <span className="font-mono text-xs text-metal">{sc.tone}</span>
              </div>
              <p className="text-sm leading-relaxed text-muted">{sc.blurb}</p>
              <div className="mt-4 flex items-center justify-between text-xs text-faint">
                <span>{sc.era}</span>
                {best ? (
                  <span className={best.returnPct >= 0 ? "text-profit" : "text-loss"}>
                    بهترین: {pct(best.returnPct)}
                  </span>
                ) : (
                  <span>هنوز بازی نشده</span>
                )}
              </div>
            </button>
          );
        })}

        <button
          type="button"
          onClick={startRandom}
          className="rounded-xl border border-dashed border-border bg-transparent p-4 text-right transition-[border-color,background-color] duration-[var(--motion-fast)] ease-[var(--ease-out)] hover:border-metal/40 hover:bg-surface sm:col-span-2"
        >
          <div className="flex items-center gap-3">
            <Shuffle className="size-4 text-metal" />
            <div>
              <h2 className="text-lg font-medium tracking-tight">پنجره تصادفی</h2>
              <p className="mt-1 text-sm text-muted">۹۰ روز پنهان از ۱۷ سال تاریخ طلا. بدون داستان، فقط نمودار.</p>
            </div>
          </div>
        </button>
      </section>

      <HowTo open={howTo} onOpenChange={openHowTo} />
    </main>
  );
}