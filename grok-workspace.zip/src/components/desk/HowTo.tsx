import * as Dialog from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";

type Props = {
  open: boolean;
  onOpenChange: (v: boolean) => void;
};

export function HowTo({ open, onOpenChange }: Props) {
  return (
    <Dialog.Root open={open} onOpenChange={onOpenChange}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-50 bg-bg/70 data-[state=open]:animate-in data-[state=closed]:animate-out" />
        <Dialog.Content className="fixed inset-x-4 top-1/2 z-50 mx-auto max-w-md -translate-y-1/2 rounded-xl border border-border bg-surface p-6 shadow-none outline-none">
          <div className="mb-5 flex items-start justify-between gap-4">
            <Dialog.Title className="text-lg font-medium tracking-tight">چطور بازی می‌شود</Dialog.Title>
            <Dialog.Close asChild>
              <Button variant="ghost" size="icon" aria-label="بستن" className="size-9">
                <X />
              </Button>
            </Dialog.Close>
          </div>
          <Dialog.Description className="sr-only">قوانین میز طلا</Dialog.Description>
          <ul className="space-y-3 text-sm leading-relaxed text-muted">
            <li>هر کندل یک روز واقعی از قیمت طلا (XAUUSD / آتی COMEX) است. آینده نمودار پنهان می‌ماند.</li>
            <li>سرمایه اولیه ۱۰٬۰۰۰ دلار مجازی است. خرید یعنی Long، فروش یعنی Short.</li>
            <li>اهرم سود و زیان را چند برابر می‌کند. اگر موجودی به سطح کال برسد، پوزیشن بسته می‌شود.</li>
            <li>
              کیبورد: Space توقف/حرکت، B خرید، S فروش، C بستن.
            </li>
            <li>هدف: بازدهی بهتر از نگهداری طلا تا پایان دوره (Buy & Hold).</li>
          </ul>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}