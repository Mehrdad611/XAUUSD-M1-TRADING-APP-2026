import { useEffect, useRef } from "react";
import { sma } from "@/lib/xau/engine";
import type { Bar, Position } from "@/lib/xau/types";

const THEME = {
  bg: "#09090b",
  text: "#9a958c",
  grid: "rgba(242,239,233,0.06)",
  metal: "#c4b59a",
  profit: "#3d9a78",
  loss: "#c45c5c",
  fg: "#f2efe9",
};

type Props = {
  bars: Bar[];
  cursor: number;
  position: Position | null;
};

type ChartApi = {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  chart: any;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  candle: any;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  ma: any;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  line: any;
};

function paint(api: ChartApi, bars: Bar[], cursor: number, position: Position | null) {
  const visible = bars.slice(0, cursor + 1);
  api.candle.setData(
    visible.map((b) => ({
      time: b.t,
      open: b.o,
      high: b.h,
      low: b.l,
      close: b.c,
    })),
  );
  api.ma.setData(sma(bars, 20, cursor));
  if (api.line) {
    api.candle.removePriceLine(api.line);
    api.line = null;
  }
  if (position) {
    api.line = api.candle.createPriceLine({
      price: position.entry,
      color: position.side === "long" ? THEME.profit : THEME.loss,
      lineWidth: 1,
      lineStyle: 2,
      axisLabelVisible: true,
      title: position.side === "long" ? "Long" : "Short",
    });
  }
  api.chart.timeScale().fitContent();
}

export function CandleChart({ bars, cursor, position }: Props) {
  const hostRef = useRef<HTMLDivElement>(null);
  const apiRef = useRef<ChartApi | null>(null);
  const latestRef = useRef({ bars, cursor, position });
  latestRef.current = { bars, cursor, position };

  useEffect(() => {
    const el = hostRef.current;
    if (!el) return;
    let cancelled = false;
    let chart: { remove: () => void } | undefined;

    import("lightweight-charts").then((lc) => {
      if (cancelled || !hostRef.current) return;
      const created = lc.createChart(hostRef.current, {
        autoSize: true,
        layout: {
          background: { type: lc.ColorType.Solid, color: THEME.bg },
          textColor: THEME.text,
          fontFamily: "IBM Plex Mono, ui-monospace, monospace",
          fontSize: 11,
        },
        grid: {
          vertLines: { color: THEME.grid },
          horzLines: { color: THEME.grid },
        },
        crosshair: {
          mode: lc.CrosshairMode.Normal,
          vertLine: { color: THEME.metal, width: 1, style: lc.LineStyle.SparseDotted },
          horzLine: { color: THEME.metal, width: 1, style: lc.LineStyle.SparseDotted },
        },
        rightPriceScale: {
          borderVisible: false,
          scaleMargins: { top: 0.08, bottom: 0.12 },
        },
        timeScale: {
          borderVisible: false,
          timeVisible: false,
        },
        localization: {
          priceFormatter: (p: number) => p.toFixed(2),
        },
      });
      chart = created;
      const candle = created.addSeries(lc.CandlestickSeries, {
        upColor: THEME.profit,
        downColor: THEME.loss,
        borderVisible: false,
        wickUpColor: THEME.profit,
        wickDownColor: THEME.loss,
      });
      const ma = created.addSeries(lc.LineSeries, {
        color: THEME.metal,
        lineWidth: 1,
        priceLineVisible: false,
        lastValueVisible: false,
        crosshairMarkerVisible: false,
      });
      const api: ChartApi = { chart: created, candle, ma, line: null };
      apiRef.current = api;
      const snap = latestRef.current;
      paint(api, snap.bars, snap.cursor, snap.position);
    });

    return () => {
      cancelled = true;
      apiRef.current = null;
      chart?.remove();
    };
  }, []);

  useEffect(() => {
    const api = apiRef.current;
    if (!api) return;
    paint(api, bars, cursor, position);
  }, [bars, cursor, position]);

  return <div ref={hostRef} dir="ltr" className="h-full w-full" />;
}