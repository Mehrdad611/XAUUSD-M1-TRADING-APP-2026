import { useEffect, useRef, type ReactNode } from "react";
import { ChevronRight, Pause, Play, Square } from "lucide-react";
import { Button } from "@/components/ui/button";
import { canAfford, equity, markPrice, unrealizedPnl } from "@/lib/xau/engine";
import { faDate, pct, px, signedUsd, usd } from "@/lib/xau/format";
import { useDesk, type Speed } from "@/lib/xau/store";
import type { ProtectMode } from "@/lib/xau/types";
import { CandleChart } from "./CandleChart";
import { cn } from "@/lib/utils";

const OUNCES = [0.1, 0.25, 0.5, 1, 2];
const LEVS = [1, 5, 10, 20];
const SPEEDS: { v: Speed; label: string }[] = [
  { v: 0, label: "توقف" },
  { v: 1, label: "۱×" },
  { v: 2, label: "۲×" },
  { v: 4, label: "۴×" },
];

function Chip({
  active,
  onClick,
  children,
  danger,
}: {
  active: boolean;
  onClick: () => void;
  children: ReactNode;
  danger?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "h-9 rounded-sm px-3 font-mono text-xs transition-[background-color,color,border-color] duration-[var(--motion-quick)]",
        active
          ? danger
            ? "border border-loss/40 bg-loss/20 text-loss"
            : "border border-accent/30 bg-accent text-accent-fg"
          : "border border-border bg-transparent text-muted hover:bg-raised hover:text-fg",
      )}
    >
      {children}
    </button>
  );
}

function Stat({ label, children, tone }: { label: string; children: React.ReactNode; tone?: "profit" | "loss" }) {
  return (
    <div className="min-w-0">
      <div className="text-[11px] text-faint">{label}</div>
      <div
        className={cn(
          "truncate font-mono text-sm tabular-nums sm:text-base",
          tone === "profit" && "text-profit",
          tone === "loss" && "text-loss",
        )}
      >
        {children}
      </div>
    </div>
  );
}

export function TradingDesk() {
  const match = useDesk((s) => s.match);
  const speed = useDesk((s) => s.speed);
  const setSpeed = useDesk((s) => s.setSpeed);
  const ounces = useDesk((s) => s.ounces);
  const leverage = useDesk((s) => s.leverage);
  const setOunces = useDesk((s) => s.setOunces);
  const setLeverage = useDesk((s) => s.setLeverage);
  const setProtectMode = useDesk((s) => s.setProtectMode);
  const buy = useDesk((s) => s.buy);
  const sell = useDesk((s) => s.sell);
  const closePos = useDesk((s) => s.closePos);
  const tickBar = useDesk((s) => s.tickBar);
  const finishNow = useDesk((s) => s.finishNow);
  const backToMenu = useDesk((s) => s.backToMenu);

  const tickRef = useRef(tickBar);
  tickRef.current = tickBar;

  useEffect(() => {
    if (!match || match.status !== "playing" || speed === 0) return;
    let raf = 0;
    let acc = 0;
    let last = performance.now();
    const interval = 1100 / speed;
    const loop = (now: number) => {
      const dt = Math.min(100, now - last);
      last = now;
      acc += dt;
      while (acc >= interval) {
        acc -= interval;
        tickRef.current();
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [match, speed]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if (e.code === "Space") {
        e.preventDefault();
        setSpeed(useDesk.getState().speed === 0 ? 1 : 0);
      } else if (e.key === "b" || e.key === "B") buy();
      else if (e.key === "s" || e.key === "S") sell();
      else if (e.key === "c" || e.key === "C") closePos();
      else if (e.key === "1") setSpeed(1);
      else if (e.key === "2") setSpeed(2);
      else if (e.key === "4") setSpeed(4);
      else if (e.key === "0") setSpeed(0);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [buy, sell, closePos, setSpeed]);

  if (!match) return null;

  const price = markPrice(match);
  const eq = equity(match);
  const u = unrealizedPnl(match);
  const ret = (eq - match.startingCash) / match.startingCash;
  const remain = match.bars.length - 1 - match.cursor;
  const pos = match.position;
  const progress = match.cursor / Math.max(1, match.bars.length - 1);
  const afford = canAfford(match);

  return (
    <div className="flex h-dvh flex-col bg-bg">
      <header className="flex shrink-0 items-center gap-3 border-b border-border px-3 py-2 sm:px-4">
        <button
          type="button"
          onClick={backToMenu}
          className="flex items-center gap-1 text-sm text-muted hover:text-fg"
        >
          <ChevronRight className="size-4" />
          میز
        </button>
        <div className="min-w-0 flex-1">
          <div className="truncate text-sm font-medium">{match.scenarioTitle}</div>
          <div className="font-mono text-[11px] text-faint" dir="ltr">
            XAUUSD · {faDate(match.bars[match.cursor]!.t)}
          </div>
        </div>
        <div className="hidden items-center gap-1 sm:flex">
          {SPEEDS.map((sp) => (
            <Chip key={sp.v} active={speed === sp.v} onClick={() => setSpeed(sp.v)}>
              {sp.label}
            </Chip>
          ))}
        </div>
        <Button
          variant="outline"
          size="icon"
          className="sm:hidden"
          aria-label={speed === 0 ? "پخش" : "توقف"}
          onClick={() => setSpeed(speed === 0 ? 1 : 0)}
        >
          {speed === 0 ? <Play className="size-4" /> : <Pause className="size-4" />}
        </Button>
      </header>

      <div className="grid shrink-0 grid-cols-2 gap-x-4 gap-y-2 border-b border-border px-3 py-3 sm:grid-cols-4 sm:px-4">
        <Stat label="حقوق" tone={ret > 0 ? "profit" : ret < 0 ? "loss" : undefined}>
          {usd(eq)}
        </Stat>
        <Stat label="بازدهی" tone={ret > 0 ? "profit" : ret < 0 ? "loss" : undefined}>
          {pct(ret)}
        </Stat>
        <Stat label="قیمت" >
          <span dir="ltr">{px(price)}</span>
        </Stat>
        <Stat
          label={pos ? (pos.side === "long" ? "خرید باز" : "فروش باز") : "پوزیشن"}
          tone={pos ? (u >= 0 ? "profit" : "loss") : undefined}
        >
          {pos ? signedUsd(u) : "—"}
        </Stat>
      </div>

      <div className="relative min-h-0 flex-1">
        <CandleChart bars={match.bars} cursor={match.cursor} position={pos} />
        <div className="pointer-events-none absolute inset-x-0 bottom-0 h-0.5 bg-raised">
          <div className="h-full bg-metal/70" style={{ width: `${progress * 100}%` }} />
        </div>
        {speed === 0 && match.cursor === match.playStart && (
          <div className="pointer-events-none absolute inset-x-0 top-4 flex justify-center">
            <p className="rounded-sm border border-border bg-surface/90 px-3 py-1.5 text-xs text-muted">
              بازار متوقف است. پوزیشن بگیر، بعد پخش را بزن.
            </p>
          </div>
        )}
      </div>

      <div className="shrink-0 border-t border-border bg-surface px-3 py-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] sm:px-4">
        <div className="mb-3 flex flex-wrap items-center gap-2">
          <span className="text-[11px] text-faint">حجم</span>
          {OUNCES.map((n) => (
            <Chip key={n} active={ounces === n} onClick={() => setOunces(n)}>
              {n} oz
            </Chip>
          ))}
          <span className="ms-2 text-[11px] text-faint">اهرم</span>
          {LEVS.map((n) => (
            <Chip key={n} active={leverage === n} danger={n >= 20} onClick={() => setLeverage(n)}>
              {n}×
            </Chip>
          ))}
        </div>
        <div className="mb-3 flex flex-wrap items-center gap-2">
          <span className="text-[11px] text-faint">محافظ</span>
          {(
            [
              ["off", "خاموش"],
              ["guard", "۲٪ / ۴٪"],
              ["tight", "۱٪ / ۲٫۵٪"],
            ] as [ProtectMode, string][]
          ).map(([id, label]) => (
            <Chip key={id} active={match.protect === id} onClick={() => setProtectMode(id)}>
              {label}
            </Chip>
          ))}
          <span className="ms-auto font-mono text-[11px] text-faint">{remain} روز مانده</span>
        </div>
        <div className="grid grid-cols-3 gap-2">
          <Button variant="buy" size="xl" onClick={buy} disabled={!pos && !afford}>
            خرید
          </Button>
          <Button variant="outline" size="xl" onClick={closePos} disabled={!pos}>
            بستن
          </Button>
          <Button variant="sell" size="xl" onClick={sell} disabled={!pos && !afford}>
            فروش
          </Button>
        </div>
        <div className="mt-2 flex items-center justify-between gap-2 sm:hidden">
          {SPEEDS.map((sp) => (
            <Chip key={sp.v} active={speed === sp.v} onClick={() => setSpeed(sp.v)}>
              {sp.label}
            </Chip>
          ))}
          <Button variant="ghost" size="sm" onClick={finishNow} className="text-faint">
            <Square className="size-3" />
            پایان
          </Button>
        </div>
        <div className="mt-2 hidden justify-end sm:flex">
          <Button variant="ghost" size="sm" onClick={finishNow} className="text-faint">
            پایان دوره
          </Button>
        </div>
      </div>
    </div>
  );
}