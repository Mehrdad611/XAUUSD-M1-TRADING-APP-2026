import { Button } from "@/components/ui/button";
import { faDate, pct, px, signedUsd, usd } from "@/lib/xau/format";
import { useDesk } from "@/lib/xau/store";
import { cn } from "@/lib/utils";

function grade(r: { status: string; returnPct: number; beatHold: boolean }) {
  if (r.status === "blown") return "کال مارجین";
  if (r.returnPct > 0 && r.beatHold) return "عالی";
  if (r.returnPct > 0) return "سود، کمتر از نگهداری";
  if (r.returnPct > -0.08) return "نزدیک به صفر";
  return "زیان";
}

export function ResultScreen() {
  const result = useDesk((s) => s.result);
  const backToMenu = useDesk((s) => s.backToMenu);
  const startScenario = useDesk((s) => s.startScenario);
  const startRandom = useDesk((s) => s.startRandom);

  if (!result) return null;

  const positive = result.returnPct >= 0;
  const replay = () => {
    if (result.scenarioId === "random") startRandom();
    else startScenario(result.scenarioId);
  };

  return (
    <main className="mx-auto flex min-h-dvh w-full max-w-lg flex-col px-4 py-10 sm:py-16">
      <p className="font-mono text-xs tracking-widest text-metal">SETTLEMENT</p>
      <h1 className="mt-2 text-3xl font-medium tracking-tight">{result.scenarioTitle}</h1>
      <p className="mt-2 text-sm text-muted">
        {faDate(result.startDate)} — {faDate(result.endDate)}
      </p>

      <div className="mt-8 rounded-xl border border-border bg-surface p-5">
        <p className="text-xs text-faint">بازدهی تو</p>
        <p
          className={cn(
            "mt-1 font-mono text-4xl tabular-nums tracking-tight",
            result.status === "blown" || !positive ? "text-loss" : "text-profit",
          )}
        >
          {pct(result.returnPct)}
        </p>
        <p className="mt-1 text-sm text-muted">{grade(result)}</p>
        <p className="mt-3 font-mono text-sm text-faint">
          {usd(result.startCash)} → {usd(result.endEquity)}
        </p>
      </div>

      <dl className="mt-4 grid grid-cols-2 gap-3">
        <div className="rounded-lg border border-border bg-surface p-4">
          <dt className="text-xs text-faint">نگهداری طلا</dt>
          <dd className={cn("mt-1 font-mono text-lg tabular-nums", result.holdPct >= 0 ? "text-profit" : "text-loss")}>
            {pct(result.holdPct)}
          </dd>
          <p className="mt-1 font-mono text-[11px] text-faint" dir="ltr">
            {px(result.startPrice)} → {px(result.endPrice)}
          </p>
        </div>
        <div className="rounded-lg border border-border bg-surface p-4">
          <dt className="text-xs text-faint">حداکثر افت</dt>
          <dd className="mt-1 font-mono text-lg tabular-nums text-loss">{pct(-result.maxDrawdown)}</dd>
          <p className="mt-1 text-[11px] text-faint">از اوج حقوق</p>
        </div>
        <div className="rounded-lg border border-border bg-surface p-4">
          <dt className="text-xs text-faint">معاملات</dt>
          <dd className="mt-1 font-mono text-lg tabular-nums">
            {result.wins}/{result.trades}
          </dd>
          <p className="mt-1 text-[11px] text-faint">برد / کل</p>
        </div>
        <div className="rounded-lg border border-border bg-surface p-4">
          <dt className="text-xs text-faint">در برابر نگهداری</dt>
          <dd className={cn("mt-1 text-lg font-medium", result.beatHold ? "text-profit" : "text-muted")}>
            {result.beatHold ? "بهتر" : "ضعیف‌تر"}
          </dd>
        </div>
      </dl>

      {result.tradeList.length > 0 && (
        <section className="mt-6">
          <h2 className="mb-2 text-sm text-muted">دفتر معاملات</h2>
          <ul className="divide-y divide-border overflow-hidden rounded-lg border border-border">
            {result.tradeList.map((t) => (
              <li key={t.id} className="flex items-center justify-between gap-3 bg-surface px-3 py-2.5">
                <div>
                  <span className={t.side === "long" ? "text-profit" : "text-loss"}>
                    {t.side === "long" ? "خرید" : "فروش"}
                  </span>
                  <span className="ms-2 font-mono text-[11px] text-faint">
                    {t.ounces}oz · {t.leverage}×
                  </span>
                </div>
                <span className={cn("font-mono text-sm tabular-nums", t.pnl >= 0 ? "text-profit" : "text-loss")}>
                  {signedUsd(t.pnl)}
                </span>
              </li>
            ))}
          </ul>
        </section>
      )}

      <div className="mt-8 flex flex-col gap-2">
        <Button size="lg" onClick={replay}>
          دوباره همین دوره
        </Button>
        <Button size="lg" variant="outline" onClick={backToMenu}>
          انتخاب سناریو
        </Button>
      </div>
    </main>
  );
}