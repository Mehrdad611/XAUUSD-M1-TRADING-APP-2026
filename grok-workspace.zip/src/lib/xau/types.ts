export type Timeframe = "1d" | "15m" | "5m";

export type Bar = {
  t: string | number;
  o: number;
  h: number;
  l: number;
  c: number;
};

export type Side = "long" | "short";

export type ExitReason = "manual" | "sl" | "tp" | "liquidation" | "eod";

export type ProtectMode = "off" | "guard" | "tight";

export type Trade = {
  id: number;
  side: Side;
  ounces: number;
  leverage: number;
  entryTime: string | number;
  entryPrice: number;
  exitTime: string | number;
  exitPrice: number;
  pnl: number;
  reason: ExitReason;
};

export type Position = {
  side: Side;
  ounces: number;
  leverage: number;
  entry: number;
  entryTime: string | number;
  margin: number;
  sl: number | null;
  tp: number | null;
};

export type MatchStatus = "playing" | "blown" | "finished";

export type MatchState = {
  scenarioId: string;
  scenarioTitle: string;
  timeframe: Timeframe;
  bars: Bar[];
  playStart: number;
  cursor: number;
  cash: number;
  position: Position | null;
  trades: Trade[];
  peakEquity: number;
  maxDrawdown: number;
  equityHistory: { t: string | number; v: number }[];
  status: MatchStatus;
  startingCash: number;
  ounces: number;
  leverage: number;
  protect: ProtectMode;
  tradeSeq: number;
};

export type Result = {
  scenarioId: string;
  scenarioTitle: string;
  timeframe: Timeframe;
  status: "finished" | "blown";
  startCash: number;
  endEquity: number;
  returnPct: number;
  holdPct: number;
  beatHold: boolean;
  trades: number;
  wins: number;
  maxDrawdown: number;
  startDate: string | number;
  endDate: string | number;
  startPrice: number;
  endPrice: number;
  tradeList: Trade[];
  equityHistory: { t: string | number; v: number }[];
};

export type Scenario = {
  id: string;
  title: string;
  era: string;
  tone: string;
  blurb: string;
  start: string;
  end: string;
  warmup: number;
  timeframe: Timeframe;
};

export type ScoreBoard = {
  version: 1;
  best: Record<string, { returnPct: number; beatHold: boolean; at: string }>;
};