import type {
  Bar,
  ExitReason,
  MatchState,
  Position,
  ProtectMode,
  Result,
  Side,
  Timeframe,
  Trade,
} from "./types";

export const STARTING_CASH = 10_000;
export const SPREAD = 0.5;
export const MAINTENANCE = 0.35;

const PROTECT: Record<Exclude<ProtectMode, "off">, { sl: number; tp: number }> = {
  guard: { sl: 0.02, tp: 0.04 },
  tight: { sl: 0.012, tp: 0.025 },
};

function ask(px: number) {
  return px + SPREAD / 2;
}
function bid(px: number) {
  return px - SPREAD / 2;
}

export function lastBar(s: MatchState): Bar {
  return s.bars[s.cursor]!;
}

export function markPrice(s: MatchState): number {
  return lastBar(s).c;
}

export function unrealizedPnl(s: MatchState, px = markPrice(s)): number {
  const p = s.position;
  if (!p) return 0;
  return p.side === "long" ? (px - p.entry) * p.ounces : (p.entry - px) * p.ounces;
}

export function equity(s: MatchState, px = markPrice(s)): number {
  return s.cash + (s.position?.margin ?? 0) + unrealizedPnl(s, px);
}

function recordPeak(s: MatchState, px?: number): MatchState {
  const eq = equity(s, px);
  const peak = Math.max(s.peakEquity, eq);
  const dd = peak > 0 ? (peak - eq) / peak : 0;
  return {
    ...s,
    peakEquity: peak,
    maxDrawdown: Math.max(s.maxDrawdown, dd),
  };
}

function snapshotEquity(s: MatchState): MatchState {
  const eq = equity(s);
  return {
    ...s,
    equityHistory: [...s.equityHistory, { t: lastBar(s).t, v: eq }],
  };
}

function levelsFor(side: Side, entry: number, mode: ProtectMode): { sl: number | null; tp: number | null } {
  if (mode === "off") return { sl: null, tp: null };
  const { sl, tp } = PROTECT[mode];
  if (side === "long") return { sl: entry * (1 - sl), tp: entry * (1 + tp) };
  return { sl: entry * (1 + sl), tp: entry * (1 - tp) };
}

function liquidationPrice(s: MatchState): number | null {
  const p = s.position;
  if (!p) return null;
  const cushion = s.cash + p.margin * (1 - MAINTENANCE);
  if (p.ounces <= 0) return null;
  if (p.side === "long") return p.entry - cushion / p.ounces;
  return p.entry + cushion / p.ounces;
}

function closeAt(s: MatchState, price: number, reason: ExitReason): MatchState {
  const p = s.position;
  if (!p) return s;
  const fill = p.side === "long" ? bid(price) : ask(price);
  const pnl = p.side === "long" ? (fill - p.entry) * p.ounces : (p.entry - fill) * p.ounces;
  const trade: Trade = {
    id: s.tradeSeq,
    side: p.side,
    ounces: p.ounces,
    leverage: p.leverage,
    entryTime: p.entryTime,
    entryPrice: p.entry,
    exitTime: lastBar(s).t,
    exitPrice: fill,
    pnl,
    reason,
  };
  const cash = s.cash + p.margin + pnl;
  let next: MatchState = {
    ...s,
    cash: Math.max(0, cash),
    position: null,
    trades: [...s.trades, trade],
    tradeSeq: s.tradeSeq + 1,
  };
  next = recordPeak(next);
  if (equity(next) <= 1) {
    next = { ...next, cash: 0, status: "blown" };
  }
  return next;
}

export function createMatch(opts: {
  scenarioId: string;
  scenarioTitle: string;
  timeframe: Timeframe;
  bars: Bar[];
  playStart: number;
  ounces: number;
  leverage: number;
}): MatchState {
  const cursor = Math.min(Math.max(opts.playStart, 0), opts.bars.length - 1);
  const seed: MatchState = {
    scenarioId: opts.scenarioId,
    scenarioTitle: opts.scenarioTitle,
    timeframe: opts.timeframe,
    bars: opts.bars,
    playStart: opts.playStart,
    cursor,
    cash: STARTING_CASH,
    position: null,
    trades: [],
    peakEquity: STARTING_CASH,
    maxDrawdown: 0,
    equityHistory: [],
    status: "playing",
    startingCash: STARTING_CASH,
    ounces: opts.ounces,
    leverage: opts.leverage,
    protect: "off",
    tradeSeq: 1,
  };
  return snapshotEquity(recordPeak(seed));
}

export function canAfford(s: MatchState, ounces = s.ounces, leverage = s.leverage): boolean {
  const px = markPrice(s);
  const margin = (px * ounces) / leverage;
  return s.cash + 1e-9 >= margin;
}

function openPosition(s: MatchState, side: Side): MatchState {
  if (s.status !== "playing" || s.position) return s;
  const raw = markPrice(s);
  const entry = side === "long" ? ask(raw) : bid(raw);
  const ounces = s.ounces;
  const leverage = s.leverage;
  const margin = (entry * ounces) / leverage;
  if (s.cash + 1e-9 < margin) return s;
  const { sl, tp } = levelsFor(side, entry, s.protect);
  const pos: Position = {
    side,
    ounces,
    leverage,
    entry,
    entryTime: lastBar(s).t,
    margin,
    sl,
    tp,
  };
  return recordPeak({
    ...s,
    cash: s.cash - margin,
    position: pos,
  });
}

export function placeLong(s: MatchState): MatchState {
  if (s.status !== "playing") return s;
  if (s.position?.side === "long") return s;
  let next = s;
  if (next.position?.side === "short") next = closeAt(next, markPrice(next), "manual");
  if (next.status !== "playing") return next;
  return openPosition(next, "long");
}

export function placeShort(s: MatchState): MatchState {
  if (s.status !== "playing") return s;
  if (s.position?.side === "short") return s;
  let next = s;
  if (next.position?.side === "long") next = closeAt(next, markPrice(next), "manual");
  if (next.status !== "playing") return next;
  return openPosition(next, "short");
}

export function flatten(s: MatchState, reason: ExitReason = "manual"): MatchState {
  if (!s.position || s.status !== "playing") return s;
  return closeAt(s, markPrice(s), reason);
}

export function setProtect(s: MatchState, mode: ProtectMode): MatchState {
  const p = s.position;
  if (!p) return { ...s, protect: mode };
  const { sl, tp } = levelsFor(p.side, p.entry, mode);
  return { ...s, protect: mode, position: { ...p, sl, tp } };
}

export function setSize(s: MatchState, ounces: number, leverage: number): MatchState {
  return { ...s, ounces, leverage };
}

function fillIfHit(s: MatchState, bar: Bar): MatchState {
  const p = s.position;
  if (!p) return s;
  const liq = liquidationPrice(s);
  if (p.side === "long") {
    if (liq !== null && (bar.o <= liq || bar.l <= liq)) {
      const fill = bar.o <= liq ? bar.o : liq;
      return closeAt(s, fill, "liquidation");
    }
    const slHit = p.sl !== null && (bar.o <= p.sl || bar.l <= p.sl);
    const tpHit = p.tp !== null && (bar.o >= p.tp || bar.h >= p.tp);
    if (slHit && tpHit) {
      const fill = bar.o <= p.sl! ? bar.o : p.sl!;
      return closeAt(s, fill, "sl");
    }
    if (slHit) {
      const fill = bar.o <= p.sl! ? bar.o : p.sl!;
      return closeAt(s, fill, "sl");
    }
    if (tpHit) {
      const fill = bar.o >= p.tp! ? bar.o : p.tp!;
      return closeAt(s, fill, "tp");
    }
  } else {
    if (liq !== null && (bar.o >= liq || bar.h >= liq)) {
      const fill = bar.o >= liq ? bar.o : liq;
      return closeAt(s, fill, "liquidation");
    }
    const slHit = p.sl !== null && (bar.o >= p.sl || bar.h >= p.sl);
    const tpHit = p.tp !== null && (bar.o <= p.tp || bar.l <= p.tp);
    if (slHit && tpHit) {
      const fill = bar.o >= p.sl! ? bar.o : p.sl!;
      return closeAt(s, fill, "sl");
    }
    if (slHit) {
      const fill = bar.o >= p.sl! ? bar.o : p.sl!;
      return closeAt(s, fill, "sl");
    }
    if (tpHit) {
      const fill = bar.o <= p.tp! ? bar.o : p.tp!;
      return closeAt(s, fill, "tp");
    }
  }
  return s;
}

export function advanceBar(s: MatchState): MatchState {
  if (s.status !== "playing") return s;
  if (s.cursor >= s.bars.length - 1) {
    return finish(s);
  }
  const cursor = s.cursor + 1;
  const bar = s.bars[cursor]!;
  let next: MatchState = { ...s, cursor };
  next = fillIfHit(next, bar);
  if (next.status !== "playing") return snapshotEquity(next);
  next = recordPeak(next);
  if (equity(next) <= 1) {
    if (next.position) next = closeAt(next, bar.c, "liquidation");
    next = { ...next, cash: 0, status: "blown" };
    return snapshotEquity(next);
  }
  if (cursor >= s.bars.length - 1) {
    return finish(snapshotEquity(next));
  }
  return snapshotEquity(next);
}

function finish(s: MatchState): MatchState {
  let next = s;
  if (next.position) next = closeAt(next, markPrice(next), "eod");
  if (next.status === "blown") return next;
  return { ...next, status: "finished" };
}

export function summarize(s: MatchState): Result {
  const startBar = s.bars[s.playStart] ?? s.bars[0]!;
  const endBar = lastBar(s);
  const endEquity = s.status === "blown" ? 0 : equity(s);
  const returnPct = (endEquity - s.startingCash) / s.startingCash;
  const holdPct = endBar.c / startBar.c - 1;
  const wins = s.trades.filter((t) => t.pnl > 0).length;
  return {
    scenarioId: s.scenarioId,
    scenarioTitle: s.scenarioTitle,
    timeframe: s.timeframe,
    status: s.status === "blown" ? "blown" : "finished",
    startCash: s.startingCash,
    endEquity,
    returnPct,
    holdPct,
    beatHold: returnPct > holdPct,
    trades: s.trades.length,
    wins,
    maxDrawdown: s.maxDrawdown,
    startDate: startBar.t,
    endDate: endBar.t,
    startPrice: startBar.c,
    endPrice: endBar.c,
    tradeList: s.trades,
    equityHistory: s.equityHistory,
  };
}

export function sma(bars: Bar[], period: number, until: number) {
  const out: { time: string; value: number }[] = [];
  let sum = 0;
  const end = Math.min(until, bars.length - 1);
  for (let i = 0; i <= end; i++) {
    sum += bars[i]!.c;
    if (i >= period) sum -= bars[i - period]!.c;
    if (i >= period - 1) out.push({ time: bars[i]!.t, value: sum / period });
  }
  return out;
}