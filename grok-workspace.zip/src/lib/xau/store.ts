import { create } from "zustand";
import {
  advanceBar,
  createMatch,
  flatten,
  placeLong,
  placeShort,
  setProtect,
  setSize,
  STARTING_CASH,
  summarize,
} from "./engine";
import { loadRandom, loadScenario } from "./scenarios";
import { loadScores, recordResult } from "./save";
import type { MatchState, ProtectMode, Result, ScoreBoard, Timeframe } from "./types";

export type Speed = 0 | 1 | 2 | 4 | 8;
export type Screen = "menu" | "desk" | "result";

type DeskState = {
  screen: Screen;
  match: MatchState | null;
  result: Result | null;
  ounces: number;
  leverage: number;
  speed: Speed;
  howTo: boolean;
  tf: Timeframe;
  scores: ScoreBoard;
  startingCash: number;
  hydrateScores: () => void;
  setTf: (tf: Timeframe) => void;
  openHowTo: (v: boolean) => void;
  setOunces: (n: number) => void;
  setLeverage: (n: number) => void;
  setSpeed: (s: Speed) => void;
  setProtectMode: (m: ProtectMode) => void;
  startScenario: (id: string) => void;
  startRandom: () => void;
  buy: () => void;
  sell: () => void;
  closePos: () => void;
  tickBar: () => void;
  finishNow: () => void;
  backToMenu: () => void;
};

function applyMatch(match: MatchState, screen: Screen, scores: ScoreBoard) {
  if (match.status === "playing") {
    return { match, screen: "desk" as const, result: null as Result | null };
  }
  const result = summarize(match);
  return {
    match,
    screen: "result" as const,
    result,
    speed: 0 as Speed,
    scores: recordResult(scores, result),
  };
}

export const useDesk = create<DeskState>((set, get) => ({
  screen: "menu",
  match: null,
  result: null,
  ounces: 0.5,
  leverage: 10,
  speed: 0,
  howTo: false,
  scores: { version: 1, best: {} },
  startingCash: STARTING_CASH,
  hydrateScores: () => set({ scores: loadScores() }),
  openHowTo: (v) => set({ howTo: v }),
  setOunces: (n) => {
    const match = get().match;
    set({
      ounces: n,
      match: match ? setSize(match, n, match.leverage) : match,
    });
  },
  setLeverage: (n) => {
    const match = get().match;
    set({
      leverage: n,
      match: match ? setSize(match, match.ounces, n) : match,
    });
  },
  setSpeed: (s) => set({ speed: s }),
  setProtectMode: (m) => {
    const match = get().match;
    if (!match) return;
    set({ match: setProtect(match, m) });
  },
  startScenario: (id) => {
    const loaded = loadScenario(id);
    if (!loaded) return;
    const { ounces, leverage } = get();
    const match = createMatch({
      scenarioId: loaded.scenario.id,
      scenarioTitle: loaded.scenario.title,
      bars: loaded.bars,
      playStart: loaded.playStart,
      ounces,
      leverage,
    });
    set({ match, screen: "desk", result: null, speed: 0 });
  },
  startRandom: () => {
    const loaded = loadRandom();
    const { ounces, leverage } = get();
    const match = createMatch({
      scenarioId: loaded.scenario.id,
      scenarioTitle: loaded.scenario.title,
      bars: loaded.bars,
      playStart: loaded.playStart,
      ounces,
      leverage,
    });
    set({ match, screen: "desk", result: null, speed: 0 });
  },
  buy: () => {
    const match = get().match;
    if (!match) return;
    set({ match: placeLong(match) });
  },
  sell: () => {
    const match = get().match;
    if (!match) return;
    set({ match: placeShort(match) });
  },
  closePos: () => {
    const match = get().match;
    if (!match) return;
    set({ match: flatten(match) });
  },
  tickBar: () => {
    const { match, scores } = get();
    if (!match || match.status !== "playing") return;
    const next = advanceBar(match);
    set(applyMatch(next, "desk", scores));
  },
  finishNow: () => {
    const { match, scores } = get();
    if (!match) return;
    let next = match;
    while (next.status === "playing" && next.cursor < next.bars.length - 1) {
      next = advanceBar(next);
    }
    if (next.status === "playing") next = advanceBar(next);
    set(applyMatch(next, "result", scores));
  },
  backToMenu: () => set({ screen: "menu", match: null, result: null, speed: 0 }),
}));