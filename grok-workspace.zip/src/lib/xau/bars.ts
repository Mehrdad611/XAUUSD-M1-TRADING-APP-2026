import rawDaily from "@/data/xau-daily.json";
import raw5m from "@/data/xau-5m.json";
import raw15m from "@/data/xau-15m.json";
import type { Bar, Timeframe } from "./types";

function mapRows(raw: unknown, unix: boolean): Bar[] {
  const rows = raw as [string | number, number, number, number, number][];
  return rows.map(([t, o, h, l, c]) => ({
    t: unix ? Number(t) : String(t),
    o,
    h,
    l,
    c,
  }));
}

export const XAU_DAILY: Bar[] = mapRows(rawDaily, false);
export const XAU_5M: Bar[] = mapRows(raw5m, true);
export const XAU_15M: Bar[] = mapRows(raw15m, true);

export const TF_META: Record<Timeframe, { label: string; short: string; bars: Bar[] }> = {
  "1d": { label: "روزانه", short: "D1", bars: XAU_DAILY },
  "15m": { label: "۱۵ دقیقه", short: "M15", bars: XAU_15M },
  "5m": { label: "۵ دقیقه", short: "M5", bars: XAU_5M },
};

export function barsFor(tf: Timeframe): Bar[] {
  return TF_META[tf].bars;
}

export function dayKey(t: string | number): string {
  if (typeof t === "number") return new Date(t * 1000).toISOString().slice(0, 10);
  return t.slice(0, 10);
}

export function sliceWindow(start: string, end: string, warmup: number, bars: Bar[]) {
  const startIdx = bars.findIndex((b) => dayKey(b.t) >= start);
  let endIdx = -1;
  for (let i = bars.length - 1; i >= 0; i--) {
    if (dayKey(bars[i]!.t) <= end) {
      endIdx = i;
      break;
    }
  }
  if (startIdx < 0 || endIdx < 0) {
    return { bars: bars.slice(0, 1), playStart: 0 };
  }
  endIdx = Math.max(startIdx, endIdx);
  const warmFrom = Math.max(0, startIdx - warmup);
  return { bars: bars.slice(warmFrom, endIdx + 1), playStart: startIdx - warmFrom };
}