const usdFmt = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

const usdCompact = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  minimumFractionDigits: 0,
  maximumFractionDigits: 0,
});

const pxFmt = new Intl.NumberFormat("en-US", {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

export function usd(n: number, compact = false): string {
  return (compact ? usdCompact : usdFmt).format(n);
}

export function px(n: number): string {
  return pxFmt.format(n);
}

export function pct(n: number, digits = 2): string {
  const sign = n > 0 ? "+" : "";
  return `${sign}${(n * 100).toFixed(digits)}%`;
}

function asDate(t: string | number): { d: Date; intra: boolean } {
  if (typeof t === "number") return { d: new Date(t * 1000), intra: true };
  if (t.length > 10) return { d: new Date(t), intra: true };
  return { d: new Date(`${t}T00:00:00Z`), intra: false };
}

export function faStamp(t: string | number): string {
  const { d, intra } = asDate(t);
  return new Intl.DateTimeFormat("fa-IR", {
    year: intra ? undefined : "numeric",
    month: "short",
    day: "numeric",
    hour: intra ? "2-digit" : undefined,
    minute: intra ? "2-digit" : undefined,
    hour12: false,
    timeZone: intra ? "Asia/Tehran" : "UTC",
  }).format(d);
}

export function faDate(t: string | number): string {
  return faStamp(t);
}

export function signedUsd(n: number): string {
  const body = usd(Math.abs(n));
  if (n > 0) return `+${body}`;
  if (n < 0) return `−${body}`;
  return body;
}