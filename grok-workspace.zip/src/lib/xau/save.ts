import type { Result, ScoreBoard } from "./types";

const KEY = "xau-desk-scores-v1";

const empty: ScoreBoard = { version: 1, best: {} };

export function loadScores(): ScoreBoard {
  if (typeof localStorage === "undefined") return empty;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return empty;
    const parsed = JSON.parse(raw) as ScoreBoard;
    if (parsed.version !== 1 || typeof parsed.best !== "object") return empty;
    return { version: 1, best: parsed.best ?? {} };
  } catch {
    return empty;
  }
}

export function recordResult(board: ScoreBoard, result: Result): ScoreBoard {
  const prev = board.best[result.scenarioId];
  if (prev && prev.returnPct >= result.returnPct) return board;
  const next: ScoreBoard = {
    version: 1,
    best: {
      ...board.best,
      [result.scenarioId]: {
        returnPct: result.returnPct,
        beatHold: result.beatHold,
        at: String(result.endDate),
      },
    },
  };
  try {
    localStorage.setItem(KEY, JSON.stringify(next));
  } catch {
    /* private mode / quota */
  }
  return next;
}