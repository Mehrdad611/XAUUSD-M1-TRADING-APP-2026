import { barsFor, dayKey, sliceWindow, XAU_5M, XAU_15M, XAU_DAILY } from "./bars";
import type { Bar, Scenario, Timeframe } from "./types";

export const SCENARIOS: Scenario[] = [
  {
    id: "peak-2011",
    title: "قله ۲۰۱۱",
    era: "۲۰۱۰ — ۲۰۱۲",
    tone: "رونددار",
    blurb: "بحران بدهی اروپا و سیاست پولی انبساطی. طلا به عنوان پناهگاه دوباره مرکز توجه است.",
    start: "2010-09-01",
    end: "2012-03-01",
    warmup: 45,
    timeframe: "1d",
  },
  {
    id: "crash-2013",
    title: "زمستان ۲۰۱۳",
    era: "۲۰۱۳",
    tone: "پرنوسان",
    blurb: "بازار انتظار دارد سیاست پولی عوض شود. آیا طلا هنوز پناهگاه است یا دارایی پرریسک؟",
    start: "2013-01-02",
    end: "2013-12-31",
    warmup: 45,
    timeframe: "1d",
  },
  {
    id: "covid-2020",
    title: "پناه کووید",
    era: "۲۰۲۰",
    tone: "شوک",
    blurb: "همه‌گیری جهانی نقدینگی را می‌مکد. طلا، دلار، همه چیز با هم حرکت می‌کنند — تا وقتی که نکنند.",
    start: "2020-01-02",
    end: "2020-08-31",
    warmup: 40,
    timeframe: "1d",
  },
  {
    id: "war-2022",
    title: "شوک جنگ",
    era: "۲۰۲۲",
    tone: "دو طرفه",
    blurb: "تهاجم و تورم. پناهگاه سنتی طلا در برابر نرخ بهره واقعی محک می‌خورد.",
    start: "2022-02-01",
    end: "2022-11-15",
    warmup: 40,
    timeframe: "1d",
  },
  {
    id: "rally-2024",
    title: "رالی خاموش",
    era: "۲۰۲۳ — ۲۰۲۴",
    tone: "رونددار",
    blurb: "بانک‌های مرکزی می‌خرند، نرخ‌ها به اوج نزدیک‌اند. شکست مقاومت‌های قدیمی در راه است — یا فریب.",
    start: "2023-10-02",
    end: "2024-10-31",
    warmup: 45,
    timeframe: "1d",
  },
  {
    id: "year-2025",
    title: "سال آتش",
    era: "۲۰۲۵",
    tone: "رونددار",
    blurb: "طلا بالای سقف‌های تاریخی معامله می‌شود. دنبال‌کردن روند، یا شرط روی بازگشت؟",
    start: "2025-01-02",
    end: "2025-12-31",
    warmup: 45,
    timeframe: "1d",
  },
  {
    id: "m15-aug05",
    title: "هفته جهش",
    era: "اوت ۲۰۲۶",
    tone: "پرنوسان",
    blurb: "چند روز متوالی با نوسان سه‌رقمی. روی ۱۵دقیقه ورود و خروج را زمان‌بندی کن.",
    start: "2026-08-04",
    end: "2026-08-07",
    warmup: 24,
    timeframe: "15m",
  },
  {
    id: "m15-aug19",
    title: "رالی ۱۹ اوت",
    era: "اوت ۲۰۲۶",
    tone: "رونددار",
    blurb: "حرکت تند به سمت سقف‌های جدید. آیا دنبال می‌کنی یا در اوج می‌فروشی؟",
    start: "2026-08-18",
    end: "2026-08-20",
    warmup: 20,
    timeframe: "15m",
  },
  {
    id: "m15-dump",
    title: "ریزش ۲۸ اوت",
    era: "اوت ۲۰۲۶",
    tone: "شوک",
    blurb: "بازگشت تند از سقف. ۱۵دقیقه جای پنهان‌شدن نمی‌دهد.",
    start: "2026-08-27",
    end: "2026-08-28",
    warmup: 20,
    timeframe: "15m",
  },
  {
    id: "m15-last-week",
    title: "هفته آخر",
    era: "اوت — سپتامبر ۲۰۲۶",
    tone: "دو طرفه",
    blurb: "آخرین هفته داده: سقف و سپس عقب‌نشینی. اسکالپ یا سوئینگ کوتاه.",
    start: "2026-08-25",
    end: "2026-09-01",
    warmup: 16,
    timeframe: "15m",
  },
  {
    id: "m5-aug05",
    title: "جهش ۵ اوت",
    era: "۵ اوت ۲۰۲۶",
    tone: "شوک",
    blurb: "یک جلسه با بیش از ۲۰۰ دلار نوسان. ۵دقیقه، تصمیم‌های سریع.",
    start: "2026-08-05",
    end: "2026-08-05",
    warmup: 36,
    timeframe: "5m",
  },
  {
    id: "m5-aug19",
    title: "حمله ۱۹ اوت",
    era: "۱۹ اوت ۲۰۲۶",
    tone: "رونددار",
    blurb: "رالی یک‌جلسه‌ای به سقف تازه. ورود دیر یعنی جا ماندن؛ ورود زود یعنی ترس.",
    start: "2026-08-19",
    end: "2026-08-19",
    warmup: 36,
    timeframe: "5m",
  },
  {
    id: "m5-aug28",
    title: "سقوط ۲۸ اوت",
    era: "۲۸ اوت ۲۰۲۶",
    tone: "پرنوسان",
    blurb: "بازگشت خشن از ۴۶۸۰. حد ضرر را جدی بگیر.",
    start: "2026-08-28",
    end: "2026-08-28",
    warmup: 36,
    timeframe: "5m",
  },
  {
    id: "m5-last",
    title: "جلسه آخر",
    era: "۱ سپتامبر ۲۰۲۶",
    tone: "دو طرفه",
    blurb: "آخرین روز موجود. قیمت از سقف فاصله می‌گیرد — دنباله یا برگشت؟",
    start: "2026-09-01",
    end: "2026-09-01",
    warmup: 40,
    timeframe: "5m",
  },
];

export function loadScenario(id: string) {
  const sc = SCENARIOS.find((s) => s.id === id);
  if (!sc) return null;
  const slice = sliceWindow(sc.start, sc.end, sc.warmup, barsFor(sc.timeframe));
  return { scenario: sc, ...slice };
}

function sessionDays(bars: Bar[]): string[] {
  const counts = new Map<string, number>();
  for (const b of bars) {
    const k = dayKey(b.t);
    counts.set(k, (counts.get(k) ?? 0) + 1);
  }
  const min = bars === XAU_5M ? 180 : 60;
  return [...counts.entries()].filter(([, n]) => n >= min).map(([d]) => d);
}

export function loadRandom(tf: Timeframe = "1d") {
  if (tf === "1d") {
    const play = 90;
    const warmup = 40;
    const bars = XAU_DAILY;
    const minStart = warmup;
    const maxStart = bars.length - play - 1;
    const startIdx = minStart + Math.floor(Math.random() * (maxStart - minStart));
    const endIdx = startIdx + play;
    const warmFrom = startIdx - warmup;
    const window = bars.slice(warmFrom, endIdx + 1);
    const startDate = bars[startIdx]!.t;
    const endDate = bars[endIdx]!.t;
    const scenario: Scenario = {
      id: "random",
      title: "پنجره تصادفی",
      era: String(startDate).slice(0, 4),
      tone: "ناشناخته",
      blurb: "۹۰ روز تصادفی از ۱۷ سال تاریخ طلا. بدون داستان، فقط قیمت.",
      start: String(startDate),
      end: String(endDate),
      warmup,
      timeframe: "1d",
    };
    return { scenario, bars: window, playStart: warmup };
  }

  const source = tf === "5m" ? XAU_5M : XAU_15M;
  const days = sessionDays(source);
  const span = tf === "5m" ? 1 : 3;
  const pick = Math.floor(Math.random() * Math.max(1, days.length - span));
  const start = days[pick]!;
  const end = days[Math.min(days.length - 1, pick + span - 1)]!;
  const warmup = tf === "5m" ? 36 : 20;
  const slice = sliceWindow(start, end, warmup, source);
  const scenario: Scenario = {
    id: `random-${tf}`,
    title: "پنجره تصادفی",
    era: start.slice(5),
    tone: "ناشناخته",
    blurb:
      tf === "5m"
        ? "یک جلسه تصادفی از ۶۰ روز اخیر، کندل ۵دقیقه."
        : "چند روز تصادفی از ۶۰ روز اخیر، کندل ۱۵دقیقه.",
    start,
    end,
    warmup,
    timeframe: tf,
  };
  return { scenario, ...slice };
}