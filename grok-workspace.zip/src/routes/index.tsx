import { createFileRoute } from "@tanstack/react-router";
import { ResultScreen } from "@/components/desk/ResultScreen";
import { StartMenu } from "@/components/desk/StartMenu";
import { TradingDesk } from "@/components/desk/TradingDesk";
import { useDesk } from "@/lib/xau/store";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const screen = useDesk((s) => s.screen);
  if (screen === "desk") return <TradingDesk />;
  if (screen === "result") return <ResultScreen />;
  return <StartMenu />;
}